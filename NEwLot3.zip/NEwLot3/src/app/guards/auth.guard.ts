import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../service/authentication.service';
import { Role } from '../shared/model/role';


@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private _router: Router,  private oauthService: OAuthService,private authenticationservice:AuthenticationService){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      const roles = next.data.roles as Role[];
      const isprojectrole= next.data.isProjectPage as boolean;
    
      //OIDC CODE
      if ( this.oauthService.hasValidAccessToken() )
       {
        if(!isprojectrole){
          if (roles && !roles.some(r => this.authenticationservice.hasRole(r))) {
            return false;
          }
          else{
            return true
          }
        }
        else{
if (roles && !roles.some(r => this.authenticationservice.hasProjectRole(r))) {
            return false;
        }
        else{
          //20 May 
          //this.oauthService.refreshToken()
          return true
        }
        }
      }
     
       else{
        window.location.reload();
        this.oauthService.logOut();
          return false;
          // console.log("token validationin", this.oauthService.hasValidAccessToken())
          // NE28061-27 -Session Expire
          // alert("Session Expired")
          // window.location.reload();
          // this.oauthService.logOut();
          // return false;
      }

  }
}
