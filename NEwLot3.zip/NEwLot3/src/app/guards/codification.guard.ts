import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router, ActivatedRoute } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthenticationService } from '../service/authentication.service';
import { CodificationSeaService } from '../service/codification-sea.service';
import { CommonService } from '../service/common.service';
import { ProjectService } from '../service/project.service';
import { Role } from '../shared/model/role';

@Injectable({
  providedIn: 'root'
})
export class CodificationGuard implements CanActivate {
  constructor(private _router: Router, private oauthService: OAuthService,private codSeaService:CodificationSeaService,
    private commonService:CommonService,private activateRoute:ActivatedRoute,private router:Router,private projectService:ProjectService,
     private authenticationservice: AuthenticationService) { }


     canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot):Observable<boolean>|boolean {
      const url = window.location.href
      let projectId= url.match("project-home/(.*)/measure")[1];
      
      if(projectId!=undefined && projectId!=null){
        this.commonService.setProjectId(projectId);
       let reqparamas={
       "UserId":this.commonService.getUserID(),
       "ProjectId":projectId,
       }
     return this.codSeaService.getRoleByProjectId(reqparamas).pipe(map((data)=>{
    
        if (data) {
         
         let val= data.GetRoleDetailsByUserGoalIDAndProjectIDNewResult[0]
         if(val!=undefined && val!=null && val!=""){
          this.commonService.setProjectRole(val.ROLE_NAME)
          this.commonService.setProjectName(val.PROJECT_NAME)
          if(val.ROLE_NAME!=undefined && val.ROLE_NAME!=null && val.ROLE_NAME!=""){
           if(val.ROLE_NAME!=Role.ReadOnly){
         
          return true;}
          else{
            return false;
          }
        }

          else{
            return false;
          }
      }
      else{
        return false
      }}
        
       }))}
     }}













//   canActivate(
//     next: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {


//     const isprojectrole = next.data.isProjectPage as boolean;

//     //OIDC CODE
//     if (this.oauthService.hasValidAccessToken()) {
//        this.setRole()
       
//       return true;
//     }

//     else {

//       // this.oauthService.refreshToken()
//       // console.log("token validationin", this.oauthService.hasValidAccessToken())
//       // NE28061-27 -Session Expire
//       alert("Session Expired")
//       window.location.reload();
//       this.oauthService.logOut();
//       return false;
//     }

//   }
//   async setRole(){
//     let reqparamas={

//     }
//      this.codSeaService.getRoleByProjectId(reqparamas).subscribe((data:any)=>{
//       let projectRole= data.GetHighestRoleDetailsByUserGoalIDAndProjectIDResult
//       //this.commonService.setProjectRole(projectRole);
//       this.commonService.setProjectRole("TNT.ADMIN")
//       console.log("role set")
//        })
//   }
// }

    
