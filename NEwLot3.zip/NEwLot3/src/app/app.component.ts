import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter, map, mergeMap, tap } from 'rxjs/operators';
import LocalStorage from './util/local-storage';
import { OAuthService } from 'angular-oauth2-oidc';
import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';
import { AuthenticationService } from './service/authentication.service';
import { LOCAL_STORAGE_USER_ID, LOCAL_STORAGE_USER_LOCALE, LOCAL_STORAGE_User_LOGGED, LOCAL_STORAGE_USER_NAME, LOCAL_STORAGE_USER_ROLE } from './constant/auth-constant';
import { ConfirmationService } from 'primeng';
import { Role } from './shared/model/role';
import { URLService } from './service/url.service';
import { TechnicalErrorService } from './service/technical-error.service';
import { CommonService } from './service/common.service';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';

import { AppConfig } from './shared/config/app.config';
import { authCodeFlowConfig } from './shared/config/sso.config';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  
})
export class AppComponent {
  timed :boolean = false;
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
   countdown:any;
  helplink:string;
  showSidebar$: Observable<boolean>;
  displayDailog:boolean;sessionOutDialog:boolean=false
  interval;

  // OIDC CODE set userprofileload this to false 
  userprofileload: Boolean = false;
  private defaultShowSidebar = true;
  title = 'newTitan';
  constructor(private router: Router, private activatedRoute: ActivatedRoute,
    private authenticationservice: AuthenticationService,
    private urlService: URLService,
    private oauthService: OAuthService,
    private TechnicalErrorService: TechnicalErrorService,
    private commonservice: CommonService, private idle: Idle,
    private appConfig: AppConfig) {
    /*call to idp*/
    ////OIDC CODE
    this.configureSingleSignOn();
    /*To show hide the left menu*/
    this.showSidebar$ = this.router.events.pipe(
      filter(e => e instanceof NavigationEnd),
      map(() => activatedRoute),
      map(route => {
        while (route.firstChild) {
          route = route.firstChild;
        }
        return route;
      }),
      mergeMap(route => route.data),
      map(data => data.hasOwnProperty('showSidebar') ? data.showSidebar : this.defaultShowSidebar),
    )
  }
  ngOnInit() {
  }

  /***
     * this method calls the IPD and validate the received token.
     * method is written aync so the flow of the project waits for the IDP response.
     * Author:Shweta
     * created 15/02/2021
     * updated:25/06/2021
     */

  configureSingleSignOn() {
    authCodeFlowConfig.clientId = this.appConfig.exposedClientID;
    authCodeFlowConfig.issuer = this.appConfig.exposedIssuerURL
    authCodeFlowConfig.disablePKCE = false
    authCodeFlowConfig.responseType = 'code'
    authCodeFlowConfig.redirectUri = this.appConfig.exposedRedirectURL
    authCodeFlowConfig.tokenEndpoint = this.appConfig.exposedTokenEndpointURL
    authCodeFlowConfig.dummyClientSecret = this.appConfig.exposedClientSecretVar
    authCodeFlowConfig.scope = this.appConfig.exposedScopeVar;
    authCodeFlowConfig.logoutUrl = this.appConfig.exposedLogoutURL
    this.oauthService.configure(authCodeFlowConfig);
    this.oauthService.setStorage(localStorage);

    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.loadDiscoveryDocumentAndLogin().then(res => {
      if (res) {
        let token = this.oauthService.getAccessToken();
        let tokenexpiry = this.oauthService.getAccessTokenExpiration();
        console.log("has valid access token ", this.oauthService.hasValidAccessToken());
        console.log("has valid Id token", this.oauthService.hasValidIdToken());
        this.authenticationservice.startRefreshTokenTimer(this.appConfig.exposedRefreshTokenInterval)  // NE28061-27 -Session Expire commented by Savitri
        this.getUserInfo(token);
        console.log(tokenexpiry, "expires_at ");
        let valueExpDATETIME = new Date(tokenexpiry as number);
        console.log(valueExpDATETIME, "valueExpDATETIME");
        this.checkUserIdleTime();


      }
      else
        this.authenticationservice.stopRefreshTokenTimer()
    }).catch(err => {
      console.log("Unable to login");
    })

  }


  getUserInfo(token) {
    let reqParamas = {
      "accessToken": token,
      "userLocale": this.commonservice.getUserlocaleName()
    }
    this.authenticationservice.loginWithToken(reqParamas).subscribe(res => {
      let data = res.AuthenticateWithIDPResult
      console.log("data", data);

      if (data.Result) {

        LocalStorage.addItem(LOCAL_STORAGE_USER_NAME, data.UserName)
        LocalStorage.addItem(LOCAL_STORAGE_USER_ID, data.UserID)
        LocalStorage.addItem(LOCAL_STORAGE_User_LOGGED, true)
        LocalStorage.addItem(LOCAL_STORAGE_USER_LOCALE, data.UserLocale)

        if (data.groups == null) {
          this.userprofileload = false;
          this.displayDailog = true
        }
        else
          if (this.authenticationservice.matchRole(data.groups) == false) {
            this.userprofileload = false;
            this.displayDailog = true
          }

          else {
            LocalStorage.addItem(LOCAL_STORAGE_USER_ROLE, data.groups)
            console.log("user role", data.groups)
            this.userprofileload = true
          }
      }
      ;
    },
      (error) => {
        this.TechnicalErrorService.setFlagValue(true)
        alert("Server is down. Please try to access the application after some time!")
        this.authenticationservice.logout()
      })
  }

  getHelpLink() {
    this.helplink = this.urlService.getHelpLink();
  }

  onHide() {
    // this.oauthService.revokeTokenAndLogout();
    this.authenticationservice.logout();
  }
  checkUserIdleTime() {
    this.idle.setIdle(this.appConfig.exposedIdleInterval);
    this.idle.setTimeout(this.appConfig.eposedidleTimeOutInterval);
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    this.idle.onIdleEnd.subscribe(() => {
      this.authenticationservice.refreshToken()

    });
    this.idle.onTimeout.subscribe(() => {
      this.sessionOut();
     
    });
    this.idle.onTimeoutWarning.subscribe((countdown) => {
      this.sessionOutDialog=true
      let d = new Date();
      let n = d.getUTCMinutes()
      console.log(countdown, n)
      if (countdown == 1) {
        this.timed = true;
        console.log("in count times");
      }
    });

    this.reset();
  }
  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }
  //This method will prevent default right click
  onRightClick() {
    return false;
  }
  sessionOut(){
    this.sessionOutDialog=false
    this.timedOut = true;
    window.location.reload();
    this.oauthService.logOut();
  }
  setIntervalFormessage()
  {
    this.sessionOutDialog=false
    this.authenticationservice.refreshToken();
    this.reset();
  }
}
