import {Component, OnInit} from '@angular/core';
import {MenuItem} from 'primeng/api';
import {isNullOrUndefined} from 'util';
import {ActivatedRoute, NavigationEnd, Router, RouterEvent} from '@angular/router';
import {distinctUntilChanged, filter, map, takeUntil} from 'rxjs/operators';
import { CommonService } from './service/common.service';
import { TranslateService } from '@ngx-translate/core';
import { PROJECTDYNAMICNAME,PROJECT_TITLE } from './constant/auth-constant';
import * as _ from 'node_modules/lodash';
import { Subject } from 'rxjs/internal/Subject';
import { HeaderChangeService } from './service/header-change.service';
import { WindowScrollController } from '@fullcalendar/core';
export interface BreadCrumb {
    label: string;
    url: string;title:string
};
@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss'],
  styles: ['div { border: none !important; }body .ui-breadcrumb{border:none !important}'],
  /*template: `
    <style>
    .ui-breadcrumb {
      border: none !important;
  },
  .pi-home:before
  {
    color: #1976d2;
  }
    </style>
    
  `*/

})
export class BreadcrumbComponent implements OnInit {
  static readonly ROUTE_DATA_BREADCRUMB = 'breadcrumb';
  static readonly TRANSLATION_KEY = 'traskey';
  readonly home = {icon: 'home-icon', url: '/home'};
  menuItems: MenuItem[];unsubscribe$: Subject<boolean> = new Subject();

  breadcrumbs$ = this.router.events.pipe(filter(event => event instanceof NavigationEnd))
  .subscribe(() => {this.menuItems = this.createBreadcrumbs(this.activatedRoute.root)
    distinctUntilChanged(),
    this.menuItems.forEach(item=>{
      let text= item.title
      if(text!=null&& text!=""&& text!=undefined){
        if(text==PROJECTDYNAMICNAME){
         item.label=this.commonservice.getProjectName()!=undefined?this.commonservice.getProjectName():PROJECTDYNAMICNAME
        }
        else{
         let res= this.translate.instant(text)
         item.label= res;
        }
      }
 
      
     })});
  projectName: string;
    //Build your breadcrumb starting with the root route of your current activated route


  constructor(private router: Router,private headerService:HeaderChangeService, private activatedRoute: ActivatedRoute, private translate: TranslateService ,private commonservice:CommonService) { }

  private createBreadcrumbs(route: ActivatedRoute, url: string = '', breadcrumbs: MenuItem[] = []): MenuItem[] {
    
    const children: ActivatedRoute[] = route.children;
    
    if (children.length === 0) {
      return breadcrumbs;
    }

    for (const child of children) {
      const routeURL: string = child.snapshot.url.map(segment => segment.path).join('/');
      if (routeURL !== '') {
        url += `/${routeURL}`;
      }

      let label = child.snapshot.data[BreadcrumbComponent.ROUTE_DATA_BREADCRUMB];
      let title= child.snapshot.data[BreadcrumbComponent.TRANSLATION_KEY];
      if(label!=""&& label!=undefined && label!=""){
        if(title==PROJECT_TITLE) {
          let userlang= this.commonservice.getUserlocaleName()
          if(userlang!=null && userlang!="" && userlang !=undefined ){
            let langobj=  userlang.split("_")[0];
            if(langobj!=null && langobj!="" && langobj!=undefined) {
              this.translate.use(langobj);  
            }
          }
        }
        label=this.translate.instant(title)
      }
      if (!isNullOrUndefined(label)) {
        breadcrumbs.push({label, url,title,routerLink:url});
      }
   
      return this.createBreadcrumbs(child, url, breadcrumbs);
    }
  }
  ngOnInit() {

   this.initEvents()
      this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => 
        {
          this.menuItems=  _.uniqBy(this.menuItems, 'title');
          this.menuItems.forEach(item=>{
            let text= item.title
            if(text==PROJECTDYNAMICNAME){
              // setTimeout(() => {      
              //   item.label=this.commonservice.getProjectName()!=undefined?this.commonservice.getProjectName():PROJECTDYNAMICNAME
              // }, 100);
              item.label=this.commonservice.getProjectName()!=undefined?this.commonservice.getProjectName():PROJECTDYNAMICNAME
            }
            else{
             let res= this.translate.instant(text)
             item.label= res;
            }
           })
        
      });    
  }
  ngOnDestroy() {
     this.unsubscribe$.next(true);
     this.unsubscribe$.complete();
  }
  initEvents()
  {
    
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {this.menuItems = this.createBreadcrumbs(this.activatedRoute.root)
     
      this.menuItems=  _.uniqBy(this.menuItems, 'title');
      console.log("breadcrumbs",this.menuItems)
    this.menuItems.forEach(item=>{
     let text= item.title
     if(text!=null&& text!=""&& text!=undefined){
       if(text==PROJECTDYNAMICNAME){
        // setTimeout(() => {
            
        //   item.label=this.commonservice.getProjectName()!=undefined?this.commonservice.getProjectName():PROJECTDYNAMICNAME
        // }, 100);
         item.label=this.commonservice.getProjectName()!=undefined?this.commonservice.getProjectName():PROJECTDYNAMICNAME
       }
       else{
        let res= this.translate.instant(text)
        item.label= res;
       }
     }

     
    })}
      );    
  }
}
