import { Component, Output, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Role } from "../../../shared/model/role";
import { AuthenticationService } from '../../../service/authentication.service';
import LocalStorage from '../../../util/local-storage';
import { LOCAL_STORAGE_USER_NAME } from '../../../constant/auth-constant';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { CommonService } from 'src/app/service/common.service';
import { ProjectService } from 'src/app/service/project.service';
import { filter } from 'rxjs-compat/operator/filter';
import { TechnicalErrorService } from 'src/app/service/technical-error.service';

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
    Role = Role;
    isActive: boolean = false;
    collapsed: boolean = false;
    showMenu: string = '';
    pushRightClass: string = 'push-right';
    userRole: string;
    projectLayout: boolean = false;
    // disk storage issue
    selectedprojectid:any;
    @Output() collapsedEvent = new EventEmitter<boolean>();

    sideBarTooltip: string;
    browserLang: string;

    // unsubscribe$: Subject<boolean> = new Subject();

    constructor(private translate: TranslateService,
        private commonservice: CommonService,
        private headerChangeService: HeaderChangeService,
        public router: Router,
        public route: ActivatedRoute,
        private _authService: AuthenticationService,

        private projectservice: ProjectService,

    ) {
        
    }


    ngOnInit(): void {
        if(this.selectedprojectid != null && this.selectedprojectid != undefined){
 
            this.storeSessionInfo();
        }
        
        // Function to change tooltip
        this.sideBarTooltip = "Collapse Sidebar";      
        
        setTimeout(() => {  
            this.selectedprojectid = this.commonservice.getProjectId(); 
              
        }, 300);

       
        this.headerChangeService.projectchange.subscribe(res => {   
            this.projectLayout = res.isProjectSelected;
            if(this.projectLayout){
                this.storeSessionInfo()
            }
        });
        
        this.commonservice.setProjectId(this.selectedprojectid);
       
        const user: any = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);

        this.router.events.subscribe(val => {
            if (
                val instanceof NavigationEnd &&
                window.innerWidth <= 992 &&
                this.isToggled()
            ) {
                this.toggleSidebar();
            }
        });
    }

    // ngOnDestroy() {
    //     this.unsubscribe$.next(true);
    //     this.unsubscribe$.complete();
    // }

    storeSessionInfo(){

        this.headerChangeService.projectchange.subscribe(res => {
            this.selectedprojectid = this.commonservice.getProjectId();
            this.projectLayout = res.isProjectSelected;
        });

        this.selectedprojectid = this.commonservice.getProjectId();
    
       // let val = this.commonservice.decryptID(this.selectedprojectid)
        this.projectservice.getprojectDetailById(this.selectedprojectid).subscribe((data: any) => {
            this.commonservice.setProjectName(data.URL_SITE)
            this.commonservice.setProjectLocale(data.LOCALE)
        })
       
    }

    onLaunch() {

        this.storeSessionInfo();
        this.router.navigate(['/project-home/' + this.selectedprojectid + '/launch'])
    }

    onMailRec(){
        this.storeSessionInfo();
        this.router.navigate(['/project-home/' + this.selectedprojectid + '/mailrecipients'])
    }
    onVehicleDetail(){
        this.storeSessionInfo();
        this.router.navigate(['/project-home/' + this.selectedprojectid + '/vehicles'])
    }

    onUpload(){
        this.storeSessionInfo();
        this.router.navigate(['/project-home/' + this.selectedprojectid + '/upload'])
    }

    eventCalled() {
        this.isActive = !this.isActive;
    }

    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }

    toggleCollapsed() {
        this.sideBarTooltip = this.showSideBarTooltip(this.collapsed);

        this.collapsed = !this.collapsed;
        this.collapsedEvent.emit(this.collapsed);

    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {

        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);

        console.log("side bar toggeld")
    }

    changeLang(language: string) {
        this.translate.use(language);
    }

    onLoggedout() {
        localStorage.removeItem('isLoggedin');
    }

    logout() {
        this._authService.logout();
    }

    // isReader(): boolean {
    //     return this._authService.isReader();
    // }

    // Function to show tooltip

    showSideBarTooltip(compareResult) {

        //this.browserLang = this.commonservice.getUserlocaleName();

        // console.log(compareResult,"Change Tooltip");
        console.log(this.browserLang, "Browser Lang");

        // this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => {
        //     this.browserLang=this.commonservice.getUserlocaleName()
        //     console.log(this.browserLang);
        // })


        let tooltipText: string;

        if (compareResult == true) {
            tooltipText = "Collapse Sidebar";
        }
        if (compareResult == false) {
            tooltipText = "Expand Sidebar";
        }

        // if(compareResult == true && this.browserLang == "fr_FR"){
        //     tooltipText = "Masquer le menu";
        // }

        // if(compareResult == false && this.browserLang == "fr_FR"){
        //     tooltipText = "FR_Expand Sidebar";
        // }



        return tooltipText;
    }


}
