import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd, RouterEvent } from '@angular/router';
import { filter, distinctUntilChanged, map, subscribeOn, takeUntil } from 'rxjs/operators';

import { TranslateService } from '@ngx-translate/core';
import LocalStorage from '../../../util/local-storage';
import {
  LOCAL_STORAGE_USER_NAME, LOCAL_STORAGE_USER_ID, DEFAULT_LANGUGAGECODEENG, DEFAULT_LANGUGAGECODEFR,
  DEFAULT_LANGUGAGE, LOCAL_STORAGE_USER_LOCALE, LOCAL_STORAGE_USER_LOCALEID
} from '../../../constant/auth-constant';
import { MenuItem } from 'primeng/api';
import { AuthenticationService } from 'src/app/service/authentication.service';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Subject } from 'rxjs';
import { URLService } from 'src/app/service/url.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  pushRightClass: string = 'push-right';
  private langObs$: BehaviorSubject<string> = new BehaviorSubject(null);
  userdetail: any = []
  helplink:string;
  welcomeMessage: string;
  static readonly ROUTE_DATA_BREADCRUMB = 'breadcrumb';
  readonly home = { icon: 'pi pi-home', url: 'Home' };
  menuItems: MenuItem[];
  userlang: string = "Language";
  dataLoadStatus:boolean=false
  lstLanguages: any = [];
  unsubscribe$: Subject<boolean> = new Subject();
  constructor(private translate: TranslateService, private _authService: AuthenticationService,
    public router: Router, private activatedRoute: ActivatedRoute, private headerChangeService: HeaderChangeService,
    private urlService:URLService) {

    this.translate.addLangs(['en', 'fr', 'ur', 'es', 'it', 'fa', 'de','ru','sk','pt', 'zh-CHS']);
    this.translate.setDefaultLang('en');
    const browserLang = this.translate.getBrowserLang();
    this.translate.use(browserLang.match(/en|fr|ur|es|it|fa|de|ru|sk|pt|zh-CHS/) ? browserLang : 'en');

    this.router.events.subscribe(val => {
      if (
        val instanceof NavigationEnd &&
        window.innerWidth <= 992 &&
        this.isToggled()
      ) {
        this.toggleSidebar();
      }
    });
  }

  ngOnInit() {
   
    this.getLanguagelist()
    this.getHelpLink()
    const user: any = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
    const userid: any = LocalStorage.readValue(LOCAL_STORAGE_USER_ID);
    let languageselected: any = LocalStorage.readValue(LOCAL_STORAGE_USER_LOCALE)
   
    if (languageselected != undefined && languageselected != "" && languageselected != null) {
      let langobj=  languageselected.split("_")[0]
      if(langobj!=null && langobj!="" && langobj!=undefined)
        this.translate.use(langobj);
        this.userlang=languageselected
    }
    this.welcomeMessage = user+" - " + userid;

  }

  getLanguagelist() {
    this._authService.getlanguageList().subscribe(
      res => {
        if (res.length > 0) {
          this.lstLanguages = res
        }
      },
      error => {
        console.log(error);
      }
    );
  }
  private createBreadcrumbs(route: ActivatedRoute, url: string = '#', breadcrumbs: MenuItem[] = []): MenuItem[] {

    const children: ActivatedRoute[] = route.children;

    if (children.length === 0) {
      return breadcrumbs;
    }

    for (const child of children) {
      const routeURL: string = child.snapshot.url.map(segment => segment.path).join('/');
      if (routeURL !== '') {
        url += `/${routeURL}`;
      }

      const label = child.snapshot.data[HeaderComponent.ROUTE_DATA_BREADCRUMB];
      if (!(label)) {
        breadcrumbs.push({ label, url });
      }

      return this.createBreadcrumbs(child, url, breadcrumbs);
    }
  }

  isToggled(): boolean {
    const dom: Element = document.querySelector('body');
    return dom.classList.contains(this.pushRightClass);
  }

  toggleSidebar() {
    const dom: any = document.querySelector('body');
    dom.classList.toggle(this.pushRightClass);
  }

  rltAndLtr() {
    const dom: any = document.querySelector('body');
    dom.classList.toggle('rtl');
  }

  onLoggedout() {
    this._authService.logout()
    localStorage.removeItem('isLoggedin');
  }

  changeUserLanguage(langID) {
     this.dataLoadStatus=true                     
    let locale = ""
    let localeid = ""
    localeid = langID
    let dataobj = this.lstLanguages.filter(e => e.LCID == langID)
    locale = dataobj[0].LOCALE

   
    let name = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
    let userid = LocalStorage.readValue(LOCAL_STORAGE_USER_ID);
    let params = { "oTNTQTC10Model": { "USER_ID": userid, "USER_NAME": name, "LOCALE_ID": localeid, "LOCALE_NAME": locale, "USER_CREATION": userid, "USER_MAJ": userid } }
    this._authService.updateUser(params).subscribe(
      res => {
      
        if (res.InsertUserProfileResult) {
          this.getUserDetail(userid)
          this.dataLoadStatus=false  
        }
      },
      error => {
        this.dataLoadStatus=false  
        console.log(error);
      }
    );
  }
 
  /*get user profile*/
  getUserDetail(userid) {
    this._authService.getuser(userid).subscribe(
      res => {
        let data = res.GetUserProfileResult;
      let localeid= data.LOCALE_ID;
      let locale=data.LOCALE_NAME
        if (localeid != undefined && localeid != "" && localeid != null) {
          this.userlang=locale
          let langobj=  locale.split("_")[0]
          if(langobj!=null && langobj!="" && langobj!=undefined)
            this.translate.use(langobj);
           
          }
        this.userdetail._LOCALE_ID = data.LOCALE_ID
        this.userdetail._LOCALE_NAME = data.LOCALE_NAME
        LocalStorage.addItem(LOCAL_STORAGE_USER_LOCALEID, data.LOCALE_ID)
        LocalStorage.addItem(LOCAL_STORAGE_USER_LOCALE, data.LOCALE_NAME)
        this.headerChangeService.toggle();
        this.headerChangeService.setlanguageProfileObs(this.userdetail._LOCALE_NAME)

      },
      error => {
        console.log(error);
        // this.errorMessage = 'Login failed';
      }
    );
  }
  getHelpLink(){
    this.helplink=this.urlService.getHelpLink();
  }
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
