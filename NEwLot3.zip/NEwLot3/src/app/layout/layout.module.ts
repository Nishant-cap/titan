import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';

import {TooltipModule} from 'primeng/tooltip';
import { BreadcrumbComponent } from '../breadcrumb.component';
import { LayoutRoutingModule } from './layout-routing.module';
import { LayoutComponent } from './layout.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import { AuthGuard } from '../shared';
import { UserRoleDirectiveModule } from '../shared/modules/user-role-directive/user-role-directive.module';
import { ProjectRoleModule } from '../shared/modules/project-role/project-role.module';



@NgModule({
    imports: [
        CommonModule,BreadcrumbModule,
        LayoutRoutingModule,
        TranslateModule,
        TooltipModule,
        NgbDropdownModule,
        UserRoleDirectiveModule,ProjectRoleModule
    ],
    declarations: [LayoutComponent, SidebarComponent, HeaderComponent,BreadcrumbComponent],
    
})
export class LayoutModule {}
