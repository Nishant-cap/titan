import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';
import { AuthGuard } from '../guards/auth.guard';

const routes: Routes = [
    {
        path: '', 
        component: LayoutComponent,
        
        children: [
           
            { path: '',redirectTo: 'home', pathMatch: 'prefix' },
            { path: 'home',loadChildren: () => import('./../modules/home/home.module').then(m => m.ProjectModule) ,data: { showSidebar: true,breadcrumb: 'Home',traskey:'Home'} },
            { path: 'project-home/:id',loadChildren: () => import('./../modules/project-home/project-home.module').then(m => m.ProjectHomeModule),data: { showSidebar: true,breadcrumb: 'Project Home',traskey:'Project Home'} },
            { path: 'technicalevents-list', loadChildren: () => import('./../modules/technicalevents/technicalevents.module').then(m => m.TechnicaleventsModule) },
           
        ]   
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule {}
