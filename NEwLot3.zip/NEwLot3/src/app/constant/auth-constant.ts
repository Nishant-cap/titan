export const LOCAL_STORAGE_TOKEN_NAME = 'access_token';
export const LOCAL_STORAGE_USER_NAME = 'newTitan_user';
export const LOCAL_STORAGE_USER_ID = 'newTitan_userId';
export const LOCAL_STORAGE_USER_LOCALE = 'newTitan_userLocale';
export const LOCAL_STORAGE_USER_LOCALEID = 'newTitan_userLoacleId';
export const LOCAL_STORAGE_USER_ROLE="USER_ROLE";
export const ROLE_ADMIN = 'ADMIN';
export const ROLE_RULE_MANAGER = 'RULE_MANAGER';
export const LOCAL_STORAGE_User_LOGGED = 'loggedIn';
export const DEFAULT_STATUS = 'IN PROGRESS';
export const DEFAULT_LANGUGAGE = 'fr_FR';
export const DEFAULT_LANGUGAGECODEENG = 'en';
export const DEFAULT_LANGUGAGECODEFR = 'fr';
export const PROJECT_ID = 'PROJECT_ID';
export const PROJECT_LOCALE = 'PROJECT_LOCALE';
export const IMAGE_SIZE = 10;
export const IMAGE_WIDTH = 170;
export const IMAGE_HEIGHT = 130;
export const RECORD_TYPE_SAVE= "SAVE";
export const RECORD_TYPE_UPDATE = "NEW";
export const PERIMETER_DEFAULT = 200;
export const DIRECTION="left";
export const PROJECT_NAME="Project Name";
export const PROJECT_DESCRIPTION="Project Desc";
export const USER_ROLE="user role";
export const PROJECT_ROLE="Project Role"
export const BORDER_NAV="none";
export const PROJECTDYNAMICNAME="Project Home";
export const FILE_TYPE_XLSX="xlsx";
export const FILE_TYPE_XLS="xls";
export const MAIL_TYPE_TO="TO";
export const MAIL_TYPE_FROM="FROM";
export const MAIL_TYPE_BCC="BCC";
export const MAIL_TYPE_CC="CC"
export const MAIL_TEMPLATE_DEFAULT_VALUE="Synthèse Titan {0}  – {1} : résultats {2} ({3} – {4} – emon : {5})"
export const REPORT_PERIMETER_ISSUE_LIST="ISSUES LIST";
export const UPLOAD_FILE_XLSX_TYPE="xlsx";
export const UPLOAD_FILE_XLS_TYPE="xls";
export const TYPE_PLANNING_KEY="3"
export const TYPE_VEHICLE_KEY="2"
export const TYPE_PARTCONFIGURATION_KEY="1"
export const TYPE_MANUALIMPORT_KEY="5"
export const TYPE_OBJECTIVE_KEY="4"
export const ROLE_EXPERT_PILOT_ID="102"
export const TOOL_HEADER="Tools"
export const LINK_HEADER="Links"
export const TOOL_TYPE_ID="101";
export const LINK_TYPE_ID="102"
export const SEARCH_FIELD_NAME="name"
export const SEARCH_FIELD_ROLE="role"
export const PROJECT_TITLE="Home"
export const enum PROJECT_IMAGE_TYPES {
    PNG = "data:image/png;base64,",
    JPEG="data:image/jpeg;base64,",
    BMP="data:image/bmp;base64,",
   

  }
  // export const REPORT_URL="&rs:Command=Render&ProjetLancementTITANURLSITE="
  // export const REPORT_URL_TEXT="[01 - Projet Lancement TITAN].[URL SITE].&["
  
