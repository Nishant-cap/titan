// import angular specific Modules
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule, ErrorHandler, Injector, APP_INITIALIZER } from '@angular/core';
import { HashLocationStrategy, LocationStrategy,PathLocationStrategy } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EnvService } from './env-service/env.service';

// import angular custom Modules 
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { TokenInterceptor } from './interceptor/token-interceptor';

// import external Modules 
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateService } from '@ngx-translate/core';
import { MaterialModule } from './shared/modules/material/material.module';
//oidc
import { OAuthModule } from 'angular-oauth2-oidc';
import { ConfirmDialogModule, DialogModule } from 'primeng';
import { NgIdleModule } from '@ng-idle/core';
//import { MeasureListComponent } from './modules/measures/measure-list/measure-list.component';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { AppConfig } from './shared/config/app.config';
// AoT requires an exported function for factories
export const createTranslateLoader = (http: HttpClient) => {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
};
 export let apiURL: String="";
export let InjectorInstance: Injector;
export function initializeApp(appConfig: AppConfig) {
 
  return () => appConfig.load();
}

 export function getUrl(appConfig: AppConfig){
  return appConfig.getAppConfig();

}
  
@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    DialogModule,
    CommonModule,
    FormsModule,
    NgIdleModule,
    NgIdleKeepaliveModule,
    OAuthModule.forRoot({
      resourceServer: {
        allowedUrls: [`${apiURL}`],
        
        sendAccessToken: true
      }
    }),
    TranslateModule.forRoot({
      loader: {
          provide: TranslateLoader,
          useFactory: createTranslateLoader,
          deps: [HttpClient]
      }
  }),
    NgbModule
  ],
  //this needs to umcomment to impliment authentications
   // providers: [AuthGuard,TranslateService, EnvService,
   //  {provide:HTTP_INTERCEPTORS, useClass:DefaultOAuthInterceptor, multi:true}`
  // ],
  providers: [AppConfig,
    { provide: APP_INITIALIZER,useFactory: initializeApp,deps: [AppConfig], multi: true}, 
 //OIDC CODE
 {provide:HTTP_INTERCEPTORS, useClass:TokenInterceptor, multi:true},
   TranslateService, EnvService,
   
  ],
 
  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor(private injector: Injector) {
      InjectorInstance = this.injector;
  }
}
