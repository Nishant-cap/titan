import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';

import { TechnicaleventsListComponent } from './modules/technicalevents/technicalevents-list/technicalevents-list.component';

const routes: Routes = [
    { path: '',loadChildren: () => import('./layout/layout.module').then(m => m.LayoutModule) },
   // { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
    { path: 'not-found', loadChildren: () => import('./not-found/not-found.module').then(m => m.NotFoundModule) },
    // { path: '**', redirectTo: 'not-found ' },
   

];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
}) 
export class AppRoutingModule { }
