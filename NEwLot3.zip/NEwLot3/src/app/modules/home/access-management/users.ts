export interface Users {
    ID?: string;
    NOM?: string;
    Roles?: string;
    Projects?: Array<string>;
    Modifiedby?:string;
    ModifiedDate?:string
  
}