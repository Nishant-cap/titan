import { Component, OnInit,ViewChild } from '@angular/core';
import { FormGroup, FormBuilder,Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/api';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Table } from 'primeng/table';
import * as _ from 'node_modules/lodash';
import { AccessManagementService } from 'src/app/service/access-management.service';
import { Users } from '../users';
import { MatOption } from '@angular/material/core';
import { CommonService } from 'src/app/service/common.service';
import { TranslateService } from '@ngx-translate/core';
import { takeUntil } from 'rxjs/operators';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { Subject } from 'rxjs';
import { ROLE_EXPERT_PILOT_ID, SEARCH_FIELD_NAME, SEARCH_FIELD_ROLE } from 'src/app/constant/auth-constant';
import { Role } from 'src/app/shared/model/role';
import { MatSelect } from '@angular/material/select';
import { MatCheckboxChange } from '@angular/material/checkbox';

@Component({
  selector: 'app-access-management',
  templateUrl: './access-management.component.html',
  styleUrls: ['./access-management.component.scss'],
  providers: [MessageService, ConfirmationService],
})
export class AccessManagementComponent implements OnInit {
// @ViewChild('errFilter','errFilter');
@ViewChild('allSelected') private allSelected: MatOption;
public accesform: FormGroup;
rolesList:any[];
usersList:any[];
LDAPUsersList:any[];
isDialogBox: boolean;
projectList:any[];
selectedProject:any=[];
filterUserlist:any[];
filterLDAPUserlist:any[];
userFlag:boolean=true;
enableLoader:boolean=false;

msg:string='view.accessmanagement.deleteMsg';
headerMsg:string='view.accessmanagement.confirmDelete';
acceptMsg:string='view.accessmanagement.acceptMsg';
rejectMsg:string='view.accessmanagement.rejectMsg';

selectedpp:any[];
filterLDAPUser:string;
filterName:string;
filterRole:string;
allProject=[]
selectProject=[]
// @ViewChild('dt','ss') table: Table;

errorRecords: any = [];
selectedRecords: any[] = [];
selectedRecord: any[] = [];
errorMessage: null;

// variable for columns 
cols: any[];
maincols:any[];
// pagination variables
first: number = 0;
page: number;
rows: number = 10;
size: number;

// Filter Variables
loading: boolean;
filterValue = {};

// Date filter variables
extshowDateContainer: boolean = false;
errshowDateContainer: boolean = false;
extfdate: Date;
exttdate: Date;
errfdate: Date;
errtdate: Date;
resultMsg:string;
accessRecords={};
newRecord:boolean=true;
//save parameters

getUserDetailsResult: string;


// Sort Variables
sortData = {} ;
sortResult: string;
userrole:string="";assignproject:string=""
userValidationMsg:string;
validationFlag:boolean=false;
popupLoader:boolean=false;
searchPopupLoader:boolean=false;
userNom:any;
// waring message 
msgs: any[] = [];
editable: boolean = true;
totalNumberRecords:number =0;
datePipe: any;
displayDialog: boolean;
blockedDocument = false;
userLanguage:string;
unsubscribe$: Subject<boolean> = new Subject();
/* user list variable*/
userList:any;
userSearchList:any
userGoalId:any;
displayUserListDialog:boolean;
errorRolevalidation=""
  erroProjectVal=""
searchErorMsg:string
userSearch:string
filteredUsers:any
searchUserField:any[]
user:any;
flag:boolean=false;
searchUserInfoMsg:string;
submitted:boolean=false
selectedRole:any
projectFlag:boolean=true;
@ViewChild('select') select: MatSelect;
  allSelectedProject=false;
  constructor(private fb : FormBuilder,private modalService: NgbModal,private accessservice:AccessManagementService,
    private confirmationService:ConfirmationService,private messageService:MessageService,private commonService:CommonService
    ,private translate:TranslateService,
    private headerService:HeaderChangeService,
    ) { }

  ngOnInit() {
    this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => {
      this.userLanguage=this.commonService.getUserlocaleName()
      this.resultMsg=""
      this.validationFlag=false;
    });
     this.accesform = this.fb.group({
      username: ['',Validators.required],
      userrole: ['',Validators.required],
      assignproject: ['',Validators.required],
      id:['']
     
     });

     this.cols = [
      { field: 'NOM', header: 'UserName' },
      { field: 'Roles', header: 'Role' },
      { field: 'Projects', header: 'Assigned Project' }
     
    ];

    this.maincols=[
      { field: 'USER_GOAL_NAME', header: 'UserName / UserGroup' },
      { field: 'ROLE_DISPLAY_NAME', header: 'Role' },
      { field: 'PROJECT_ID_LIST', header:'Assigned Project' },
      { field: 'USER_MAJ', header: 'Modified By' },
      { field: 'DATE_MAJ', header: 'Modified On' },
    ]

    this.searchUserField = [
      { field: 'DISPLAY_NAME', header: 'Name'},
      { field: 'TITLE', header: 'Title'},
      { field: 'DEPARTMENT', header: 'Department'},
      { field: 'EMAIL', header: 'E-Mail'},
      { field: 'MOBILE_NUMBER', header: 'Mobile Number'},
      { field: 'ACCOUNT_NAME', header: 'Account Name'}
    ];
     this.getRoles();
     this.getProjectList();
     this.getAccessManagementRecords()
    
  }
  /*when click on select all option*/
  toggleAllSelection() {
   
    if (this.allSelectedProject) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }
   optionClick() {
    let newStatus = true;
    this.select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.allSelectedProject = newStatus;
  }
  /*get roles*/
  getRoles()
  {
    
    let req={
      "UserLocale":this.userLanguage
    }
    this.accessservice.getRoleMaster(req).subscribe(  
      (data: any) => {
      this.rolesList = data;
      
    },
    (error: any) => this.errorMessage = <any>error
  );
  }

  /*get project list*/
  getProjectList()
  {
    
    let req={
      "UserLocale":this.userLanguage
    }
    this.accessservice.getProjects(req).subscribe(  
      (data: any) => {
      this.projectList = data;
      
      for(let d of data){
        this.allProject.push(d.ProjectId)
      }
     
    },
    (error: any) => this.errorMessage = <any>error
  );
  }
  
  get f(){return this.accesform.controls;};

  /*get access management records*/
  getAccessManagementRecords()
  {
  
   this.enableLoader=true;
    let reqParam={
      "UserLocale":this.userLanguage
    }
    
    this.accessservice.getAccessManagementTransaction(reqParam).subscribe(  
      (data: any) => {
      this.usersList = data; 
      this.enableLoader=false;
     this.filterUserlist=data;
     //this.filterUserlist.sort((a, b) => new Date(b.DATE_CREATION).getTime() - new Date(a.DATE_CREATION).getTime());
     this.LDAPUsersList=data;
     
    },
    responseError => {
      this.enableLoader = false;
    }
  );
  }

  /*get user popup info details*/
  async searchUserPopupDetails(userGoalId){
    this.getUserDetailsResult=""
    this.filterLDAPUserlist=[]
    this.searchUserInfoMsg=""
    if(!this.filterLDAPUser){
      this.searchUserInfoMsg=this.translate.instant('view.accessmanagement.searchErorMsg');
    }
    else if(this.filterLDAPUser.length<4){ 
      this.searchUserInfoMsg=this.translate.instant('view.accessmanagement.InvalidUserMsg')
    }
    else{
      this.popupLoader=true;
    let reqparams={
      "UserGoalId":userGoalId,
      "UserLocale":this.userLanguage
    }
    await this.accessservice.getUserInfoPopupDetails(reqparams).toPromise().then(
      (data:any)=>{
        this.filterLDAPUserlist=data.lstDisplayAccessManagementDetails;
        if(data.result == false){
          this.getUserDetailsResult = data.Message;
        }else if(data.result == true){
          this.getUserDetailsResult = "";
        }
        
        this.popupLoader=false
      }
    );
    responseError => {
      this.popupLoader = false;
    }
  }}
  /*toaster to show successful and failure msg*/
  showToast(severity, summary, detail) {
    let res= this.translate.instant(summary)
    this.messageService.add({ key: 'tc', severity: severity, summary: res, detail: detail });
  }
/*change event for role*/
  onSelectRole(event){
    const value = event.target.value;
    this.selectedRole=value
    let role=this.rolesList.find(e=>e.ID==this.accesform.controls['userrole'].value).ROLE_NAME
  if(role==Role.ExpertPilot){
      this.selectProject=this.allProject;
      this.allSelectedProject=true
     // this.allSelected.select()
     this.projectFlag=false
 }
 else{ this.selectProject=[]
 this.projectFlag=true
 this.allSelectedProject=false
}
   }


 /* to filter records based on role, username and userId*/
  onFilterChange(fieldname) {
    if(fieldname)
    {
    this.filterUserlist = this.usersList.filter((e) =>e.USER_GOAL_NAME.toLowerCase().includes(this.filterName.toLowerCase()) 
    || e.USER_GOAL_ID.toLowerCase().includes(this.filterName.toLowerCase() ));
    }
    if(!fieldname)
    {
      this.filterUserlist = this.usersList.filter((e) =>e.ROLE_DISPLAY_NAME.toLowerCase().includes(this.filterRole.toLowerCase()));
    }
  }

  /*set form value*/
  formValue() {
  this.accesform.patchValue({ 
    username:this.accessRecords['USER_GOAL_NAME'],
    userrole:this.accessRecords['ROLE_ID'],
    assignproject:this.accessRecords['PROJECT_ID_LIST'],
    id:this.accessRecords['ID']
}); 
    this.accesform.controls['username'].disable()
    let role=this.rolesList.find(e=>e.ID==this.accesform.controls['userrole'].value).ROLE_NAME
    if(role==Role.ExpertPilot){
       this.projectFlag=false
       this.allSelectedProject=true
   }
  
   if(this.accesform.controls['assignproject'].value.length==this.allProject.length){
     this.allSelectedProject=true
   }
}

  /*edit the access management record*/
  editPermission(ID)
  {
    this.validationFlag=false
    this.projectFlag=true;
    this.allSelectedProject=false
    this.newRecord=false;
    this.resultMsg="";
    this.accesform.reset()
    this.enableLoader=true;
    let reqparams={
      "ID":ID,
      "UserLocale":this.userLanguage
    }
     this.accessservice.editAccessmanagementRecordById(reqparams).subscribe(
      (data:any)=>{
       this.accessRecords=data;
       this.enableLoader=false;
       this.formValue() 
      },
      responseError => {
        this.enableLoader = false;
      }
     )   
  }

  /*delete access management record*/
  deleteUserRole(ID) {
    this.validationFlag=false
    this.resultMsg=""
    
    let reqParam={
      "ID":ID,
      "userLocale":this.userLanguage
    }
    this.confirmationService.confirm({
      message: this.translate.instant(this.msg),
      header: this.translate.instant(this.headerMsg),
      icon: 'pi pi-exclamation-triangle',
      acceptLabel:this.translate.instant(this.acceptMsg),
      rejectLabel:this.translate.instant(this.rejectMsg),
        accept: () => {
          
         this.accessservice.deleteAccessManagementRecordsByID(reqParam).subscribe(
          response=>{
            if(response.DeleteAccessManagementRecordByIDResult.result){
              this.resultMsg="";
              this.showToast('success', 'view.accessmanagement.deleteConfirmMsg', '');
              this.getAccessManagementRecords();
             
            }
           else
           this.resultMsg=response.DeleteAccessManagementRecordByIDResult.Message;
           
          }
          );
           
        }
    });
}
/*check user validation before submit*/
async checkUserValidationBeforeSumbit(){

  this.submitted=true
  this.resultMsg=""
  this.userGoalId=""
  this.validationFlag=false;
  let searchtxt=this.accesform.controls['username'].value
  
  if(searchtxt==null || searchtxt==""){
    this.validationFlag=true;
    this.userValidationMsg=this.translate.instant('view.main.validation.required')
  
  }
  else if(searchtxt.length<4){
    this.validationFlag=true
    this.userValidationMsg=this.translate.instant('view.accessmanagement.validationMsg')
  }
  else{
    this.enableLoader=true;
    let reqparams={
      "SearchText":searchtxt,
      "UserLocale":this.userLanguage
    }
   await this.accessservice.getUserAndGoalsBySearchText(reqparams).toPromise().then(
      responseData => {
        if(responseData.RESULT){
        this.userSearchList = responseData.lstUserInfoLDAP;
        this.enableLoader=false;
        if(this.userSearchList.length==1){
        let name=this.userSearchList.find(e=>e.USER_GOAL_ID.toLowerCase()==searchtxt.toLowerCase() || 
        e.DISPLAY_NAME.toLowerCase()==searchtxt.toLowerCase())
        if(name!=undefined && name!=null){
        this.accesform.controls['username'].setValue(name.DISPLAY_NAME)
        this.userGoalId=name.USER_GOAL_ID
        this.onSubmit()}
        else{
          this.validationFlag=true;
          this.userValidationMsg=this.translate.instant('view.accessmanagement.validationMsg')
          this.enableLoader=false;
        }
        }
        else{
          this.validationFlag=true;
          this.userValidationMsg=this.translate.instant('view.accessmanagement.validationMsg')
          this.enableLoader=false;}
        }
        else{
          this.validationFlag=true;
          this.userValidationMsg=this.translate.instant('view.accessmanagement.validationMsg')
          this.enableLoader=false
        }
      },
      responseError => {
        this.enableLoader = false;
       
      });
   
  }}
  /*submit the data after checking user validation*/
  onSubmit()
  {
    if(this.accesform.valid){
    let formdata=this.accesform.value
    if(this.newRecord){
    let reqParams={"saveAccessManagementDetails":{
      "ID":"0",
      "USER_GOAL_ID":this.userGoalId.trim(),
      "ROLE_ID":formdata.userrole,
      "USER_CREATION":this.commonService.getUserID(),
      "USER_MAJ":this.commonService.getUserID(),
      "PROJECT_ID_LIST":formdata.assignproject,
      "userLocale":this.userLanguage
      }
      }
    this.accessservice.saveAccessManagementDetails(reqParams).subscribe(  
      (response: any) => {
      if(response.SaveAccessManagementDetailsResult.result){
        this.getAccessManagementRecords(); 
        this.resultMsg=response.SaveAccessManagementDetailsResult.Message
      }
      else
       this.resultMsg=response.SaveAccessManagementDetailsResult.Message
       
    },
    (error: any) => this.errorMessage = <any>error
  );
    this.resetForm();
    this.projectFlag=true
    this.allSelectedProject=false
  }
  else{
    let reqParams={"saveAccessManagementDetails":{
      "ID":this.accessRecords['ID'],
      "USER_GOAL_ID":this.accessRecords['USER_GOAL_ID'],
      "ROLE_ID":formdata.userrole,
      "USER_CREATION":this.commonService.getUserID(),
      "USER_MAJ":this.commonService.getUserID(),
      "PROJECT_ID_LIST":formdata.assignproject,
      "userLocale":this.userLanguage
      }
      }
    this.accessservice.saveAccessManagementDetails(reqParams).subscribe(  
      (response: any) => {
      if(response.SaveAccessManagementDetailsResult.result){
        this.getAccessManagementRecords();
        this.resultMsg=response.SaveAccessManagementDetailsResult.Message
        this.accessRecords="";
        this.newRecord=true;
      }
      else
       this.resultMsg=response.SaveAccessManagementDetailsResult.Message
       this.newRecord=true;
    },
    (error: any) => this.errorMessage = <any>error
  );
    this.resetForm();
    this.projectFlag=true
    this.allSelectedProject=false
  }
}else{
  return false

}
}

/*to reset the form value*/
  resetForm()
  {
    this.projectFlag=true
    this.allSelectedProject=false
    this.newRecord=true;
    this.validationFlag=false
    this.userFlag=false;
    this.accessRecords="";
    this.accesform.patchValue({
      username:"",
      userrole:"",
      assignproject:""
    });
    this.resultMsg="";
    this.accesform.controls['username'].enable()
  }
  /*userlink info popup*/
  opeModel()
  { this.getUserDetailsResult = "";
    this.searchUserInfoMsg=""
    this.filterLDAPUser=""
    this.filterLDAPUserlist=[]
    this.displayDialog = true;
  }
/*user search list dialog*/
  openUserDailog()
{  
  this.validationFlag=false;
  this.flag=false;
  this.searchErorMsg=""
  this.userSearch=""
  this.displayUserListDialog=true;
  this.userList=null;
}

/*get user list details by search text*/
getUserList(){
  this.userList=null
  this.searchErorMsg="";
    if(!this.userSearch){
      this.searchErorMsg=this.translate.instant('view.accessmanagement.searchErorMsg');
    }
    else if(this.userSearch.length < 4){
      this.searchErorMsg=this.translate.instant('view.accessmanagement.noResultfound');
    }
    else{
     this.searchPopupLoader=true;
    let reqparams={
    "SearchText":this.userSearch,
    "UserLocale":this.userLanguage
  }
  this.accessservice.getUserAndGoalsBySearchText(reqparams).subscribe(
    responseData => {
      if(responseData.RESULT){
      this.userList = responseData.lstUserInfoLDAP;
      this.searchPopupLoader=false;
      }
      else{
        this.searchErorMsg=this.translate.instant('view.accessmanagement.noResultfound');
        this.searchPopupLoader=false;
      }
    }, 
    responseError => {
      this.searchPopupLoader= false;}
  );
}}
/*when double click user data*/
rowSelected(user){
  if(this.newRecord){
  this.accesform.controls['username'].setValue(user.DISPLAY_NAME)}
  this.displayUserListDialog=false;

}
 /* single click user data*/ 
oneClickRow(name){
  this.user=name;
  this.flag=true;
}
/*user pop up add Ok button*/
addUserToForm(){
  if(this.newRecord){
  this.accesform.controls['username'].setValue(this.user)}
  this.displayUserListDialog=false;
}
/*check whether user is existing or not*/
checkUserValidation(){
  this.resultMsg=""
this.validationFlag=false;
let searchtxt=this.accesform.controls['username'].value
if(searchtxt==null || searchtxt==""){
  this.validationFlag=true;
  this.userValidationMsg=this.translate.instant('view.main.validation.required')
}
else if(searchtxt.length<4){
  this.validationFlag=true
  this.userValidationMsg=this.translate.instant('view.accessmanagement.validationMsg')
}
else{
  this.enableLoader=true;
  let reqparams={
    "SearchText":searchtxt,
    "UserLocale":this.userLanguage
  }
  this.accessservice.getUserAndGoalsBySearchText(reqparams).subscribe(
    responseData => {
      if(responseData.RESULT){
      this.userList = responseData.lstUserInfoLDAP;
      this.enableLoader=false;
      if(this.userList.length==1){
      let name=this.userList.find(e=>e.USER_GOAL_ID.toLowerCase()==searchtxt.toLowerCase() ||
      e.DISPLAY_NAME.toLowerCase()==searchtxt.toLowerCase() )
      if(name!=undefined && name!=null){
      this.accesform.controls['username'].setValue(name.DISPLAY_NAME)
      }else{
        this.validationFlag=true;
        this.userValidationMsg=this.translate.instant('view.accessmanagement.validationMsg')
        this.enableLoader=false;
      }
      }
      else{
        this.validationFlag=true;
        this.userValidationMsg=this.translate.instant('view.accessmanagement.validationMsg')
        this.enableLoader=false;}
      }
      else{
        this.validationFlag=true;
        this.userValidationMsg=this.translate.instant('view.accessmanagement.validationMsg')
        this.enableLoader=false
      }
    },
    responseError => {
      this.enableLoader = false;
    });
}}

/*cancel button on user search popup*/
cancelUser()
{
  this.searchErorMsg="";
  this.userSearch=""
  this.displayUserListDialog = false;  
}
/*to unsubscribe from the header change event so that api dont get called when page is not loaded */
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
