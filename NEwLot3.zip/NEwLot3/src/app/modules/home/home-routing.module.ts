import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { Role } from 'src/app/shared/model/role';
import { TechnicaleventsListComponent } from '../technicalevents/technicalevents-list/technicalevents-list.component';
import { AccessManagementComponent } from './access-management/access-management/access-management.component';
import { AdminTagComponent } from './admin-tag/admin-tag.component';
import { PartRepositoryComponent } from './parts-repository/part-repository/part-repository.component';
import { ProjectListComponent } from './project-list/project-list.component';
import { ProjectReportsComponent } from './reports/project-reports/project-reports.component';


const routes: Routes = [
  {
      path: '',component: ProjectListComponent },
  { path: 'admin-tag',  data: { breadcrumb: 'Admin TAG',traskey:'Admin TAG',isProjectPage:false, roles: [ Role.GlobalAdmin ]}, canActivate:[AuthGuard],component:AdminTagComponent},
  { path: 'project-reports', data: { breadcrumb: 'Reports',traskey:'Reports',isProjectPage:false,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ]},canActivate:[AuthGuard],component:ProjectReportsComponent},
  { path: 'parts-repository',data: { breadcrumb: 'Parts Repository',traskey:'Parts Repository',isProjectPage:false,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ] },canActivate:[AuthGuard], component:PartRepositoryComponent},
   { path: 'tech', component:TechnicaleventsListComponent },

  { path: 'access-management',canActivate:[AuthGuard],data: { breadcrumb: 'Access Management',traskey:'Access Management',isProjectPage:false, roles: [ Role.GlobalAdmin ] }, component:AccessManagementComponent}
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectRoutingModule { }
