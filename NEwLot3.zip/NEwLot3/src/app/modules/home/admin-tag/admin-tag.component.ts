import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { AdminTagService } from '../../../service/admin-tag.service';
import { MessageService, ConfirmationService } from 'primeng/api';
import { CommonService } from 'src/app/service/common.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import LocalStorage from 'src/app/util/local-storage';
import * as _ from 'node_modules/lodash';
import { templateJitUrl } from '@angular/compiler';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { Subject } from 'rxjs/internal/Subject';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-admin-tag',
  templateUrl: './admin-tag.component.html',
  styleUrls: ['./admin-tag.component.scss'],
  providers: [MessageService, ConfirmationService]
})
export class AdminTagComponent implements OnInit {
  @ViewChild("content") modalContent: ViewContainerRef;
  dataLoadStatus: boolean = false
  errorRes = '';
  unknownError = false;
  resmessage = ""
  submitted: boolean = false;
  deleteprevioustag: boolean = false;
  msg:string='view.project.deleteMsg';
  headerMsg:string='view.project.confirmDelete';
  acceptMsg:string='view.project.acceptMsg';
  rejectMsg:string='view.project.rejectMsg';
  public adminProjectData: any;
  public adminTagData: any;
  public accesform: FormGroup;
  selectedProject: any;
  selectedTag: any;
  reqParams = {
    "oAdminTagObject": {
      "ProjectName": "",
      "ProjectID": "",
      "TagName": "",
      "TagID": "",
      "ReplaceText": ""
    },
    "userLocale": ""
  }
  errorResvalidation=""
  erroPrevioustag=""
  unsubscribe$: Subject<boolean> = new Subject();
  constructor(
    private _adminService: AdminTagService,
    private translate: TranslateService,
    private commonservice: CommonService,
    private fb: FormBuilder,
    private commonService: CommonService,
    private modalService: NgbModal,
    private headerService: HeaderChangeService,
    private confirmationService: ConfirmationService
  ) {
  }
  /*functiona calls on init of page all the intial calls are done here*/
  ngOnInit() {
    this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => {
      let selectedlanguage = language
      this.accesform = this.fb.group({
        projectList: ['', [Validators.required]],
        projectTag: ['', [Validators.required]],
        newTag: ['']
      });
      this.getProjectList();
      this.getTagList(0)
       this.selectedProject=""
       this.selectedTag=""
       this.erroPrevioustag=""
       this.errorResvalidation=""
       this.resmessage=""
    });
    this.accesform = this.fb.group({
      projectList: ['', [Validators.required]],
      projectTag: ['', [Validators.required]],
      newTag: ['']
    });
    //this.getProjectList();
  }
  
  /* Get Project List Data */
  getProjectList() {
    this.dataLoadStatus = true;
    let param = {
      locale: this.commonService.getUserlocaleName()
    }
    this._adminService.getProjectData(param).subscribe(
      responseData => {
        this.adminProjectData = responseData.GetAdminTagProjectListResult;
        this.dataLoadStatus = false
      },
      responseError => {
        if (responseError.status === 200 && responseError.statusText === 'OK' && responseError.name === 'HttpErrorResponse') {
          this.unknownError = true;
        } else {
          this.errorRes = responseError.status + ' : ' + responseError.statusText;
        }
      }
    );
  }
  /* change event for projects dowpdown */
  public onOptionsSelected(event) {
    this.erroPrevioustag=""
    this.resmessage="";
    const value = event.target.value;
    this.selectedProject = value;
    this.selectedTag = "";
    this.accesform.controls['projectTag'].setValue('');
  if(this.selectedProject && this.selectedProject!=0)
  {
    this.errorResvalidation=""
  }
    this.getTagList(value);
  }
/*change event for tag dropdown*/
  public onTagSelected(event){
    this.resmessage="";
    const value = event.target.value;
    this.selectedTag=value;
    if(this.selectedTag && this.selectedTag!=0){
      this.erroPrevioustag=""
    }
  }

  /* Get Tag List Data */
  public getTagList(value) {
    this.dataLoadStatus = true;
    let param = {
      locale: this.commonService.getUserlocaleName(),
      ProjectId: value,
    }
    this._adminService.getPreviousTag(param).subscribe(
      responseData => {
        this.adminTagData = responseData.GetTagsbyProjectIDResult;
        this.dataLoadStatus = false;
      },
      responseError => {
        if (responseError.status === 200 && responseError.statusText === 'OK' && responseError.name === 'HttpErrorResponse') {
          this.unknownError = true;
        } else {
          this.errorRes = responseError.status + ' : ' + responseError.statusText;
        }
      }
    );
  }
  /*reset the form value*/
  resetTag() {
    this.accesform.patchValue({
      projectList:"",
      projectTag:"",
      newTag:""
    });
    this.erroPrevioustag=""
    this.errorResvalidation=""
    this.selectedProject=""
    this.selectedTag=""
    this.getTagList(0)  
  }

  /*when click on reset button*/
  reset() {
    this.accesform.patchValue({
      projectList:"",
      projectTag:"",
      newTag:""
    });
    this.erroPrevioustag=""
    this.errorResvalidation=""
    this.selectedProject=""
    this.selectedTag=""
    this.getTagList(0) 
    this.resmessage="" 
  }

  /* Get Form Value */
  formValue() {
    this.accesform.patchValue({
      projectList: this.accesform['projectList'],
      projectTag: this.accesform['projectTag'],
      newTag: this.accesform['newTag']
    });
  }

  get f() { return this.accesform.controls; }

  /* when click on save button */
  onSubmit() {
    this.errorResvalidation=""
    this.erroPrevioustag=""
    this.submitted = true;
    if (this.accesform.valid && this.selectedProject!=0 && this.selectedTag!=0) {
      let formvalues = this.accesform.value;
      if (formvalues.newTag == "" && this.deleteprevioustag == false) {
        this.confirmationService.confirm({
          message: this.translate.instant(this.msg),
          header: this.translate.instant(this.headerMsg),
          icon: 'pi pi-exclamation-triangle',
          acceptLabel:this.translate.instant(this.acceptMsg),
          rejectLabel:this.translate.instant(this.rejectMsg),
          accept: () => {
            this.onConfirm();
            this.dataLoadStatus = true;
            var updateData = [];
            let projectObj = this.adminProjectData.filter(val => val.Value == this.selectedProject)
            let projectname = projectObj[0].Key
            let tagObj = this.adminTagData.filter(val => val.Value == formvalues.projectTag)
            let tagname = tagObj[0].Key;
            this.reqParams.oAdminTagObject.ProjectID = this.selectedProject
            this.reqParams.oAdminTagObject.ProjectName = projectname
            this.reqParams.oAdminTagObject.ReplaceText = formvalues.newTag
            this.reqParams.oAdminTagObject.TagID = formvalues.projectTag
            this.reqParams.oAdminTagObject.TagName = tagname
            this.reqParams.userLocale = this.commonService.getUserlocaleName()
            this.selectedTag = tagname
            this._adminService.saveAdmin(this.reqParams).subscribe(
              responseData => {
                if (responseData.SaveAdminTagResult.result) {
                  this.dataLoadStatus = false;
                  this.resmessage = responseData.SaveAdminTagResult.Message;
                  this.getProjectList();
                  this.deleteprevioustag=false
                  this.resetTag(); 
                }
                else {
                  this.resmessage = responseData.SaveAdminTagResult.Message;
                  this.dataLoadStatus = false;
                  this.resetTag();
                  this.deleteprevioustag=false;
                }
              },
              responseError => {
                if (responseError.status === 200 && responseError.statusText === 'OK' && responseError.name === 'HttpErrorResponse') {
                  this.unknownError = true;
                } else {
                  this.errorRes = responseError.status + ' : ' + responseError.statusText;
                }
              }
            );
          }
        }); 
        return false
      }
      else if(formvalues.newTag){
        this.dataLoadStatus = true;
        var updateData = [];
        let projectObj = this.adminProjectData.filter(val => val.Value == this.selectedProject)
        let projectname = projectObj[0].Key
        let tagObj = this.adminTagData.filter(val => val.Value == formvalues.projectTag)
        let tagname = tagObj[0].Key;
        this.reqParams.oAdminTagObject.ProjectID = this.selectedProject
        this.reqParams.oAdminTagObject.ProjectName = projectname
        this.reqParams.oAdminTagObject.ReplaceText = formvalues.newTag
        this.reqParams.oAdminTagObject.TagID = formvalues.projectTag
        this.reqParams.oAdminTagObject.TagName = tagname
        this.reqParams.userLocale = this.commonService.getUserlocaleName()
        this.selectedTag = tagname
        this._adminService.saveAdmin(this.reqParams).subscribe(
          responseData => {
            if (responseData.SaveAdminTagResult.result) {
              this.dataLoadStatus = false;
              this.resmessage = responseData.SaveAdminTagResult.Message;
              this.getProjectList();
              this.resetTag();
            }
            else {
              this.dataLoadStatus = false;
              this.resmessage = responseData.SaveAdminTagResult.Message;
              this.resetTag();
            }
          },
          responseError => {
            if (responseError.status === 200 && responseError.statusText === 'OK' && responseError.name === 'HttpErrorResponse') {
              this.unknownError = true;
            } else {
              this.errorRes = responseError.status + ' : ' + responseError.statusText;
            }
          }
        );   
    return false
      }
    }
    else{
      if(!this.selectedProject || this.selectedProject==0){
    this.errorResvalidation="view.main.validation.required"}
    else if(!this.selectedTag || this.selectedTag==0){
    this.erroPrevioustag="view.main.validation.required"}
    else
    this.errorResvalidation="view.main.validation.required"
    this.erroPrevioustag="view.main.validation.required"
      return false;}
  }

/*when click on delete pop confirm button*/
  onConfirm() {
    this.deleteprevioustag = true
  }
 /* to unsubscribe from the header change event so that api dont get called when page is not loaded*/
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
