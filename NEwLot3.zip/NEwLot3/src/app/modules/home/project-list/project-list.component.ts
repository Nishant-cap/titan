import { Component, ElementRef, OnInit } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/api';
import { ProjectService } from "./../../../service/project.service";
import { Project } from './project';
import { ProjectStatus } from "./projectstatus";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'node_modules/lodash';
import { TranslateService } from '@ngx-translate/core';
import { Role } from "../../../shared/model/role";
import { CommonService } from 'src/app/service/common.service';
import { takeUntil } from 'rxjs/operators';
import { DEFAULT_STATUS, DEFAULT_LANGUGAGE, RECORD_TYPE_UPDATE, RECORD_TYPE_SAVE, DIRECTION, PROJECT_IMAGE_TYPES} from '../../../constant/auth-constant';
import { Router } from '@angular/router';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { ViewChild } from '@angular/core';
import { NameValidator } from 'src/app/shared/validators/name.validator';
import { Subject } from 'rxjs/internal/Subject';
import { SearchNeoPipe } from 'src/app/shared/pipes/search-neo.pipe';




@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.scss'],
  providers: [MessageService, ConfirmationService,SearchNeoPipe],
})
export class ProjectListComponent implements OnInit {
  Role = Role;
  dataLoadStatus: boolean = false
  dialogHeader: string = ""; imageUrl: string = ""
  errorMessage: string; selectedStatus: string = "";
  msg:string='view.project.deleteMsg';
  headerMsg:string='view.project.confirmDelete';
  acceptMsg:string='view.project.acceptMsg';
  rejectMsg:string='view.project.rejectMsg';
  projectList: Project[] = []; filtersprojectList: Project[] = []; projectStatus: ProjectStatus[]; projectDialog: boolean; project: Project;
  submitted: boolean = false; selectedProjects: Project[]; totalNumberRecords: number = 0; languageslist: any[]; lotsSparteProject: any[]
  lotsSparteProjectSelected: any[]; neoProjects: any[]; neoProjectsSelected: any[]; getSingledata: any; newproject: boolean = false;
  editProjectForm: FormGroup; selectedValue: string; selectedImage: any; imageuploadMessage: string; message: string = ""
  closeResult: string; filename: string = 'view.pr.message.static'
  reqParams = {
    "saveProjectDetails": {
      "ID": "", "NOM": "", "I18N_STATUT": "", "URL_SITE": "", "DESC_SITE": "", "USER_CREATION": "", "USER_MAJ": "", "LOCALE": "", "LOCALE_ID": "", "DELETED_BY": "", "DELETED_DATE": "", "currentProjectsNEO": ["", ""], "currentProjectsSparte": [
        "", ""]
    },
    "type": "",
    "userLocale":""
  }
  userole:string;
  displayDialog: boolean;
  selectedNeo:any[]=[]
  selectedSparte:any[]=[]
  isImageValid: boolean = false
  displayErrorDailog:boolean
  @ViewChild('UploadFileInput') uploadFileInput: ElementRef;
  constructor(private projectservice: ProjectService,
     private commonservice: CommonService, private confirmationService: ConfirmationService, private messageService: MessageService
    , private fb: FormBuilder, private modalService: NgbModal, 
    private translate: TranslateService, private headerService: HeaderChangeService,
    private router: Router) {
    this.lotsSparteProjectSelected = []; this.neoProjectsSelected = [];
    this.editProjectForm = this.fb.group({
      title: ['', [Validators.required,NameValidator.cannotContainSpace]],
      lotsparte: [''],
      neoproject: [''],
      description: [''],
      language: [''],
      languageID: [''],
      status: [''],
      ID: [''],
      projectimage: ['']
    });


  }
  param = {
    StatusValue: "1",
    LOCALE: ""
  }
  unsubscribe$: Subject<boolean> = new Subject();

  selectedlanguage:string=""
  /***
   * functiona calls on init of page all the intial calls are done here
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */
  ngOnInit() {
    let userlang=this.commonservice.getUserlocaleName();
    let langobj=  userlang.split("_")[0]
    if(langobj!=null && langobj!="" && langobj!=undefined)
     this.translate.use(langobj)
    this.param.StatusValue="1";
    this.userole=this.commonservice.getUserRole();
    this.headerService.changeLeftpanel(false)
    this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => 
      {this.selectedlanguage = language
      if(this.selectedlanguage!=null && this.selectedlanguage!="" &&this.selectedlanguage!=undefined)
      this.setIntialCalls();
      
    });
     
    this.projectservice.getProjectParameters().subscribe(
      (data: any) => {

      },
      responseError => {
        this.errorMessage=responseError
        console.log(this.errorMessage)
      }
    );
  this.setIntialCalls();

  }
  
   /***
   * Initial calls
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */

  setIntialCalls(){
    this.getAllRecord(this.param);
    this.getMasterData();  
    this.getuserlanguage();
    this.getProjectStatus();                   
  }
    /***
   * gets the project list 
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */

  getAllRecord(param) {
   this.param.StatusValue=param.StatusValue
   this.param.LOCALE=this.commonservice.getUserlocaleName()
    this.dataLoadStatus = true
   
    this.projectservice.getRecords(this.param).subscribe(
      (data: Project[]) => {
     
        this.projectList = data;
        this.filtersprojectList = data;
        this.dataLoadStatus = false;
      },
      responseError => {
        this.dataLoadStatus = false;
        this.errorMessage=responseError
      }
    
    );
  }
    /***
   *to set the user selected lang
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */
getuserlanguage(){
 let userlang= this.commonservice.getUserlocaleName()
 if(userlang!=null && userlang!="" && userlang !=undefined ){
 let langobj=  userlang.split("_")[0];
 if(langobj!=null && langobj!="" && langobj!=undefined)
 this.translate.use(langobj);   
 }
 
 
}
  get f() { return this.editProjectForm.controls; }
 /***
   *function gets called when project status is changed
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */
  sortByProjectStatus(obj) {
    let param = {
      StatusValue: ""
    }
    if (obj.value != "") {
      param.StatusValue = obj.value;
      this.getAllRecord(param);

    }

  }
   /***
   *function gets called when click on project edit button
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */
  editProject(product: Project) {
    this.getMasterData(); 
    this.project = product;
    this.projectDialog = true;
  }
 /***
   *function gets called when click on project edit button
   * Author:Shweta
   * created 08/12/2020
   * updated:05/04/2021
   */
  getProjectStatus() {
    let param = {
      LOCALE: this.commonservice.getUserlocaleName()
    }
    this.projectservice.getProjectStatus(param).subscribe(
      (data: ProjectStatus[]) => {
        this.projectStatus = data;
   
        if (this.projectStatus.length > 0)
          this.editProjectForm.patchValue({
            status: this.projectStatus[0].I18N_CODE_VALEUR,

          });
      },
      responseError => {
        this.errorMessage=responseError
        console.log(this.errorMessage)
      }
    );
  }
/***
   *gets all the master data for  create project
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */
  getMasterData() {
  
    this.projectservice.getMasterData().subscribe(
      (data: any) => {
        this.languageslist = data.lstLanguages;
        this.neoProjects = _.map(data.lstNeoProjects, function (element) {
          return _.extend({}, element, { selected: false });
        });
        this.lotsSparteProject = data.lstNeoProjects
        this.lotsSparteProject = _.map(data.lstSparteProjects, function (element) {
          return _.extend({}, element, { selected: false });
        })
      },
      responseError => {
        this.errorMessage=responseError
        console.log(this.errorMessage)
      }
    );
  }
  /***
   *gets all the master data for edit  project
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */
  getMasterDataEdit( projectId) {
    this.dataLoadStatus = true;
    this.projectservice.getMasterData().subscribe(
      (data: any) => {
        this.dataLoadStatus = false;
        this.languageslist = data.lstLanguages;
        this.neoProjects = _.map(data.lstNeoProjects, function (element) {
          return _.extend({}, element, { selected: false });
        });
        this.lotsSparteProject = data.lstNeoProjects
        this.lotsSparteProject = _.map(data.lstSparteProjects, function (element) {
          return _.extend({}, element, { selected: false });
        })
        this.getprojectDetail(projectId);
      },

      responseError => {
        this.errorMessage=responseError
        console.log(this.errorMessage)
      }
    );
  }
  /***
   *to do
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */
  confirmationBox(product: Project) {
    this.confirmationService.confirm({
      message: this.translate.instant(this.msg),
      header: this.translate.instant(this.headerMsg),
      icon: 'pi pi-exclamation-triangle',
      acceptLabel:this.translate.instant(this.acceptMsg),
      rejectLabel:this.translate.instant(this.rejectMsg),
      accept: () => {
        this.projectList = this.projectList.filter(val => val.ProjectId !== product.ProjectId);
        this.project = {};
        this.messageService.add({ severity: 'success', summary: 'Successful', detail: 'Product Deleted', life: 3000 });
      }
    });
  }
  deleteRecord() {

  }
  /***
   *model pop up on create project
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */
  createNewProject(user) {
    this.selectedSparte=[]
    this.selectedNeo=[]
    this.getMasterData(); 
    this.displayDialog = true;
    this.filename = 'view.pr.message.static'
    this.imageUrl = ""
    this.message = "",
      this.dialogHeader = "view.project.headeradd"
    this.imageuploadMessage = ""
    this.submitted = false;
    this.newproject = true
    this.editProjectForm.reset();
    this.neoProjectsSelected = [];
    this.lotsSparteProjectSelected = [];
    if(this.editProjectForm.get("language").value!=DEFAULT_LANGUGAGE){
      let langObj = this.languageslist.filter(el => el.Key == DEFAULT_LANGUGAGE)
     
      if (langObj.length > 0)
        this.editProjectForm.patchValue({
          languageID: langObj[0].Value,
          language: langObj[0].Key
        });
      }
    this.getProjectStatus();
  }
  /***
   *model pop up on edit project
   * Author:Shweta
   * created 08/12/2020
   * updated:
   */
  editModal( project) {
    this.selectedNeo=[]
    this.selectedSparte=[]
    this.displayDialog = true;
    this.dialogHeader = "view.project.headeredit"
    this.filename = 'view.pr.message.static'
    this.imageuploadMessage = ""
    this.message = "";
    this.submitted = false;
    this.newproject = false
    this.editProjectForm.reset();
    this.neoProjectsSelected = [];
    this.lotsSparteProjectSelected = [];
    this.getMasterDataEdit( project.ProjectId);
    this.getProjectStatus();


  }
  /***
   *Image upload
   * Author:Shweta
   * created 08/12/2020
   * updated:26 feb 2021 update for removing theimage validation for size and dimenstions
   */
  selectImage(event) {
    this.selectedImage = event.target.files;
    this.filename = event.target.files[0].name
    this.imageuploadMessage = ""
      this.processImage();
  }
 /***
   *Image upload -to check the image validation
   * Author:Shweta
   * created 08/12/202008/12/2020
   * updated:
   */
  processImage() {
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const image = new Image();
      image.src = e.target.result;
      image.onload = rs => {
       this.isImageValid=true
      };
    };
    reader.readAsDataURL(this.selectedImage[0]);

  }

 
  saveImageAttachment(projectId) {
   
    let filedata: File = this.selectedImage[0];
    let fileReader: FileReader = new FileReader();
    fileReader.onloadend = (e) => {
      let reqParams =
      {
        "projectImageModel":
          { "ProjectID": "", "Image": "", "FileName": "" }
      }
      let jsonData = JSON.stringify(fileReader.result).replace(PROJECT_IMAGE_TYPES.PNG, "").replace(PROJECT_IMAGE_TYPES.JPEG, "").replace(PROJECT_IMAGE_TYPES.BMP,"")
      reqParams.projectImageModel.ProjectID = projectId
      reqParams.projectImageModel.FileName = this.selectedImage[0].name
      reqParams.projectImageModel.Image = JSON.parse(jsonData)
      this.projectservice.saveProjectImage(reqParams).subscribe((response :any)=> {
        let result = response
        
      },
      responseError => {
        this.dataLoadStatus = false;
        this.errorMessage=responseError
      }
      )

    }
    fileReader.readAsDataURL(filedata);

  }
 
 
/***
   * get project details when clicled on edit passing project id
   * Author:Shweta
   * created 08/12/202008/12/2020
   * updated:
   */

  getprojectDetail(projectId) {
    this.dataLoadStatus = true;
    let param = {
      projectId: projectId
    }
    this.projectservice.getprojectDetail(param).subscribe(
      (data: any) => {
        this.getSingledata = data;
        this.dataLoadStatus = false;
        if (data.currentProjectsNEO.length > 0) {
          this.neoProjects = this.neoProjects.filter(o => o != data.currentProjectsNEO)
          this.neoProjectsSelected = data.currentProjectsNEO
        }
        if (data.currentProjectsSparte.length > 0) {
          this.lotsSparteProject = this.lotsSparteProject.filter(o => o != data.currentProjectsSparte)
          this.lotsSparteProjectSelected = data.currentProjectsSparte
        }
        if(!_.isNil(this.getSingledata.ProjectData))
        {
        this.editProjectForm.patchValue({
          title: this.getSingledata.ProjectData.NOM,
          description: this.getSingledata.ProjectData.DESC_SITE,
          language: this.getSingledata.ProjectData.LOCALE!=null ? this.getSingledata.ProjectData.LOCALE:DEFAULT_LANGUGAGE,
          languageID: this.getSingledata.ProjectData.LOCALE_ID!=null ? this.getSingledata.ProjectData.LOCALE_ID: this.languageslist.find(x => x.Key ==DEFAULT_LANGUGAGE ).Value,
          status: this.getSingledata.ProjectData.I18N_STATUT,
          projectimage: this.getSingledata.ProjectData.PROJECT_IMAGE_URL,
          ID: this.getSingledata.ProjectData.ID
        });
        this.imageUrl = this.getSingledata.ProjectData.PROJECT_IMAGE_URL
      }
      this.dataLoadStatus = false;
    },
      responseError => {
        this.dataLoadStatus = false;
        this.errorMessage=responseError
      }
    );
  }

/***
   * calls on submit button of create project to save or update project
   * Author:Shweta
   * created 08/12/202008/12/2020
   * updated:05/04/2021
   */
  submitForm() {
    this.submitted = true;
    if (this.editProjectForm.valid) {
     
      this.dataLoadStatus = true
      let lotData = []; let neoData = [];
      if (this.neoProjectsSelected.length > 0) {
        this.neoProjectsSelected.forEach(element => {
          neoData.push(element.Key)
        });
      }
      if (this.lotsSparteProjectSelected.length > 0) {
        this.lotsSparteProjectSelected.forEach(element => {
          lotData.push(element.Key)
        });
      }
   
      let formdata = this.editProjectForm.value
      this.reqParams.saveProjectDetails.ID = formdata.ID != null ? formdata.ID : 0
      this.reqParams.saveProjectDetails.URL_SITE = formdata.title
      this.reqParams.saveProjectDetails.USER_MAJ = this.commonservice.getUserID()
      this.reqParams.saveProjectDetails.NOM = formdata.title
      this.reqParams.saveProjectDetails.DESC_SITE = formdata.description
      this.reqParams.saveProjectDetails.I18N_STATUT = formdata.status!=null ? formdata.status:"1"
      this.reqParams.saveProjectDetails.LOCALE = formdata.language
      this.reqParams.saveProjectDetails.currentProjectsNEO = neoData
      this.reqParams.saveProjectDetails.currentProjectsSparte = lotData
      this.reqParams.userLocale=this.commonservice.getUserlocaleName()
      if (formdata.status == 0)//closed status
      {
        this.reqParams.saveProjectDetails.DELETED_BY = this.commonservice.getUserID()
      }
      if (this.newproject) {
        this.reqParams.type = RECORD_TYPE_UPDATE
        this.reqParams.saveProjectDetails.USER_CREATION = this.commonservice.getUserID()
        this.reqParams.saveProjectDetails.LOCALE_ID = this.languageslist.find(x => x.Key == formdata.language).Value
      }
      else {
        this.reqParams.type = RECORD_TYPE_SAVE
        this.reqParams.saveProjectDetails.USER_CREATION = ""
        this.reqParams.saveProjectDetails.LOCALE_ID =this.languageslist.find(x => x.Key == formdata.language).Value
      }
      
      this.projectservice.updateProject(JSON.stringify(this.reqParams)).subscribe(
        (data: any) => {
          if (data.SaveProjectDetailsResult.result) {
            this.displayDialog = false;
            let res=data.SaveProjectDetailsResult
            if (this.isImageValid){
              this.saveImageAttachment(res.ID)
            }
            this.message = data.SaveProjectDetailsResult.Message;
            this.getProjectStatus();
            
         
            if (this.projectStatus.length > 0)
              this.selectedStatus = this.projectStatus[0].I18N_CODE_VALEUR
              this.param.StatusValue=this.selectedStatus
            this.getAllRecord(this.param);
            this.dataLoadStatus = false
            this.filename = 'view.pr.message.static'
            if (this.newproject) {
            this.showToast('success', 'view.projectlist.createdMsg', '');
            let projectParams={"ProjectId":res.ID,"Title":res.ProjectName,"ProjectLocale":this.reqParams.saveProjectDetails.LOCALE
          ,"ProjectDesc":res.ProjectDesc,"ProjectLevelRole":res.ProjectLevelRole};
            
            this.projectInternalNavigation(projectParams)
            }
            else
            {
            this.showToast('success', 'view.projectlist.updatedMsg', '');
            }
          
            
          }
          else {
            this.message = data.SaveProjectDetailsResult.Message
            this.dataLoadStatus = false
          }
        },
        responseError => {
          this.dataLoadStatus = false;
         
        }
      );
      return true;
    }
    else {
      return false;
    }

  }
/***
   * toaster to show message of success and failure
   * Author:Shweta
   * created 08/12/202008/12/2020
   * updated:
   */
  showToast(severity, summary, detail) {
    let res= this.translate.instant(summary)
    this.messageService.add({ key: 'tc', severity: severity, summary: res, detail: detail });
  }
  

/***
   * on click of project name user is navigated to project-home 
   * Author:Shweta
   * created 08/12/202008/12/2020
   * updated:
   */
  projectInternalNavigation(obj) {

    if (obj.ProjectId> 0) {
      this.commonservice.setProjectId(obj.ProjectId)
        this.commonservice.setProjectName(obj.Title)
         this.commonservice.setProjectDescription(obj.ProjectDesc)
         console.log("ProjectLevelRole",obj.ProjectLevelRole)
        this.headerService.setlanguageProfileObs(obj.ProjectLocale)
        if(obj.ProjectLocale!=null && obj.ProjectLocale!=undefined && obj.ProjectLocale!=""){
          this.commonservice.setProjectLocale(obj.ProjectLocale)
        let langobj=  obj.ProjectLocale.split("_")[0];
        if(langobj!=null && langobj!="" && langobj!=undefined)
        this.translate.use(langobj);   
        }
        let userIsadmin= this.commonservice.getUserRole();
        if(userIsadmin.toLocaleLowerCase()==Role.GlobalAdmin.toLocaleLowerCase() && !obj.ProjectLevelRole){
        this.commonservice.setProjectRole(Role.GlobalAdmin)
        }
        else
        {
          this.commonservice.setProjectRole(obj.ProjectLevelRole)
        }
        
        //let val=this.commonservice.encrypt(obj.ProjectId)
       
        this.router.navigate(['/project-home',obj.ProjectId]);
       
        // else
        // this.displayErrorDailog=true
    }
  }

  
/***
   * list operations on neo and sparte
   * Author:Shweta
   * created 08/12/202008/12/2020
   * updated:
   */
  public toggleSelection(item, list) {
    item.selected = !item.selected;
  }
/***
   * list operations on neo and sparte
   * Author:Shweta
   * created 08/12/202008/12/2020
   * updated:
   */
  public moveLotsProjectSelected(direction) {

    if (direction === DIRECTION) {
      this.lotsSparteProjectSelected.forEach(item => {
        if (item.selected) {
          this.lotsSparteProject.push(item);

        }
      });
      this.lotsSparteProjectSelected = this.lotsSparteProjectSelected.filter(i => !i.selected);
      this.lotsSparteProject.forEach(data => data.selected = false);

    } else {
      this.lotsSparteProject.forEach(item => {
        if (item.selected) {
          this.lotsSparteProjectSelected.push(item);

        }
      });
      this.lotsSparteProject = this.lotsSparteProject.filter(i => !i.selected);
      this.lotsSparteProjectSelected.forEach(data => data.selected = false);
    }
  }
  /***
   * list operations on neo and sparte
   * Author:Shweta
   * created 08/12/202008/12/2020
   * updated:
   */
  public moveSelected(direction) {
    if (direction === DIRECTION) {
      this.neoProjectsSelected.forEach(item => {
        if (item.selected) {
          this.neoProjects.push(item);
        }
      });
      this.neoProjectsSelected = this.neoProjectsSelected.filter(i => !i.selected);
      this.neoProjects.forEach(data => data.selected = false);
    } else {
      this.neoProjects.forEach(item => {
        if (item.selected) {
          this.neoProjectsSelected.push(item);
        }
      });
      this.neoProjects = this.neoProjects.filter(i => !i.selected);
      this.neoProjectsSelected.forEach(data => data.selected = false);
    }
  }
  /***
   * to unsubscribe from the header change event so that api dont get called when page is not loaded 
   * Author:Shweta
   * created 08/12/202008/12/2020
   * updated:
   */
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
  
  cancel() {
    
    this.displayDialog = false;
    this.dataLoadStatus = false;
  }
}
