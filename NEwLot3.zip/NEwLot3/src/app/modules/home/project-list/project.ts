export interface Project {
    Title?:string;
    ProjectId?:string;
    Url?:string;
    description?:string;
    Status?:string;
    StatusCode?:string;
  
}