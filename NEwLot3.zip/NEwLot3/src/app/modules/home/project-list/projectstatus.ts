export interface ProjectStatus {
  CODE_VALEUR_ALTIS: string,
  CODE_VALEUR_PLM: string,
  I18N_CODE_VALEUR: string,
  LIBELLE: string,
  LOCALE: string,
  REFERENTIEL: string
  };