import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-project',
  templateUrl: './manage-project.component.html',
  styleUrls: ['./manage-project.component.scss']
})
export class ManageProjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
