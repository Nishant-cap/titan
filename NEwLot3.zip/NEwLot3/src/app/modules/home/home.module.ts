import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectRoutingModule } from './home-routing.module';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import {CalendarModule} from 'primeng/calendar';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {TooltipModule} from 'primeng/tooltip';
import {ToastModule} from 'primeng/toast';
import {DialogModule} from 'primeng/dialog';
import {ToolbarModule} from 'primeng/toolbar';
// import {DropdownModule} from 'primeng/dropdown';

import { ProjectListComponent } from './project-list/project-list.component';
import { TranslateModule } from '@ngx-translate/core';
import {CardModule} from 'primeng/card';
import { MaterialModule } from 'src/app/shared/modules/material/material.module';


//mat
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatBadgeModule} from '@angular/material/badge';
import {MatBottomSheetModule} from '@angular/material/bottom-sheet';
import {MatButtonModule} from '@angular/material/button';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatCardModule} from '@angular/material/card';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatChipsModule} from '@angular/material/chips';
import {MatStepperModule} from '@angular/material/stepper';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatDialogModule} from '@angular/material/dialog';
import {MatDividerModule} from '@angular/material/divider';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatListModule} from '@angular/material/list';
import {MatMenuModule} from '@angular/material/menu';
import {MatNativeDateModule, MatRippleModule} from '@angular/material/core';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatRadioModule} from '@angular/material/radio';
import {MatSelectModule} from '@angular/material/select';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatSliderModule} from '@angular/material/slider';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatSortModule} from '@angular/material/sort';
import {MatTableModule} from '@angular/material/table';
import {MatTabsModule} from '@angular/material/tabs';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatTreeModule} from '@angular/material/tree';
import { SharedPipesModule } from 'src/app/shared/pipes/shared-pipes.module';
import { ProjectReportsComponent } from './reports/project-reports/project-reports.component';
import { AdminTagComponent } from './admin-tag/admin-tag.component';
import { PartRepositoryComponent } from './parts-repository/part-repository/part-repository.component';
import { AccessManagementComponent } from './access-management/access-management/access-management.component';
import { UserRoleDirectiveModule } from 'src/app/shared/modules/user-role-directive/user-role-directive.module';
import { SearchNeoPipe } from 'src/app/shared/pipes/search-neo.pipe';
import { SearchSpartePipe } from 'src/app/shared/pipes/search-sparte.pipe';


@NgModule({
 
  imports: [
    CommonModule,
    ProjectRoutingModule,
    SharedPipesModule,
     TableModule,
    ButtonModule,FormsModule ,ReactiveFormsModule,
    PaginatorModule,
    CalendarModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    DialogModule,
    ToolbarModule,
    CardModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    UserRoleDirectiveModule
  ],
  declarations: [ProjectListComponent, ProjectReportsComponent,AdminTagComponent, PartRepositoryComponent,SearchNeoPipe,SearchSpartePipe, AccessManagementComponent],
 
  
})
export class ProjectModule { }
