import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartRepositoryComponent } from './part-repository.component';

describe('PartRepositoryComponent', () => {
  let component: PartRepositoryComponent;
  let fixture: ComponentFixture<PartRepositoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartRepositoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartRepositoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
