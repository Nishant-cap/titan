import { Component, OnInit, ViewChild, ElementRef, ViewContainerRef } from '@angular/core';
import { ProjectService } from '../../../../service/project.service'
import {FileUploadModule} from 'primeng/fileupload';
import { TranslateService } from '@ngx-translate/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import * as _ from 'lodash';
import { PartRepositoryService } from '../../../../service/part-repository.service';
import { Observable, Subject } from 'rxjs';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from 'src/app/service/common.service';
import { saveAs } from "file-saver";
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { takeUntil } from 'rxjs/operators';
import { FILE_TYPE_XLS, FILE_TYPE_XLSX } from 'src/app/constant/auth-constant';
// import { HeaderChangeService } from 'src/app/service/header-change.service';

@Component({
  selector: 'app-part-repository',
  templateUrl: './part-repository.component.html',
  styleUrls: ['./part-repository.component.scss'],
  providers: [FileUploadModule]
})
export class PartRepositoryComponent implements OnInit {
  @ViewChild('UploadFileInput') uploadFileInput: ElementRef;
  dialogHeader:string="";
  fileInputLabel: string;
  selectedFiles: FileList;
  value:any
  resultForm = {
    successfullRecord: "",
    UploadedDate:"",
    filename: "",
    failedRecord: ""
  }
  dateFlag:boolean=false
  isUloadEnable:boolean=true
  dataLoadStatus:boolean=false
  progressInfos = [];
  message ={"message":"","filename":""} ;
  recentUploadID:number=0
  fileInfos: Observable<any>;
  reqParams = {
    "partConfigurationUpload":
    {
      "FileName": "",
      "UserName": "",
      "FileData": "",
      "UploadType": "HomePage",
      "UserLocale":""
    }
  }
  langChange:false
  filename: string = 'view.pr.message.static'
  @ViewChild("content") modalContent: ViewContainerRef;
 userLanguage:string;
  fileToUpload: File = null;
  unsubscribe$: Subject<boolean> = new Subject();
  constructor(private service: ProjectService, private http: HttpClient,
    private uploadService: PartRepositoryService,
    private formBuilder: FormBuilder,
    private modalService: NgbModal,
    private translate: TranslateService,
    private commanService: CommonService,
    private headerService:HeaderChangeService
  ) { }
/* functiona calls on init of page all the intial calls are done here*/
  ngOnInit(): void {
    this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => {
      this.message.message="";
      this.message.filename="";
      this.value=undefined;
    this.filename='view.pr.message.static'
      this.isUloadEnable=true;
    this.userLanguage=this.commanService.getUserlocaleName()
    });
    this.userLanguage=this.commanService.getUserlocaleName()
  }
/*select file to upload*/
  selectFiles(event) {
    this.progressInfos = [];
    this.selectedFiles = event.target.files;
    let af = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel']
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.filename = event.target.files[0].name
      if (!_.includes(af, file.type)) {
        this.message.message = 'view.pr.message.validation';
        this.isUloadEnable=true
      }
      else{
        this.message.message="";
        this.message.filename="";
        this.isUloadEnable=false
      } 
    }}
/*upload call */
  uploadFiles() {
    this.message.message = '';this.message.filename=""
    for (let i = 0; i < this.selectedFiles.length; i++) {
      this.upload(i, this.selectedFiles[i]);
    }
  }
  /* upload file for part configuration */
  upload(idx, file) {
    this.dateFlag=false
    this.dataLoadStatus=true
    this.resetModalData()
    let encryptData;
    this.progressInfos[idx] = { value: 0, fileName: file.name };
    let filedata: File = file;
    let fileReader: FileReader = new FileReader();
    fileReader.onloadend = (e) => {
    encryptData = fileReader.result;
      let jsonData = JSON.stringify(fileReader.result).replace("data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,", "").replace("data:application/vnd.ms-excel;base64,","")
      this.reqParams.partConfigurationUpload.FileData = JSON.parse(jsonData)
      this.reqParams.partConfigurationUpload.FileName = file.name ? file.name : ""
      this.reqParams.partConfigurationUpload.UploadType = "HomePage";
      this.reqParams.partConfigurationUpload.UserLocale=this.userLanguage;
      this.reqParams.partConfigurationUpload.UserName = this.commanService.getUserID()
      this.uploadService.uploadFile(this.reqParams).subscribe(
        response => {
          if (response.UploadPartConfigMainResult.ServiceStatus) {
            this.resultForm.filename = this.filename
            this.resultForm.failedRecord = response.UploadPartConfigMainResult.Failed_Records
            this.resultForm.successfullRecord = response.UploadPartConfigMainResult.Inserted_Records +response.UploadPartConfigMainResult.Updated_Records 
            this.recentUploadID=response.UploadPartConfigMainResult.UploadID
            this.dataLoadStatus=false;
            this.dialogHeader = 'Upload Status';
            this.opeModel()
            this.filename = 'view.pr.message.static'
            this.uploadFileInput.nativeElement.value = null
            this.isUloadEnable=true
          }
          else{
            this.dataLoadStatus=false
            this.message.message =response.UploadPartConfigMainResult.StatusLog 
            this.message.filename="";
            this.isUloadEnable=false
          }
        },
        err => {
          this.dataLoadStatus=false
          this.progressInfos[idx].value = 0;
          this.message.message = "view.pr.message.uploaderror" 
          this.message.filename=file.name; 
        });
    }
    fileReader.readAsDataURL(filedata);
  }
/* call on export button  */
  export() {
    this.dateFlag=true
    this.message.message="";
    this.filename=""
    this.isUloadEnable=true;
    this.value=undefined
      this.dataLoadStatus=true
      this.resetModalData()
      let req =
      {
        "partConfigurationExport":
        {
          "UserName": this.commanService.getUserID(),
          "UserLocale":this.userLanguage
        }
      }
      this.uploadService.export(req).subscribe(
        response => {
          if (response.ExportPartConfigurationMainResult.ServiceStatus) {
            this.resultForm.filename = response.ExportPartConfigurationMainResult.FileName!=null?response.ExportPartConfigurationMainResult.FileName:""
            this.resultForm.UploadedDate=response.ExportPartConfigurationMainResult.UploadedDate!=null?response.ExportPartConfigurationMainResult.UploadedDate:""
            this.resultForm.failedRecord = response.ExportPartConfigurationMainResult.Failed_Records !=null?response.ExportPartConfigurationMainResult.Failed_Records:""
            this.resultForm.successfullRecord = response.ExportPartConfigurationMainResult.Inserted_Records + response.ExportPartConfigurationMainResult.Updated_Records
            if(response.ExportPartConfigurationMainResult.FileData!=null && response.ExportPartConfigurationMainResult.FileName!=null) 
            this.convertToXl(response.ExportPartConfigurationMainResult.FileData,response.ExportPartConfigurationMainResult.FileName)
              this.dataLoadStatus=false;
              this.dialogHeader = 'Export Status';
              this.opeModel()
              this.filename = 'view.pr.message.static'
              this.uploadFileInput.nativeElement.value = "";
          }
          else{
            this.dataLoadStatus=false
            this.message.message=response.ExportPartConfigurationMainResult.StatusLog
            this.message.filename=""
          }
        },
        err => {
          this.dataLoadStatus=false
          this.message.message="view.pr.message.exporterror"
          this.message.filename=""
          console.log(JSON.stringify(err))
        }); 
  }
  /*check file extension */
  checkFileExtension(filename){
    if(filename!=null){
    let extn = filename.split(".").pop();
    if (extn == FILE_TYPE_XLSX){
      return true
    }
    else if( extn == FILE_TYPE_XLS){
      return false
    }
  }
  }
     /* call on export all button  */
  exportAll() {
    this.dateFlag=false
    this.message.message="";
    this.filename=""
    this.isUloadEnable=true;
    this.value=undefined
    this.resetModalData()
    this.dataLoadStatus=true
    let req =
    {
      "partConfigurationExport":
      {
        "UserName": this.commanService.getUserID(),
        "UserLocale":this.userLanguage
      }
    }
    this.uploadService.exportAll(req).subscribe(
      response => {
        if (response.ExportAllPartConfigurationMainResult.ServiceStatus) {
          this.resultForm.filename = response.ExportAllPartConfigurationMainResult.FileName!=null?response.ExportAllPartConfigurationMainResult.FileName:""
           this.resultForm.failedRecord = response.ExportAllPartConfigurationMainResult.Failed_Records!=null?response.ExportAllPartConfigurationMainResult.Failed_Records:0
           this.resultForm.successfullRecord = (response.ExportAllPartConfigurationMainResult.Inserted_Records + response.ExportAllPartConfigurationMainResult.Updated_Records)
         if(response.ExportAllPartConfigurationMainResult.FileData!=null && response.ExportAllPartConfigurationMainResult.FileName!=null)
           this.convertToXl(response.ExportAllPartConfigurationMainResult.FileData,response.ExportAllPartConfigurationMainResult.FileName)
          this.dataLoadStatus=false;
          this.dialogHeader = 'Export All Status';
          this.opeModel()
        }
        else{
          this.dataLoadStatus=false
          this.message.message=response.ExportAllPartConfigurationMainResult.StatusLog
          this.message.filename=""
        }
      },
      err => {
        this.message.message="view.pr.message.exporallerror"
        this.message.filename=""
        this.dataLoadStatus=false
        console.log(JSON.stringify(err))
      });
  }
   /* open  Model pop up  */
  opeModel() {
    this.modalService.open(this.modalContent, {
      centered: true,
      backdrop: 'static', size: 'm'
    });
  }
  /* empty data array  */
  resetModalData() {
    this.resultForm = {
      successfullRecord: "",
      UploadedDate:"",
      filename: "",
      failedRecord: ""
    }
  }
  /* convert base64 string to file  */
  convertToXl(dataURI,filename) {
    let isxlxs=false
     isxlxs=this.checkFileExtension(filename)
    let downloadFiletype= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      int8Array[i] = byteString.charCodeAt(i);
    }
    if(isxlxs)
    downloadFiletype= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      else
      downloadFiletype='application/vnd.ms-excel'
    const blob = new Blob([int8Array], { type: downloadFiletype});    
    saveAs(blob, filename);
 }
/* to unsubscribe from the header change event so that api dont get called when page is not loaded */
 ngOnDestroy() {
  this.unsubscribe$.next(true);
  this.unsubscribe$.complete();
}
}
