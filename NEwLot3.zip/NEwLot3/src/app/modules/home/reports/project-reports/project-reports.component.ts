import { Component,ElementRef, OnInit,ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ProjectReportService } from '../../../../service/project-report.service';
import { MessageService,ConfirmationService } from 'primeng/api';
import * as _ from 'node_modules/lodash';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from 'src/app/service/common.service';
import { formatDate } from '@angular/common';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message'
import { RECORD_TYPE_SAVE, RECORD_TYPE_UPDATE, PERIMETER_DEFAULT, REPORT_PERIMETER_ISSUE_LIST } from 'src/app/constant/auth-constant';
import { NameValidator } from 'src/app/shared/validators/name.validator';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs/internal/Subject';
import { Router } from '@angular/router';
import { Role } from 'src/app/shared/model/role';

@Component({
  selector: 'app-project-reports',
  templateUrl: './project-reports.component.html',
  styleUrls: ['./project-reports.component.scss'],  
  providers: [MessageService, ConfirmationService],
})
export class ProjectReportsComponent implements OnInit {
  Role = Role;
  dataLoadStatus = '';    
  errorRes = '';
  errorMessage:string;
  userForm: FormGroup;
  unknownError = false;
  blockedDocument = false;
  reportData = [];
  msg:string='view.project.deleteMsg';
  headerMsg:string='view.project.confirmDelete';
  acceptMsg:string='view.project.acceptMsg';
  rejectMsg:string='view.project.rejectMsg';
  cols: any[];
  projectReportData = {};
  dialogHeader;
  selectColReportData: any;
  saveAction = 'Save';
  deleteAction = 'Delete';
  displayDialog: boolean;
  addReportData : boolean;
  modi_data : any[];
  languageslist:any[];
  perimeterlist:any[];
  projectstatuslist:any[];
  STATUS:any[];
  newproject:boolean=false;
  projectStatus: [];
  userLanguage:any;
  message:string="";
  intValue: number = 1;
  IS_STANDARD : any;
  PERIMETER_NAME ="";
  LOCALE="";
  COMMENTS ="";
  URL ="";
  isdefault: boolean = false;
  submitted: boolean=false;
  
  edit_btn;
  dropdownValue= "";
  SPECIFY_YOUR_OWN_VALUE : any;
  typeDropdown: any[];
  selected:any

  reqParams= {
    "saveReportDetails":{
        "ID":"",
       "NAME":"",
       "PERIMETER_NAME":"",
       "PERIMETER_VALUE":0,
       "IS_STANDARD":0,
         "COMMENTS": "",
         "URL": "",
         "LOCALE": 0,
         "STATUS": 0,
         "USER_CREATION":"",
         "USER_MAJ":"",
         "ORDER_OF_APPEARANCE":0,
         "userLocale":""
     },"type":""
 }
 @ViewChild("checkBoxdefault", { static: false }) checkBoxdefault: ElementRef;
  @ViewChild("checkBoxown", { static: false }) checkBoxown: ElementRef;
  unsubscribe$: Subject<boolean> = new Subject();


  constructor(
    private translate:TranslateService,
    private _projectreport: ProjectReportService,
    private fb: FormBuilder,private router:Router,
    private modalService: NgbModal, 
    private messageService: MessageService,
    private commonservice:CommonService,
    private headerService: HeaderChangeService,
    private confirmationService:ConfirmationService
  ) { 
    
  }

  ngOnInit() {

    this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => {
      let selectedlanguage = language
      this.userLanguage=this.commonservice.getUserlocaleName()
      this.getDropdownValue();
      this.getProjectReportData()
    });


    this.cols = [
      { field: 'STATUS_NAME', header: 'Status',inputType: 'textDate',sortInput:'notrequired' },
      { field: 'NAME', header: 'Name'  ,inputType: 'textDate',sortInput:'required'},
      { field: 'PERIMETER_NAME', header: 'Perimiter' ,inputType: 'textDate',sortInput:'required'},
      { field: 'IS_STANDARD_NAME', header: 'Standard',inputType: 'textDate',sortInput:'required' },
      { field: 'LOCALE', header: 'Language',inputType: 'textDate',sortInput:'required' },
      { field: 'COMMENTS', header: 'Comments',inputType: 'textDate',sortInput:'required' },
      { field: 'USER_CREATION', header: 'Created By',inputType: 'textDate',sortInput:'required' },
      { field: 'DATE_CREATION', header: 'Created On',inputType: 'textDate',sortInput:'required' },
      { field: 'USER_MAJ', header: 'Modified By',inputType: 'textDate',sortInput:'required' },
      { field: 'DATE_MAJ', header: 'Modified On',inputType: 'textDate',sortInput:'required' }
    ];
this.typeDropdown = [
      { label: 'Brouillon', value: 'Brouillon'  },
      { label: 'Publié', value: 'Publié'  },
      { label: 'Ancienne version', value: 'Ancienne version'  }
    ];
    //this.getProjectReportData();
    this. buildUserForm();
   //this.getDropdownValue();

  
  }
  

  showToast(severity, summary, detail) {
    let res= this.translate.instant(summary)
    this.messageService.add({ key: 'tc', severity: severity, summary: res, detail: detail });
  }
getDropdownValue()
{
  this.getProjectLanguage();
  this.getProjectPerimeter();
  this.getStatusReport();
  this.getProjectStatus();
}

get f() { return this.userForm.controls; }
  buildUserForm() {
    let URL_REGEXP = "^https?:\/\/(.*)"
    this.userForm = this.fb.group({ 
      LOCALE: [''], 
      NAME: ['', [Validators.required,NameValidator.cannotContainSpace]],
      URL: ['',[Validators.pattern(URL_REGEXP),Validators.required]],
      COMMENTS: [''],
      IS_STANDARD: [''],
      PERIMETER_NAME: [''],
      PERIMETER_VALUE: [''],
      STATUS: [''],
      ORDER_OF_APPEARANCE:[''],
      SPECIFY_YOUR_OWN_VALUE:['']
    });
  }
  

  formValue() {
        let status_data = this.projectstatuslist.find(x=>x.Value==this.projectReportData['STATUS']);
    this.userForm.patchValue({    
      ID: this.projectReportData['ID'],
      LOCALE: this.projectReportData['LOCALE'],
      NAME: this.projectReportData['NAME'],
      URL: this.projectReportData['URL'],
      COMMENTS: this.projectReportData['COMMENTS'],
      IS_STANDARD: this.projectReportData['IS_STANDARD'],
      PERIMETER_NAME: this.projectReportData['PERIMETER_NAME'],
      PERIMETER_VALUE: this.projectReportData['PERIMETER_VALUE'],
      STATUS:(status_data!=undefined?status_data.Value:0),
      ORDER_OF_APPEARANCE:this.projectReportData['ORDER_OF_APPEARANCE'],
      
      
    });    
  }

  getProjectReportData() {
  if(this.selected==null || this.selected==undefined){
    this.selected=1;
  }
    let reqparam={
      "UserLocale":this.commonservice.getUserlocaleName(),
      "StatusValue":this.selected
    }
    
    this.dataLoadStatus = '';
    this.blockedDocument = true;
    this._projectreport.getReportData(reqparam).subscribe(
      responseData => {
        this.blockedDocument = false;
        this.reportData = responseData.GetReportListByStatusResult;
        this.dataLoadStatus = 'dataLoaded';
        this.dropdownValue = this.selected;
      },
      responseError => {
        if (responseError.STATUS === 200 && responseError.statusText === 'OK' && responseError.name === 'HttpErrorResponse') {
          this.unknownError = true;
        } else {
          this.errorRes = responseError.STATUS + ' : ' + responseError.statusText;
        }
      }
    );}

  selectData(data) {
    this.selectColReportData = data;
  }

  reportExternalLink(obj)
  {
    
  //  window.open("https://www.google.com", "_blank");
  //this.router.navigateByUrl("https://angular.io/api/common/http/HttpInterceptor");
  }
   createReports() {
    this.message="";
   this.submitted=false
    this.userForm.reset()
   let result = _.head(this.perimeterlist);   
  
    this.isdefault = true
    this.dialogHeader = 'Create New Report';
    this.saveAction = 'Save';
    this.deleteAction = 'Cancel';
    this.projectReportData = {};
    this.formValue();
    if (result != undefined && result != "") {
      this.userForm.patchValue({
        PERIMETER_NAME: result.Key,
        PERIMETER_VALUE: result.Value
      });
    }
    this.displayDialog = true;
    this.newproject=true;
    let resultlang = _.head(this.languageslist);
    let resultstatus = _.head(this.projectstatuslist);
    if(!_.isNil(resultlang))
     this.userForm.patchValue({
      LOCALE:resultlang.Key,    
      });
      if(!_.isNil(resultstatus))
     this.userForm.patchValue({
      STATUS: result.Value
      });

  }

  EditReport(ID)
  {
    this.message="";
    this.userForm.reset()
    this.dialogHeader = 'Edit Report';
    this.saveAction = 'Update';
    this.deleteAction = 'Cancel';
    this.blockedDocument = true;
    this.newproject=false;
    let reqparam={
      "ID":ID,
      "UserLocale":this.commonservice.getUserlocaleName()
    }
    this._projectreport.getSingleReport(reqparam).subscribe(
      (data: any) => {        
        this.displayDialog = true;
        this.blockedDocument = false;
        this.projectReportData = data;
       
        this.userForm.controls["ORDER_OF_APPEARANCE"].setValue('');
        this.formValue();
        if(data.PERIMETER_VALUE==PERIMETER_DEFAULT)
        {
          this.checkBoxdefault.nativeElement.checked = false;
          this.checkBoxown.nativeElement.checked = true;
          this.userForm.controls["SPECIFY_YOUR_OWN_VALUE"].setValue(this.projectReportData['PERIMETER_NAME']);
        }
        else{
          this.checkBoxdefault.nativeElement.checked = true;
          this.checkBoxown.nativeElement.checked = false;  
        
        }

       

      },
      (error: any) => this.errorMessage = <any>error
    );
  }


  changeSpecify(value)
  {
    // if(value==0){
    //   this.userForm.controls["SPECIFY_YOUR_OWN_VALUE"].setValue('');
    
    // }
    
  }

// Get All Language List

  getProjectLanguage()
  {
    this._projectreport.getProjectLanguage().subscribe(
      (data: any) => {        
        this.languageslist = data;
      },
      (error: any) => this.errorMessage = <any>error
    );
  }

// Get All Perimeter List
getProjectPerimeter()
{
  let param = {
    LOCALE: this.commonservice.getUserlocaleName()
  }
  this._projectreport.getPerimeterList(param).subscribe(
    (data: any) => {        
      this.perimeterlist = data;
    },
    (error: any) => this.errorMessage = <any>error
  );
}


// Get STATUS Report Radio Option
getStatusReport()
{
  let param = {
    LOCALE: this.commonservice.getUserlocaleName()
  }
  this._projectreport.getReportStatusList(param).subscribe(
    (data: any) => {        
      this.projectstatuslist = data;
    },
    (error: any) => this.errorMessage = <any>error
  );
}


// Get Project STATUS
sortByProjectStatus (obj){
  this.dropdownValue = obj.value;
  
  this.getProjectReportData();
}



// Get Project STATUS
getProjectStatus()
   {
    let param = {
      LOCALE: this.userLanguage
    }
    this._projectreport.getReportStatusList(param).subscribe(  
      (data: any) => {
      this.projectStatus = data;
    },
    (error: any) => this.errorMessage = <any>error
  );
   }

   radioChangeEvent(event){
     let issueList=_.head(this.perimeterlist)
     this.userForm.controls['PERIMETER_NAME'].setValue(issueList.Key);
   }


   UpdateReportData()
  {   
    this.submitted = true;
    if(this.userForm.valid){
    this.blockedDocument = true;  
    let userid=!_.isNil(this.commonservice.getUserID())?this.commonservice.getUserID():""
    let selectedvalue = 0
    let checkedvalue=this.checkBoxown.nativeElement.checked; 
    let formdata=this.userForm.value;
    if (checkedvalue) {
           
    }
    else{
      if (!_.isNil(formdata.PERIMETER_NAME)) {
        let obj = this.perimeterlist.filter(x => x.Key == formdata.PERIMETER_NAME)
        selectedvalue = obj[0].Value
      } 
    }

    this.reqParams.saveReportDetails.USER_MAJ=this.commonservice.getUserID()
    this.reqParams.saveReportDetails.USER_CREATION=this.commonservice.getUserID()
    this.reqParams.saveReportDetails.NAME=formdata.NAME
    this.reqParams.saveReportDetails.PERIMETER_NAME=(formdata.PERIMETER_NAME!=undefined?formdata.PERIMETER_NAME:"")
    this.reqParams.saveReportDetails.PERIMETER_VALUE=selectedvalue != undefined ? selectedvalue : 0
    this.reqParams.saveReportDetails.IS_STANDARD=(formdata.IS_STANDARD!=undefined?formdata.IS_STANDARD:0)
    this.reqParams.saveReportDetails.COMMENTS=(formdata.COMMENTS!=undefined?formdata.COMMENTS:"")
    this.reqParams.saveReportDetails.LOCALE=(formdata.LOCALE!=undefined?formdata.LOCALE:0)
    this.reqParams.saveReportDetails.STATUS=(formdata.STATUS!=undefined?formdata.STATUS:0)
    this.reqParams.saveReportDetails.URL=(formdata.URL!=undefined?formdata.URL:"")
    this.reqParams.saveReportDetails.ORDER_OF_APPEARANCE=(formdata.ORDER_OF_APPEARANCE!=undefined?formdata.ORDER_OF_APPEARANCE:0)
    this.reqParams.saveReportDetails.userLocale=this.commonservice.getUserlocaleName()
    if (!_.isNil(formdata.SPECIFY_YOUR_OWN_VALUE) && formdata.SPECIFY_YOUR_OWN_VALUE!="" ) {
      this.reqParams.saveReportDetails.PERIMETER_NAME = formdata.SPECIFY_YOUR_OWN_VALUE
      this.reqParams.saveReportDetails.PERIMETER_VALUE = PERIMETER_DEFAULT

    }
    this.getDropdownValue();
  
 
  if(this.newproject)
  {
    this.reqParams.saveReportDetails.ID=formdata.ID!=null?formdata.ID:0
     this.reqParams.type=RECORD_TYPE_UPDATE;    
  }
  else{
    this.reqParams.type=RECORD_TYPE_SAVE;
    this.reqParams.saveReportDetails.USER_CREATION=""; 
    this.reqParams.saveReportDetails.ID=this.projectReportData['ID'];
    this.reqParams.saveReportDetails.IS_STANDARD=this.IS_STANDARD;
  }     
      
      this._projectreport.createReportData(JSON.stringify(this.reqParams)).subscribe(
        (data: any) =>  {
          if(data.SaveReportDetailsResult.result){
            this.message=data.SaveReportDetailsResult.Message;
           this.getProjectReportData();
            this.displayDialog = false;
            if(this.newproject)
  {
           this.showToast('success', 'view.projecthome.createdMsg', '');
  }
  else{
    this.showToast('success', 'view.projecthome.updatedMsg', '');
  }
            }
           else {
             this.message=data.SaveReportDetailsResult.Message;
           }
        },
        (error: any) => this.errorMessage = <any>error
      );
       
       } else {return false}
  }

  deleteReport(ID)
  {
    
      let parmDelete = 
      {
        "ReportID" : ID,
        "userLocale":this.userLanguage
      } 

        
    this.confirmationService.confirm({
      
      message: this.translate.instant(this.msg),
      header: this.translate.instant(this.headerMsg),
      icon: 'pi pi-exclamation-triangle',
      acceptLabel:this.translate.instant(this.acceptMsg),
          rejectLabel:this.translate.instant(this.rejectMsg),
      accept: () => {       
        this._projectreport.deleteReport(JSON.stringify(parmDelete)).subscribe(
          (data: any) => {   
             if(data.result) 
             {
              this.getProjectReportData();
              this.blockedDocument = false;
              this.selectColReportData = null;
              this.showToast('success', 'view.projecthome.deletedMsg', '');
            }  
            else{
              this.messageService.add({severity:'success', summary: 'Successful', detail: 'Report Deleted', life: 3000});
            }          
          },
          (error: any) => this.errorMessage = <any>error
        );          
      }
  });    
  }

  cancel() {
    
    this.displayDialog = false;
    this.blockedDocument = false;
  }
  testURL(url){
  
    if(url!=null && url!="")
    {
      window.open(url, "_blank");
    }
    else{
      return false
    }
  }
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
