import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { saveAs } from "file-saver";
import { Observable, Subject } from 'rxjs';
import * as _ from 'lodash';
import { CommonService } from 'src/app/service/common.service';
import { PartRepositoryService } from 'src/app/service/part-repository.service';
import { ProjectService } from 'src/app/service/project.service';
import { UploadAndExportService } from 'src/app/service/upload-and-export.service';
import { Header } from 'primeng';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { takeUntil } from 'rxjs/operators';
import { TYPE_MANUALIMPORT_KEY, TYPE_OBJECTIVE_KEY, TYPE_PARTCONFIGURATION_KEY, TYPE_PLANNING_KEY, TYPE_VEHICLE_KEY, UPLOAD_FILE_XLSX_TYPE, UPLOAD_FILE_XLS_TYPE } from 'src/app/constant/auth-constant';
import { ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-upload-export',
  templateUrl: './upload-export.component.html',
  styleUrls: ['./upload-export.component.scss']
})
export class UploadExportComponent implements OnInit {

  @ViewChild('UploadFileInput') uploadFileInput: ElementRef;
  dialogHeader;
  fileInputLabel: string;
  categoryFile:string="";
  selectedFiles: FileList;
  manualUploadFlag:boolean=false;
  resultForm = {
    successfullRecord: "",
    UploadedDate:"",
    filename: "",
    failedRecord: "",
    result:"",
    LogText:""
  }
  isUloadEnable:boolean=true
  dataLoadStatus:boolean=false
  flag:boolean=false
  progressInfos = [];
  dateFlag:boolean=false
  message ={"message":"","filename":""} ;
  recentUploadID:number=0
  fileInfos: Observable<any>;
  resultParameter:any
  value:any
  langChange:false
  filename: string = 'view.pr.message.static'
  @ViewChild("content") modalContent: ViewContainerRef;
  fileToUpload: File = null;
  category:any;
  launchID:any;
  launch:string="";
  userLanguage:string;
  projectid:any
  unsubscribe$: Subject<boolean> = new Subject();
  constructor(private service: ProjectService, private http: HttpClient,
    private uploadService: PartRepositoryService,
    private formBuilder: FormBuilder,
    private modalService: NgbModal,
    private translate: TranslateService,
    private commanService: CommonService,
    private route: ActivatedRoute,
    private uploadExportService:UploadAndExportService,
     private headerService:HeaderChangeService,
     
  ) { }
/*functiona calls on init of page all the intial calls are done here*/
  ngOnInit() {
    const projectId = this.route.snapshot.paramMap.get('id');
    this.commanService.setProjectId(projectId);
    this.projectid = this.commanService.getProjectId()
    this.service.getprojectDetailById(this.projectid).subscribe((data: any) => {      
      this.commanService.setProjectName(data.URL_SITE)
      this.commanService.setProjectLocale(data.LOCALE)
  })
    this.headerService.changeLeftpanel(true)
     this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => { 
    this.message.message="";
    this.message.filename="";
    this.flag=false;
    this.categoryFile=""
    this.launch="";
    this.isUloadEnable=true;
    this.value=undefined
    this.filename='view.pr.message.static';
    this.userLanguage=this.commanService.getUserlocaleName()
    this.getCategory();
    this.getLaunchId(); 
  });
  this.getCategory();
  this.getLaunchId();
  this.userLanguage=this.commanService.getUserlocaleName()
  }
/*get category list*/
  getCategory(){
    let param ={
      locale:this.commanService.getUserlocaleName()
    }
    this.uploadExportService.getReportCategory(param).subscribe(data=>{
      this.category=data;
      console.log(data)
    
    });
  }
/*get launch name */
  getLaunchId(){
    // disk issue - when open new tab
    
  // disk issue
    let param={
      ProjectID:this.projectid
    }
    this.uploadExportService.getLaunch(param).subscribe(data=>{this.launchID=data})
  }
/*change event for category*/
  selectType(event){
    this.filename = 'view.pr.message.static'
    this.value=undefined
    this.isUloadEnable=true
   this.message.message="";
   this.message.filename="";
   this.launch=""
    let obj=this.categoryFile
    if(obj==(this.category.find(e=>e.Key==TYPE_PLANNING_KEY).Value) || obj==(this.category.find(e=>e.Key==TYPE_OBJECTIVE_KEY).Value)){
      this.flag=true;
    }
    else
    this.flag=false;
  }
/*change event for launch*/
  selectLaunch(event){
      this.message.message="";
      this.message.filename=""
      this.value=undefined
      this.filename = 'view.pr.message.static'
      this.isUloadEnable=true
  }

  /* select files to upload*/
  selectFiles(event) {
    this.progressInfos = [];
    this.selectedFiles = event.target.files;
    let af = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel']
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.filename = event.target.files[0].name
      if (!_.includes(af, file.type)) {
        this.message.message = 'view.pr.message.validation';
        this.isUloadEnable=true
      }
      else{
        this.message.message="";
        this.message.filename="";
        this.isUloadEnable=false
      }
    }
  }
  /*set category for upload */
  setCategoryForUpload(){
    this.message.message = '';this.message.filename=""
  let obj  = this.categoryFile
  if(obj==(this.category.find(e=>e.Key==TYPE_PLANNING_KEY).Value)){
   
    for (let i = 0; i < this.selectedFiles.length; i++) {
      this.uploadPlanning(i, this.selectedFiles[i]);
      
    }
    this.dateFlag=false;
    this.manualUploadFlag=false;
   }
   else if(obj==(this.category.find(e=>e.Key==TYPE_VEHICLE_KEY).Value))
   {
    for (let i = 0; i < this.selectedFiles.length; i++) {
      this.uploadVehicle(i, this.selectedFiles[i]);
    }
    this.dateFlag=false;
    this.manualUploadFlag=false;
   }
   else if(obj==(this.category.find(e=>e.Key==TYPE_MANUALIMPORT_KEY).Value))
   {
    for (let i = 0; i < this.selectedFiles.length; i++) {
      this.uploadManualImport(i, this.selectedFiles[i]);
    }
    this.dateFlag=false;
   
   }
   else if(obj==(this.category.find(e=>e.Key==TYPE_OBJECTIVE_KEY).Value))
  {
    for (let i = 0; i < this.selectedFiles.length; i++) {
      this.uploadObjectives(i, this.selectedFiles[i]);
    }
    this.dateFlag=false;
    this.manualUploadFlag=false;
  }
  else if(obj==(this.category.find(e=>e.Key==TYPE_PARTCONFIGURATION_KEY).Value)){
    for (let i = 0; i < this.selectedFiles.length; i++) {
      this.uploadPartConfiguration(i, this.selectedFiles[i]);
    }
    this.dateFlag=false;
    this.manualUploadFlag=false;
  }
  else
  this.message.message="view.uploadexport.selectType"
  this.dateFlag=false;
  this.manualUploadFlag=false;
  }
/*set category for export*/
  setCategoryForExport(){
  let obj  = this.categoryFile
   
   
  if(obj==(this.category.find(e=>e.Key==TYPE_PLANNING_KEY).Value)){

    this.exportPlanning()
    this.dateFlag=true
    this.manualUploadFlag=false;
  }
  else if(obj==(this.category.find(e=>e.Key==TYPE_VEHICLE_KEY).Value)){
  this.exportVehicle()
  this.dateFlag=true
  this.manualUploadFlag=false;
}
  else if(obj==(this.category.find(e=>e.Key==TYPE_MANUALIMPORT_KEY).Value)){
  this.exportManualImport()
  this.dateFlag=true
  this.manualUploadFlag=false;
}
  else if(obj==(this.category.find(e=>e.Key==TYPE_OBJECTIVE_KEY).Value)){
    this.exportObjectives()
    this.dateFlag=true
    this.manualUploadFlag=false;
  }
  else if(obj==(this.category.find(e=>e.Key==TYPE_PARTCONFIGURATION_KEY).Value)){
    this.exportPartConfiguration();
    this.dateFlag=true
    this.manualUploadFlag=false;
  }
  }
/*set category for export all*/
  setCategoryForExportAll(){
    let obj  = this.categoryFile
  if(obj==(this.category.find(e=>e.Key==TYPE_PLANNING_KEY).Value)){
    this.exportAllPlanning()
    this.dateFlag=false;
    this.manualUploadFlag=false;
  }
  else if(obj==(this.category.find(e=>e.Key==TYPE_VEHICLE_KEY).Value)){
  this.exportAllVehicle()
  this.dateFlag=false;
  this.manualUploadFlag=false;
  }
  else if(obj==(this.category.find(e=>e.Key==TYPE_PARTCONFIGURATION_KEY).Value)){
  this.exportAllPartConfiguration()
  this.dateFlag=false;
  this.manualUploadFlag=false;}

  else if(obj==(this.category.find(e=>e.Key==TYPE_MANUALIMPORT_KEY).Value)){
    this.exportAllManualImport();
    this.dateFlag=false;
    this.manualUploadFlag=false;
  }
  else if(obj==(this.category.find(e=>e.Key==TYPE_OBJECTIVE_KEY).Value)){
    this.exportAllObjectives();
    this.dateFlag=false;
    this.manualUploadFlag=false;
  }
  }
/*upload for part configuration*/
  uploadPartConfiguration(idx, file) {
    this.message.message="";
    let reqParams = {
      "partConfigurationUpload":
      {
        "FileName": "",
        "UserName": "",
        "FileData": "",
        "UploadType": "HomePage",
        "UserLocale":"",
        "ProjectID":""
      },
      "userLocale":this.userLanguage
    }
    this.dataLoadStatus=true
    this.resetModalData()
    let encryptData;
    this.progressInfos[idx] = { value: 0, fileName: file.name };
    let filedata: File = file;
    let fileReader: FileReader = new FileReader();
    fileReader.onloadend = (e) => {
    encryptData = fileReader.result;
    let jsonData = JSON.stringify(fileReader.result).replace("data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,", "").replace("data:application/vnd.ms-excel;base64,","")
      reqParams.partConfigurationUpload.FileData = JSON.parse(jsonData)
      reqParams.partConfigurationUpload.FileName = file.name ? file.name : ""
      reqParams.partConfigurationUpload.UploadType = "HomePage"
      reqParams.partConfigurationUpload.UserName = this.commanService.getUserID()
      reqParams.partConfigurationUpload.UserLocale=this.userLanguage
      reqParams.partConfigurationUpload.ProjectID=this.projectid
      this.uploadExportService.uploadFilePartConfiguration(reqParams).subscribe(
        response => {
          if (response.UploadPartConfigProjectResult.ServiceStatus) {
            this.resultForm.filename = this.filename
            this.resultForm.failedRecord = response.UploadPartConfigProjectResult.Failed_Records
            this.resultForm.successfullRecord = response.UploadPartConfigProjectResult.Inserted_Records +response.UploadPartConfigProjectResult.Updated_Records +response.UploadPartConfigProjectResult.Deleted_Records
            this.recentUploadID=response.UploadPartConfigProjectResult.UploadID
            this.dataLoadStatus=false;
            this.dialogHeader = 'Upload Status';
            this.opeModel()
            this.filename = 'view.pr.message.static'
            this.uploadFileInput.nativeElement.value = null
            this.isUloadEnable=true
          }
          else{
            this.dataLoadStatus=false
            this.message.message = response.UploadPartConfigProjectResult.StatusLog 
            this.message.filename=file.name;
            this.isUloadEnable=false
          }
        },
        err => {
          this.dataLoadStatus=false
          this.progressInfos[idx].value = 0;
          this.message.message = "view.projecthome.message.uploaderror" 
          this.message.filename=file.name; 
        });
    }
    fileReader.readAsDataURL(filedata);
  }
  
  /*File upload call for planning */
  uploadPlanning(idx, file) {
    this.message.message="";
    if(!this.launch){
      this.message.message="view.uploadplanning.errorMsg"
    }else{
    let reqParams = {
      "objectivesPlanningUpload":
      {
        "FileName": "",
        "ProjectID":"",
        "UserName": "",
        "LaunchID":this.launch,
        "FileData": "",
        "UserLocale":this.userLanguage,
      }
    }
    this.dataLoadStatus=true
    this.resetModalData()
    let encryptData;
    this.progressInfos[idx] = { value: 0, fileName: file.name };
    let filedata: File = file;
    let fileReader: FileReader = new FileReader();
    fileReader.onloadend = (e) => {
    encryptData = fileReader.result;
    let jsonData = JSON.stringify(fileReader.result).replace("data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,", "").replace("data:application/vnd.ms-excel;base64,","")
      reqParams.objectivesPlanningUpload.FileData = JSON.parse(jsonData)
      reqParams.objectivesPlanningUpload.FileName = file.name ? file.name : ""
      reqParams.objectivesPlanningUpload.ProjectID = this.projectid
      reqParams.objectivesPlanningUpload.UserName = this.commanService.getUserID()
      this.uploadExportService.uploadFilePlanning(reqParams).subscribe(
        response => {
          if (response.UploadPlanningResult.ServiceStatus) {
            this.resultForm.filename = this.filename
            this.resultForm.failedRecord = response.UploadPlanningResult.Failed_Records
            this.resultForm.successfullRecord = response.UploadPlanningResult.Inserted_Records +response.UploadPlanningResult.Updated_Records 
            this.recentUploadID=response.UploadPlanningResult.UploadID
            this.dataLoadStatus=false;
            this.dialogHeader = 'Upload Status';
            this.opeModel()
            this.filename = 'view.pr.message.static'
            this.uploadFileInput.nativeElement.value = null
            this.isUloadEnable=true
          }
          else{
            this.dataLoadStatus=false
            this.message.message = response. UploadPlanningResult.StatusLog
            this.message.filename=file.name;
            this.isUloadEnable=false 
          }
        },
        err => {
          this.dataLoadStatus=false
          this.progressInfos[idx].value = 0;
          this.message.message = "view.projecthome.message.uploaderror" 
          this.message.filename=file.name;
        });
    }
    fileReader.readAsDataURL(filedata);
  }
  }

/*upload for vehicle*/
uploadVehicle(idx, file) {
  this.message.message=""; 
  let reqParams = {
    "vehicleUploadRequest":
   {
      "FileName":"",
      "UserName":"",
      "ProjectID" : "",
      "FileData":"",
      "UserLocale":this.userLanguage
   },
   "userLocale":this.userLanguage
  }
  this.dataLoadStatus=true
  this.resetModalData()
  let encryptData;
  this.progressInfos[idx] = { value: 0, fileName: file.name };
  let filedata: File = file;
  let fileReader: FileReader = new FileReader();
  fileReader.onloadend = (e) => {
    encryptData = fileReader.result;
    let jsonData = JSON.stringify(fileReader.result).replace("data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,", "").replace("data:application/vnd.ms-excel;base64,","")
    reqParams.vehicleUploadRequest.FileData = JSON.parse(jsonData)
    reqParams.vehicleUploadRequest.FileName = file.name ? file.name : ""
    reqParams.vehicleUploadRequest.ProjectID = this.projectid
    reqParams.vehicleUploadRequest.UserName = this.commanService.getUserID()
    this.uploadExportService.uploadFileVehicle(reqParams).subscribe(
      response => {
        if (response.UploadVehicleResult.ServiceStatus) {
          this.resultForm.filename = this.filename
          this.resultForm.failedRecord = response.UploadVehicleResult.Failed_Records
          this.resultForm.successfullRecord = response.UploadVehicleResult.Inserted_Records +response.UploadVehicleResult.Updated_Records 
          this.recentUploadID=response.UploadVehicleResult.UploadID
          this.dataLoadStatus=false;
          this.dialogHeader = 'Upload Status';
          this.opeModel()
          this.filename = 'view.pr.message.static'
          this.uploadFileInput.nativeElement.value = null
          this.isUloadEnable=true
        }
        else{
          this.dataLoadStatus=false
          this.message.message =response. UploadVehicleResult.StatusLog
          this.message.filename=file.name;
          this.isUloadEnable=false 
        }
      },
      err => {
        this.dataLoadStatus=false
        this.progressInfos[idx].value = 0;
        this.message.message = "view.projecthome.message.uploaderror" 
        this.message.filename=file.name;
      });
  }
  fileReader.readAsDataURL(filedata);
}


/*upload for manual import*/
uploadManualImport(idx, file){
  this.message.message="";
    let reqParams = {
      "manulaImportUploadRequest":
      {
        "FileName": "",
        "UserName": "",
        "FileData": "",
        "ProjectID":"",
        "UserLocale":"",
      },
      "userLocale":this.userLanguage
    }
    this.dataLoadStatus=true
    this.resetModalData()
    let encryptData;
    this.progressInfos[idx] = { value: 0, fileName: file.name };
    let filedata: File = file;
    let fileReader: FileReader = new FileReader();
    fileReader.onloadend = (e) => {
    encryptData = fileReader.result;
      let jsonData = JSON.stringify(fileReader.result).replace("data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,", "").replace("data:application/vnd.ms-excel;base64,","")
      reqParams.manulaImportUploadRequest.FileData = JSON.parse(jsonData)
      reqParams.manulaImportUploadRequest.FileName = file.name ? file.name : ""
      reqParams.manulaImportUploadRequest.ProjectID = this.projectid
      reqParams.manulaImportUploadRequest.UserName = this.commanService.getUserID()
      reqParams.manulaImportUploadRequest.UserLocale=this.userLanguage
      this.uploadExportService.uploadFileManualImport(reqParams).subscribe(
        response => {console.log(response)
          if (response.UploadManualImportResult.ServiceStatus) {
            this.resultForm.filename = this.filename
            this.resultForm.failedRecord = response.UploadManualImportResult.Failed_Records
            this.resultForm.result=response.UploadManualImportResult.Result
            this.resultForm.LogText=response.UploadManualImportResult.LogText
            this.resultForm.successfullRecord = response.UploadManualImportResult.Inserted_Records +response.UploadManualImportResult.Updated_Records + response.UploadManualImportResult.Deleted_Records
            this.recentUploadID=response.UploadManualImportResult.UploadID
            this.dataLoadStatus=false;
            this.dialogHeader = 'Upload Status';
            this.opeModel()
            this.filename = 'view.pr.message.static'
            this.uploadFileInput.nativeElement.value = null
            this.isUloadEnable=true
            if(response.UploadManualImportResult.Result=="KO"){
              this.manualUploadFlag=true
            }
            else{
              this.manualUploadFlag=false;
            }
          }
          else{
            this.dataLoadStatus=false
            this.message.message = response.UploadManualImportResult.StatusLog 
            this.message.filename=file.name;
            this.isUloadEnable=false
          }
        },
        err => {
          this.dataLoadStatus=false
          this.progressInfos[idx].value = 0;
          this.message.message = "view.projecthome.message.uploaderror" 
          this.message.filename=file.name;
        });
    }
    fileReader.readAsDataURL(filedata);
}

/*upload for objectives*/
uploadObjectives(idx, file){
  this.message.message="";
  if(!this.launch){
    this.message.message="view.uploadplanning.errorMsg"
  }else{
    let reqParams = {
      "objectivesPlanningUpload":
      {
        "FileName": "",
        "UserName": "",
        "FileData": "",
        "LaunchID":this.launch,
        "ProjectID":"",
        "UserLocale":"",
      }
    }
    this.dataLoadStatus=true
    this.resetModalData()
    let encryptData;
    this.progressInfos[idx] = { value: 0, fileName: file.name };
    let filedata: File = file;
    let fileReader: FileReader = new FileReader();
    fileReader.onloadend = (e) => {
    encryptData = fileReader.result;
      let jsonData = JSON.stringify(fileReader.result).replace("data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,", "").replace("data:application/vnd.ms-excel;base64,","")
      reqParams.objectivesPlanningUpload.FileData = JSON.parse(jsonData)
      reqParams.objectivesPlanningUpload.FileName = file.name ? file.name : ""
      reqParams.objectivesPlanningUpload.ProjectID = this.projectid
      reqParams.objectivesPlanningUpload.UserName = this.commanService.getUserID()
      reqParams.objectivesPlanningUpload.UserLocale=this.userLanguage
      this.uploadExportService.uploadFileObjectives(reqParams).subscribe(
        response => {console.log(response)
          if (response.UploadObjectiveResult.ServiceStatus) {
            this.resultForm.filename = this.filename
            this.resultForm.failedRecord = response.UploadObjectiveResult.Failed_Records
            this.resultForm.successfullRecord = response.UploadObjectiveResult.Inserted_Records + response.UploadObjectiveResult.Updated_Records  
            this.recentUploadID=response.UploadObjectiveResult.UploadID
            this.dataLoadStatus=false;
            this.dialogHeader = 'Upload Status';
            this.opeModel()
            this.filename = 'view.pr.message.static'
            this.uploadFileInput.nativeElement.value = null
            this.isUloadEnable=true
          }
          else{
            this.dataLoadStatus=false
            this.message.message = response.UploadObjectiveResult.StatusLog
            this.message.filename=file.name;
            this.isUloadEnable=false
          }
        },
        err => {
          this.dataLoadStatus=false
          this.progressInfos[idx].value = 0;
          this.message.message = "view.projecthome.message.uploaderror" 
          this.message.filename=file.name;
        });
    }
    fileReader.readAsDataURL(filedata);
  }
}

/* export button for planning  */
  exportPlanning() {
   this.message.message="";
   this.message.filename=""
   this.value=undefined
   this.filename='view.pr.message.static';
   this.isUloadEnable=true;
   if(!this.launch){
    this.message.message="view.uploadplanning.errorMsg"
  }else{
      let req =
      {
        "objectivesPlanningExport":
        {
          "UserName": this.commanService.getUserID(),
          "UserLocale":this.userLanguage,
          "ProjectID":this.projectid,
          "LaunchID":this.launch
        }
      }
      this.dataLoadStatus=true
      this.resetModalData()
      this.uploadExportService.exportPlanning(req).subscribe(
        response => {
          if (response.ExportPlanningResult.ServiceStatus) {
            this.resultForm.filename = response.ExportPlanningResult.FileName!=null?response.ExportPlanningResult.FileName:""
            this.resultForm.UploadedDate=response.ExportPlanningResult.UploadedDate!=null?response.ExportPlanningResult.UploadedDate:""
            this.resultForm.failedRecord = response.ExportPlanningResult.Failed_Records !=null?response.ExportPlanningResult.Failed_Records:""
            this.resultForm.successfullRecord = response.ExportPlanningResult.Inserted_Records + response.ExportPlanningResult.Updated_Records
            if(response.ExportPlanningResult.FileData!=null && response.ExportPlanningResult.FileName!=null) 
            this.convertToXl(response.ExportPlanningResult.FileData,response.ExportPlanningResult.FileName)
              this.dataLoadStatus=false;
              this.dialogHeader = 'Export Status';
              this.opeModel()
              this.filename = 'view.pr.message.static'
              this.uploadFileInput.nativeElement.value = "";
          }
          else{
            this.dataLoadStatus=false
            this.message.message=response.ExportPlanningResult.StatusLog
            this.message.filename=""
          }
        },
        err => {
          this.dataLoadStatus=false
          this.message.message="view.pr.message.exporterror"
          this.message.filename=""
        });
  }
  }
/*export for part configuration*/
  exportPartConfiguration() {
    this.message.message="";
    this.message.filename=""
    this.value=undefined
    this.filename='view.pr.message.static';
    this.isUloadEnable=true;
    this.dataLoadStatus=true
    this.resetModalData()
    let req =
    {
      "partConfigurationExport":
      {
        "UserName": this.commanService.getUserID(),
        "UserLocale":this.userLanguage,
        "ProjectID":this.projectid
      }
    }
    this.uploadExportService.exportPartConfiguration(req).subscribe(
      response => {
        if (response.ExportPartConfigurationProjectResult.ServiceStatus) {
          this.resultForm.filename = response.ExportPartConfigurationProjectResult.FileName!=null?response.ExportPartConfigurationProjectResult.FileName:""
          this.resultForm.UploadedDate=response.ExportPartConfigurationProjectResult.UploadedDate!=null?response.ExportPartConfigurationProjectResult.UploadedDate:""
          this.resultForm.failedRecord = response.ExportPartConfigurationProjectResult.Failed_Records !=null?response.ExportPartConfigurationProjectResult.Failed_Records:""
          this.resultForm.successfullRecord = response.ExportPartConfigurationProjectResult.Inserted_Records + response.ExportPartConfigurationProjectResult.Updated_Records + response.ExportPartConfigurationProjectResult.Deleted_Records
          if(response.ExportPartConfigurationProjectResult.FileData!=null && response.ExportPartConfigurationProjectResult.FileName!=null) 
          this.convertToXl(response.ExportPartConfigurationProjectResult.FileData,response.ExportPartConfigurationProjectResult.FileName)
            this.dataLoadStatus=false;
            this.dialogHeader = 'Export Status';
            this.opeModel()
            this.filename = 'view.pr.message.static'
            this.uploadFileInput.nativeElement.value = "";
        }
        else{
          this.dataLoadStatus=false
          this.message.message=response.ExportPartConfigurationProjectResult.StatusLog
          this.message.filename=""
        }
      },
      err => {
        this.dataLoadStatus=false
        this.message.message="view.pr.message.exporterror"
        this.message.filename=""
      }); 
}

/* export button for vehicle  */
exportVehicle() {
  this.message.message="";
  this.message.filename=""
  this.value=undefined
  this.filename='view.pr.message.static';
  this.isUloadEnable=true;
  this.dataLoadStatus=true
  this.resetModalData()
  let req =
  {
    "vehicleExport":
   {
      "UserName":this.commanService.getUserID(),
      "UserLocale":this.userLanguage,
      "ProjectID":this.projectid
   }
  }
  this.uploadExportService.exportVehicle(req).subscribe(
    response => {
      if (response.ExportVehicleResult.ServiceStatus) {
        this.resultForm.filename = response.ExportVehicleResult.FileName!=null?response.ExportVehicleResult.FileName:""
        this.resultForm.UploadedDate=response.ExportVehicleResult.UploadedDate!=null?response.ExportVehicleResult.UploadedDate:""
        this.resultForm.failedRecord = response.ExportVehicleResult.Failed_Records !=null?response.ExportVehicleResult.Failed_Records:""
        this.resultForm.successfullRecord = response.ExportVehicleResult.Inserted_Records + response.ExportVehicleResult.Updated_Records
        if(response.ExportVehicleResult.FileData!=null && response.ExportVehicleResult.FileName!=null) 
        this.convertToXl(response.ExportVehicleResult.FileData,response.ExportVehicleResult.FileName)
          this.dataLoadStatus=false;
          this.dialogHeader = 'Export Status';
          this.opeModel()
          this.filename = 'view.pr.message.static'
          this.uploadFileInput.nativeElement.value = "";
      }
      else{
        this.dataLoadStatus=false
        this.message.message=response.ExportVehicleResult.StatusLog
        this.message.filename=""
      }
    },
    err => {
      this.dataLoadStatus=false
      this.message.message="view.pr.message.exporterror"
      this.message.filename="" 
    });
}

/*export for manual import*/
exportManualImport(){
  this.message.message="";
  this.message.filename=""
  this.value=undefined
  this.filename='view.pr.message.static';
  this.isUloadEnable=true;
  this.dataLoadStatus=true
  this.resetModalData()
  let req =
  {
    "manualImportExport":
   {
      "UserName":this.commanService.getUserID(),
      "UserLocale":this.userLanguage,
      "ProjectID":this.projectid
   }
  }
  this.uploadExportService.exportManualImport(req).subscribe(
    response => {
      if (response.ExportManualImportResult.ServiceStatus) {
        this.resultForm.filename = response.ExportManualImportResult.FileName!=null?response.ExportManualImportResult.FileName:""
        this.resultForm.UploadedDate=response.ExportManualImportResult.UploadedDate!=null?response.ExportManualImportResult.UploadedDate:""
        this.resultForm.failedRecord = response.ExportManualImportResult.Failed_Records !=null?response.ExportManualImportResult.Failed_Records:""
        this.resultForm.successfullRecord = response.ExportManualImportResult.Inserted_Records + response.ExportManualImportResult.Updated_Records + response.ExportManualImportResult.Deleted_Records
        if(response.ExportManualImportResult.FileData!=null && response.ExportManualImportResult.FileName!=null) 
        this.convertToXl(response.ExportManualImportResult.FileData,response.ExportManualImportResult.FileName)
          this.dataLoadStatus=false;
          this.dialogHeader = 'Export Status';
          this.opeModel()
          this.filename = 'view.pr.message.static'
          this.uploadFileInput.nativeElement.value = "";
      }
      else{
        this.dataLoadStatus=false
        this.message.message=response.ExportManualImportResult.StatusLog
        this.message.filename=""
      }
    },
    err => {
      this.dataLoadStatus=false
      this.message.message="view.pr.message.exporterror"
      this.message.filename=""
    });
}

/* export for objectives*/
exportObjectives(){
  this.message.message="";
  this.message.filename=""
  this.value=undefined
  this.filename='view.pr.message.static';
  this.isUloadEnable=true;
  if(!this.launch){
    this.message.message="view.uploadplanning.errorMsg"
  }else{
  let req =
  {
    "objectivesPlanningExport":
   {
      "UserName":this.commanService.getUserID(),
      "UserLocale":this.userLanguage,
      "ProjectID":this.projectid,
      "LaunchID":this.launch
   }
  }
  this.dataLoadStatus=true
  this.resetModalData()
  this.uploadExportService.exportObjectives(req).subscribe(
    response => {
      if (response.ExportObjectiveResult.ServiceStatus) {
        this.resultForm.filename = response.ExportObjectiveResult.FileName!=null?response.ExportObjectiveResult.FileName:""
        this.resultForm.UploadedDate=response.ExportObjectiveResult.UploadedDate!=null?response.ExportObjectiveResult.UploadedDate:""
        this.resultForm.failedRecord = response.ExportObjectiveResult.Failed_Records !=null?response.ExportObjectiveResult.Failed_Records:""
        this.resultForm.successfullRecord = response.ExportObjectiveResult.Inserted_Records + response.ExportObjectiveResult.Updated_Records
        if(response.ExportObjectiveResult.FileData!=null && response.ExportObjectiveResult.FileName!=null) 
        this.convertToXl(response.ExportObjectiveResult.FileData,response.ExportObjectiveResult.FileName)
          this.dataLoadStatus=false;
          this.dialogHeader = 'Export Status';
          this.opeModel()
          this.filename = 'view.pr.message.static'
          this.uploadFileInput.nativeElement.value = "";
      }
      else{
        this.dataLoadStatus=false
        this.message.message=response.ExportObjectiveResult.StatusLog
        this.message.filename=""
      }
    },
    err => {
      this.dataLoadStatus=false
      this.message.message="view.pr.message.exporterror"
      this.message.filename=""
    });
  }
}
  /*check file extension */
  checkFileExtension(filename){
    if(filename!=null){
    let extn = filename.split(".").pop();
    if (extn == UPLOAD_FILE_XLSX_TYPE){
      return true
    }
    else if( extn == UPLOAD_FILE_XLS_TYPE){
      return false
    }
  }
  }
  /* call on export all button for planning */
  exportAllPlanning() {
    this.message.message="";
    this.message.filename=""
    this.value=undefined
    this.filename='view.pr.message.static';
    this.isUloadEnable=true;
    this.resetModalData()
    this.dataLoadStatus=true
    let req =
    {
      "objectivesPlanningExport":
      {
        "UserName": this.commanService.getUserID(),
        "UserLocale":this.userLanguage,
        "ProjectID":this.projectid
      }
    }
    this.uploadExportService.exportAllPlanning(req).subscribe(
      response => {
        if (response.ExportAllPlanningResult.ServiceStatus) {
          this.resultForm.filename = response.ExportAllPlanningResult.FileName!=null?response.ExportAllPlanningResult.FileName:""
           this.resultForm.failedRecord = response.ExportAllPlanningResult.Failed_Records!=null?response.ExportAllPlanningResult.Failed_Records:0
           this.resultForm.successfullRecord = (response.ExportAllPlanningResult.Inserted_Records + response.ExportAllPlanningResult.Updated_Records)
         if(response.ExportAllPlanningResult.FileData!=null && response.ExportAllPlanningResult.FileName!=null)
           this.convertToXl(response.ExportAllPlanningResult.FileData,response.ExportAllPlanningResult.FileName)
          this.dataLoadStatus=false;
          this.dialogHeader = 'Export All Status';
          this.filename = 'view.pr.message.static'
          this.opeModel()
        }
        else{
          this.dataLoadStatus=false
          this.message.message=response.ExportAllPlanningResult.StatusLog
          this.message.filename=""
        }
      },
      err => {
        this.message.message="view.pr.message.exporallerror"
        this.message.filename=""
        this.dataLoadStatus=false
      });
  }

  /*export all for part configuration*/
  exportAllPartConfiguration() {
    this.message.message="";
    this.message.filename=""
    this.value=undefined
    this.filename='view.pr.message.static';
    this.isUloadEnable=true;
    this.resetModalData()
    this.dataLoadStatus=true
    let req =
    {
      "partConfigurationExport":
      {
        "UserName": this.commanService.getUserID(),
        "UserLocale":this.userLanguage,
        "ProjectID":this.projectid
      }
    }
    this.uploadExportService.exportAllPartConfiguration(req).subscribe(
      response => {
        if (response.ExportAllPartConfigurationProjectResult.ServiceStatus) {
          this.resultForm.filename = response.ExportAllPartConfigurationProjectResult.FileName!=null?response.ExportAllPartConfigurationProjectResult.FileName:""
           this.resultForm.failedRecord = response.ExportAllPartConfigurationProjectResult.Failed_Records!=null?response.ExportAllPartConfigurationProjectResult.Failed_Records:0
           this.resultForm.successfullRecord = (response.ExportAllPartConfigurationProjectResult.Inserted_Records + response.ExportAllPartConfigurationProjectResult.Updated_Records + response.ExportAllPartConfigurationProjectResult.Deleted_Records )
         if(response.ExportAllPartConfigurationProjectResult.FileData!=null && response.ExportAllPartConfigurationProjectResult.FileName!=null)
           this.convertToXl(response.ExportAllPartConfigurationProjectResult.FileData,response.ExportAllPartConfigurationProjectResult.FileName)
          this.dataLoadStatus=false;
          this.dialogHeader = 'Export All Status';
          this.filename = 'view.pr.message.static'
          this.opeModel()
        }
        else{
          this.dataLoadStatus=false
          this.message.message=response.ExportAllPartConfigurationProjectResult.StatusLog
          this.message.filename=""
        }
      },
      err => {
        this.message.message="view.pr.message.exporallerror"
        this.message.filename=""
        this.dataLoadStatus=false
      });
  }

/* export all for vehicle */
  exportAllVehicle() {
    
    this.message.message="";
    this.message.filename=""
    this.value=undefined
    this.filename='view.pr.message.static';
    this.isUloadEnable=true;
    this.resetModalData()
    this.dataLoadStatus=true
    let req =
    {
      "vehicleExport":
   {
      "UserName":this.commanService.getUserID(),
      "UserLocale":this.userLanguage,
      "ProjectID":this.projectid
   }
    }
    this.uploadExportService.exportAllVehicle(req).subscribe(
      response => {
      
        if (response.ExportAllVehicleResult.ServiceStatus) {
          this.resultForm.filename = response.ExportAllVehicleResult.FileName!=null?response.ExportAllVehicleResult.FileName:""
           this.resultForm.failedRecord = response.ExportAllVehicleResult.Failed_Records!=null?response.ExportAllVehicleResult.Failed_Records:0
           this.resultForm.successfullRecord = (response.ExportAllVehicleResult.Inserted_Records + response.ExportAllVehicleResult.Updated_Records)
         if(response.ExportAllVehicleResult.FileData!=null && response.ExportAllVehicleResult.FileName!=null)
           this.convertToXl(response.ExportAllVehicleResult.FileData,response.ExportAllVehicleResult.FileName)
          this.dataLoadStatus=false;
          this.dialogHeader = 'Export All Status';
          this.filename = 'view.pr.message.static'
          this.opeModel()
        }
        else{
          this.dataLoadStatus=false
          this.message.message=response.ExportAllVehicleResult.StatusLog
          this.message.filename=""
        }
      },
      err => {
        this.message.message="view.pr.message.exporallerror"
        this.message.filename=""
        this.dataLoadStatus=false
      });
  }

  /*export all for manual import*/
exportAllManualImport(){
  this.message.message="";
  this.message.filename=""
  this.value=undefined
    this.filename='view.pr.message.static';
    this.isUloadEnable=true;
  this.resetModalData()
  this.dataLoadStatus=true
  let req =
  {
    "manualImportExport":
 {
    "UserName":this.commanService.getUserID(),
    "UserLocale":this.userLanguage,
    "ProjectID":this.projectid
 }
  }
  this.uploadExportService.exportAllManualImport(req).subscribe(
    response => {
      if (response.ExportAllManualImportResult.ServiceStatus) {
        this.resultForm.filename = response.ExportAllManualImportResult.FileName!=null?response.ExportAllManualImportResult.FileName:""
         this.resultForm.failedRecord = response.ExportAllManualImportResult.Failed_Records!=null?response.ExportAllManualImportResult.Failed_Records:0
         this.resultForm.successfullRecord = (response.ExportAllManualImportResult.Inserted_Records + response.ExportAllManualImportResult.Updated_Records + response.ExportAllManualImportResult.Deleted_Records)
       if(response.ExportAllManualImportResult.FileData!=null && response.ExportAllManualImportResult.FileName!=null)
         this.convertToXl(response.ExportAllManualImportResult.FileData,response.ExportAllManualImportResult.FileName)
        this.dataLoadStatus=false;
        this.dialogHeader = 'Export All Status';
        this.filename = 'view.pr.message.static'
        this.opeModel()
      }
      else{
        this.dataLoadStatus=false
        this.message.message=response.ExportAllManualImportResult.StatusLog
        this.message.filename=""
      }
    },
    err => {
      this.message.message="view.pr.message.exporallerror"
      this.message.filename=""
      this.dataLoadStatus=false
    });
}
/*export all for objective*/
exportAllObjectives(){
  this.message.message="";
  this.message.filename=""
  this.value=undefined
    this.filename='view.pr.message.static';
    this.isUloadEnable=true;
  this.resetModalData()
  this.dataLoadStatus=true
  let req =
  {
    "objectivesPlanningExport":
 {
    "UserName":this.commanService.getUserID(),
    "UserLocale":this.userLanguage,
    "ProjectID":this.projectid
 }
  }
  this.uploadExportService.exportAllObjectives(req).subscribe(
    response => {
      if (response.ExportAllObjectiveResult.ServiceStatus) {
        this.resultForm.filename = response.ExportAllObjectiveResult.FileName!=null?response.ExportAllObjectiveResult.FileName:""
         this.resultForm.failedRecord = response.ExportAllObjectiveResult.Failed_Records!=null?response.ExportAllObjectiveResult.Failed_Records:0
         this.resultForm.successfullRecord = (response.ExportAllObjectiveResult.Inserted_Records + response.ExportAllObjectiveResult.Updated_Records)
       if(response.ExportAllObjectiveResult.FileData!=null && response.ExportAllObjectiveResult.FileName!=null)
         this.convertToXl(response.ExportAllObjectiveResult.FileData,response.ExportAllObjectiveResult.FileName)
        this.dataLoadStatus=false;
        this.dialogHeader = 'Export All Status';
        this.filename = 'view.pr.message.static'
        this.opeModel()
      }
      else{
        this.dataLoadStatus=false
        this.message.message=response.ExportAllObjectiveResult.StatusLog
        this.message.filename=""
      }
    },
    err => {
      this.message.message="view.pr.message.exporallerror"
      this.message.filename=""
      this.dataLoadStatus=false
    });
}

/* open  Model pop up  */
  opeModel() {
    this.modalService.open(this.modalContent, {
      centered: true,
      backdrop: 'static', size: 'm'
    });
  }
  /* empty data array  */
  resetModalData() {
    this.resultForm = {
      successfullRecord: "",
      UploadedDate:"",
      filename: "",
      failedRecord: "",
      result:"",
      LogText:""
    }
  }
  /* convert base64 string to file  */
  convertToXl(dataURI,filename) {
    
    let isxlxs=false
     isxlxs=this.checkFileExtension(filename)
    let downloadFiletype= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      int8Array[i] = byteString.charCodeAt(i);
    }
    if(isxlxs)
    downloadFiletype= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      else
      downloadFiletype='application/vnd.ms-excel'
    const blob = new Blob([int8Array], { type: downloadFiletype});    
    saveAs(blob, filename);
 }
  /* to unsubscribe from the header change event so that api dont get called when page is not loaded  */
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
