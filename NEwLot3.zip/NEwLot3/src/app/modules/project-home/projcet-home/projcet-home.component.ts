import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Role } from 'src/app/shared/model/role';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from 'src/app/service/common.service';
import { MessageService, ConfirmationService } from 'primeng/api'
import { AccordionModule } from 'primeng/accordion';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter, map, mergeMap, tap } from 'rxjs/operators';
import { NgbPanelChangeEvent, NgbAccordion } from '@ng-bootstrap/ng-bootstrap';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { ProjectHomeService } from '../../../service/project-home.service';

import * as _ from 'node_modules/lodash';
import { RECORD_TYPE_SAVE, RECORD_TYPE_UPDATE, PERIMETER_DEFAULT, TOOL_HEADER, LINK_HEADER, TOOL_TYPE_ID, LINK_TYPE_ID } from 'src/app/constant/auth-constant';
import { NameValidator } from 'src/app/shared/validators/name.validator';
import { ProjectService } from 'src/app/service/project.service';

@Component({
  selector: 'app-projcet-home',
  templateUrl: './projcet-home.component.html',
  styleUrls: ['./projcet-home.component.scss'],
  providers: [MessageService, ConfirmationService],
})
export class ProjcetHomeComponent implements OnInit {
  Role = Role;
  dataLoadStatus = '';
  
  errorRes = ''; visibleIndex = -1; private _selectedEvent: any;
  URLB=""
  errorMessage: string;projectName:string=""
  projectDesc:string=""
  unknownError = false;
  blockedDocument = false;
  reportData = [];
  dialogHeader;
  text="";
  dropdownValue = "";
  toolName:any;
  urlName:any;
  saveAction = 'Save';
  deleteAction = 'Delete';
  resultToolMsg:string;
  toolList:any;
  linkList:any;
  toolRecord:any;
  displayDialog: boolean;
  contentSectionText:string;
  displayTool: boolean;
  addReportData: boolean;
  projectReportData = {};
  reportForm: FormGroup;
  toolForm:FormGroup;
  PERIMETER_NAME = "";
  COMMENTS = "";
  URL = "";
  typeParams:string;
  submitted: boolean=false;
  toolSubmitted:boolean=false;
  projectImage = "";
  message: string = "";
  newperemeter: boolean = false; isdefault: boolean = false
  newTool: boolean = false;
  public cols: any[];
  perimeterlist: any[]; perimeterMasterlist: any[]
  countList: any[];
  peremeterListCount : any[];
  select_peri;
  msg:string='view.project.deleteMsg';
  headerMsg:string='view.project.confirmDelete';
  acceptMsg:string='view.project.acceptMsg';
  rejectMsg:string='view.project.rejectMsg';
  public isExpanded: boolean = false;
  //public rows:number =10;
  public expandedRows = {};
  public temDataLength: number = 0;

  // Variable for pannel show and hide
  isPannelOpen:boolean;

  reqParams = {
    "savePerimeterDetails": {
      "ID": 0,
      "NAME": "",
      "PERIMETER_NAME": "",
      "PERIMETER_VALUE": 0,
      "COMMENTS": "",
      "URL": "",
      "ORDER_OF_APPEARANCE": 1,
      "PROJECT_ID_TITAN": 0,
      "REPORT_ID_FK": 0,
      "IS_SPECIFY_OWN_VALUE":1,
      "USER_CREATION": "",
      "USER_MAJ": "",
     
    },
    "type": "",
    "userLocale":""
  }
  @ViewChild('eventTable') eventTable: any;
  @ViewChild("checkBoxdefault", { static: false }) checkBoxdefault: ElementRef;
  @ViewChild("checkBoxown", { static: false }) checkBoxown: ElementRef;

  // Set toolbar of Text area here
  isToolBarActive:boolean = true;
  projectId:any
  constructor(
    private _projecthome: ProjectHomeService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private headerService: HeaderChangeService,
    private commonservice: CommonService,
    private messageService: MessageService,
    private translate: TranslateService,
    private confirmationService: ConfirmationService,
    public projectservice: ProjectService
  ) { }

  ngOnInit() {
    

    // disk issue - when open new tab
    const projectId = this.activatedRoute.snapshot.paramMap.get('id');
    //this.projectId = this.commonservice.decryptID(projectId)
    this.commonservice.setProjectId(projectId);
    
    this.projectservice.getprojectDetailById(projectId).subscribe((data: any) => {
      console.log(data, "project details");
      
      this.commonservice.setProjectName(data.URL_SITE)
      this.commonservice.setProjectLocale(data.LOCALE)
      
  })
  this.getPerimeterCountList();
    // this.sortByStatus(0, 0) 
    

    //Code for pannel show and hide
    this.isPannelOpen = true;


   this.projectName= this.commonservice.getProjectName();
   this.projectDesc=this.commonservice.getProjectDesciption();
    this.headerService.changeLeftpanel(true)
    this.cols = [
      { field: 'Key', header: 'Key' }
    ];
    // this.reportData = this.reportData;

    
    
    this.getProjectReportData(1);
    this.getProjectPerimeter()
    this.getPerimeterCountList();
    this.buildreportForm()
    this.buildToolForm()
    this.getProjectImage();
    this.getRichtextBoxContent();
    this.getContentSectionDetailsOfLink();
    this.getContentSectionDetailsOfTool();
    //this.reportData.length < this.rows ? this.temDataLength = this.reportData.length : this.temDataLength = this.rows;
    console.log("reportData",this.reportData);
  }

  showToast(severity, summary, detail) {
    let res= this.translate.instant(summary)
    this.messageService.add({ key: 'tc', severity: severity, summary: res, detail: detail });
  }

  getProjectImage() {
    
    let projectId = this.commonservice.getProjectId()
    this._projecthome.getProjectImage(projectId).subscribe(
      (data: any) => {
        if (data[0].Key)
          this.projectImage = data[0].Value;
      },
      (error: any) => this.errorMessage = <any>error
    );
  }
  getDropdownValue() {
    this.getProjectPerimeter();
  }
  get f() { return this.reportForm.controls; }
  get ft() { return this.toolForm.controls; }

  buildreportForm() {
    let URL_REGEXP =   "^https?:\/\/(.*)"
    //'^(?:(?:http(?:s)?|ftp)://)(?:\\S+(?::(?:\\S)*)?@)?(?:(?:[a-zA-Z0-9\u00a1-\uffff](?:-)*)*(?:[a-zA-Z0-9\u00a1-\uffff])+)(?:\\.(?:[a-zA-Z0-9\u00a1-\uffff](?:-)*)*(?:[a-zA-Z0-9\u00a1-\uffff])+)*(?:\\.(?:[a-zA-Z0-9\u00a1-\uffff]){2,})(?::(?:\\d){2,5})?(?:/(?:\\S)*)?$'
    this.reportForm = this.fb.group({
      ID:[''],
      NAME: ['', [Validators.required,NameValidator.cannotContainSpace]],
      URL: ['', [Validators.required, Validators.pattern(URL_REGEXP)]],
      COMMENTS: [''],
      PERIMETER_NAME: [''],
      PERIMETER_VALUE: [''],
      ORDER_OF_APPEARANCE: [''],
      PERIMETER_NAME_OWN: [''],
      IS_SPECIFY_OWN_VALUE:[],
    });
  }
  buildToolForm(){
    let URL_REGEXP =   "^https?:\/\/(.*)"
    this.toolForm=this.fb.group({
      NAME:['',[Validators.required,NameValidator.cannotContainSpace]],
      URL:['',[Validators.required,Validators.pattern(URL_REGEXP)]]
    });
  }
  formValue() {
    this.reportForm.patchValue({
      ID: this.projectReportData['ID'],
      NAME: this.projectReportData['NAME'],
      URL: this.projectReportData['URL'],
      COMMENTS: this.projectReportData['COMMENTS'],
      PERIMETER_NAME: this.projectReportData['PERIMETER_NAME'],
      PERIMETER_VALUE: this.projectReportData['PERIMETER_VALUE'],
      ORDER_OF_APPEARANCE: this.projectReportData['ORDER_OF_APPEARANCE'],
      IS_SPECIFY_OWN_VALUE : this.projectReportData['IS_SPECIFY_OWN_VALUE']

    });
  }
  resetform() {
    this.reportForm.reset()

  }


  // Get All Perimeter List
  getProjectPerimeter() {
    let params = { locale: this.commonservice.getUserlocaleName() }
    this._projecthome.getPerimeterList(params).subscribe(
      (data: any) => {
        this.perimeterlist = data;
        
        //this.peremeterListCount = data;
        // this.perimeterMasterlist=data
        //  this.perimeterMasterlist.push(this.othervalue)
      },
      (error: any) => this.errorMessage = <any>error
    );
  }

  getProjectReportData(obj) {
    this.dataLoadStatus = '';
    this.blockedDocument = true;
    let param_id = {
      ProjectId: this.commonservice.getProjectId(),
      locale: this.commonservice.getUserlocaleName(),
      obj: obj,
    }
    this._projecthome.getProjectList(param_id).subscribe(
      responseData => {
        this.blockedDocument = false;
        // this.reportData = responseData;
        // console.log("getProjectReportData",this.reportData);
        
        // this._selectedEvent = this.reportData[0];
        this.dataLoadStatus = 'dataLoaded';
        this.dropdownValue = obj;
      },
      responseError => {
        if (responseError.STATUS === 200 && responseError.statusText === 'OK' && responseError.name === 'HttpErrorResponse') {
          this.unknownError = true;
        } else {
          this.errorRes = responseError.STATUS + ' : ' + responseError.statusText;
        }
      }
    );
  }

 
  // Get Project STATUS
  sortByStatus(obj, index) {
    console.log("sortByStatus",obj,index);

    // Change icon of pannel
    this.isPannelOpen = !this.isPannelOpen;
    
    // this.reportData = []
    this.dropdownValue = obj;
    if (this.visibleIndex === index) {
      this.visibleIndex = -1;
    } else {
      this.visibleIndex = index;
    }
    console.log("visibleIndex",this.isPannelOpen);
    this.getProjectReportData(obj);
  }

  // Get Peremeter Count

  getPeremeterCout(obj) {
    let param_id = {
      ProjectId:this.commonservice.getProjectId(),
      dropdownValue: obj,
      UserLocale:this.commonservice.getProjectLocale()
    }
    this._projecthome.getPerimeterCount(param_id).subscribe(
      (data: any) => {
        this.dropdownValue = obj;
        this.countList = data;
        console.log(this.countList);
      },
      (error: any) => this.errorMessage = <any>error
    );
  }


  // Get Peremeter Count and List of Peremeter

  getPerimeterCountList() {
    
    let param_id = {
      ProjectId: this.commonservice.getProjectId(),
      UserLocale:this.commonservice.getProjectLocale()
    }
    
    this._projecthome.getPerimeterCountList(param_id).subscribe(
      (data: any) => {
        //this.dropdownValue = obj;
        this.peremeterListCount = data;
        console.log(this.peremeterListCount);
        
        this.peremeterListCount.forEach(record =>{
          // console.log(record);
          this.reportData =  record.perimeterList;
          console.log(this.reportData);
          
        })
      },
      (error: any) => this.errorMessage = <any>error
    );
  }

  createReports() {
    this.message="";
    this.resetform()
    this.getDropdownValue();
    this.isdefault = true
    let result = _.head(this.perimeterlist);
    if (result != undefined && result != "") {
      this.reportForm.patchValue({
        PERIMETER_NAME: result.Key,
        PERIMETER_VALUE: result.Value
      });
    }
    this.dialogHeader = 'view.projecthome.addheader';
    this.saveAction = 'Save';
    this.deleteAction = 'Cancel';
    this.projectReportData = {};
    // this.formValue();
    this.displayDialog = true;
    //this.addReportData = true;
    this.newperemeter = true;
  }


  EditReport(ID) {
    this.message="";
    this.newperemeter = false;
    this.getDropdownValue();
    this.resetform()
    this.dialogHeader = 'view.projecthome.editheader';
    this.saveAction = 'Update';
    this.deleteAction = 'Cancel';
    this.blockedDocument = true;
  
    
    let param = {
      id: ID,
      locale: this.commonservice.getUserlocaleName()
    }
    this._projecthome.getSingleReport(param).subscribe(
      (data: any) => {
        this.displayDialog = true;
        this.blockedDocument = false;
        this.projectReportData = data;
        this.reportForm.controls["ORDER_OF_APPEARANCE"].setValue('');
        this.formValue();
        
        if(data.IS_SPECIFY_OWN_VALUE==1)
        {
          this.checkBoxdefault.nativeElement.checked = false;
          this.checkBoxown.nativeElement.checked = true;  
          this.reportForm.controls["PERIMETER_NAME_OWN"].setValue(this.projectReportData['PERIMETER_NAME']);
        
        }
        else{
          this.checkBoxdefault.nativeElement.checked = true;
          this.checkBoxown.nativeElement.checked = false;
        }
        //-if ownn value is not slected 
       // this.checkBoxdefault.nativeElement.checked = true;
        //if own value selected 
       // this.checkBoxown.nativeElement.checked = true;
        
      },
      (error: any) => this.errorMessage = <any>error
    );
  }

  changeSpecify(value)
  {
    if(value==0){
 this.checkBoxdefault.nativeElement.checked = true;
 this.checkBoxown.nativeElement.checked = false;
 let result = _.head(this.perimeterlist);
 if (result != undefined && result != "") {
   this.reportForm.patchValue({
     PERIMETER_NAME: result.Key,
     PERIMETER_VALUE: result.Value
   });
 }

    }
    else{
      this.checkBoxdefault.nativeElement.checked = false;
      this.checkBoxown.nativeElement.checked = true;
    }
  }

  UpdateReportData() {
    this.message="";
    this.submitted = true;
    if(this.reportForm.valid){
    this.blockedDocument = true;
  
    let selectedvalue = 0
    let checkedvalue=this.checkBoxown.nativeElement.checked; 
    let userid = !_.isNil(this.commonservice.getUserID()) ? this.commonservice.getUserID() : ""
    let formdata = this.reportForm.value;
    if (checkedvalue) {
           
    }
    else{
      if (!_.isNil(formdata.PERIMETER_NAME)) {
        let obj = this.perimeterlist.filter(x => x.Key == formdata.PERIMETER_NAME)
        selectedvalue = obj[0].Value
      } 
    }

    this.reqParams.savePerimeterDetails.USER_MAJ = this.commonservice.getUserID()
    this.reqParams.savePerimeterDetails.USER_CREATION = this.commonservice.getUserID()
   this.reqParams.userLocale=this.commonservice.getUserlocaleName()
    this.reqParams.savePerimeterDetails.NAME = formdata.NAME
    this.reqParams.savePerimeterDetails.PERIMETER_NAME = (formdata.PERIMETER_NAME != undefined ? formdata.PERIMETER_NAME : "")
    this.reqParams.savePerimeterDetails.PERIMETER_VALUE = selectedvalue != undefined ? selectedvalue : 0
   // this.reqParams.savePerimeterDetails.PERIMETER_VALUE = (formdata.PERIMETER_VALUE!=undefined?formdata.PERIMETER_VALUE:-1)
    this.reqParams.savePerimeterDetails.COMMENTS = (formdata.COMMENTS != undefined ? formdata.COMMENTS : "")
    this.reqParams.savePerimeterDetails.URL = (formdata.URL != undefined ? formdata.URL : "")
    this.reqParams.savePerimeterDetails.REPORT_ID_FK = 0
    this.reqParams.savePerimeterDetails.PROJECT_ID_TITAN = parseInt(this.commonservice.getProjectId())
    this.reqParams.savePerimeterDetails.ORDER_OF_APPEARANCE = (formdata.ORDER_OF_APPEARANCE != undefined ? formdata.ORDER_OF_APPEARANCE : 0)
    this.reqParams.savePerimeterDetails.IS_SPECIFY_OWN_VALUE =(formdata.IS_SPECIFY_OWN_VALUE!=undefined?formdata.IS_SPECIFY_OWN_VALUE:-1);
 
    if (checkedvalue){
      this.reqParams.savePerimeterDetails.PERIMETER_NAME = formdata.PERIMETER_NAME_OWN
      this.reqParams.savePerimeterDetails.PERIMETER_VALUE = -1
      this.reqParams.savePerimeterDetails.IS_SPECIFY_OWN_VALUE = 1

    }
    else{
      this.reqParams.savePerimeterDetails.IS_SPECIFY_OWN_VALUE = 0
      this.reqParams.savePerimeterDetails.PERIMETER_NAME = formdata.PERIMETER_NAME
    }

    //If Crete new  report

    if (this.newperemeter) {
      this.reqParams.savePerimeterDetails.ID = formdata.ID != null ? formdata.ID : 0
      this.reqParams.type = RECORD_TYPE_UPDATE;

    }
    else {
      this.reqParams.type = RECORD_TYPE_SAVE;
      this.reqParams.savePerimeterDetails.USER_CREATION = "";
      this.reqParams.savePerimeterDetails.ID = this.projectReportData['ID'];
      console.log(this.projectReportData['ID']);
    }

    // if (this.addReportData) {      
    console.log(JSON.stringify(this.reqParams));
    // Create new config
    this._projecthome.createPerimeterData(JSON.stringify(this.reqParams)).subscribe(
      (data: any) => {
        if (data.SavePerimeterDetailsResult.result) {
          this.message = data.SavePerimeterDetailsResult.Message;
          this.getProjectReportData(this.dropdownValue);
          this.getPerimeterCountList();
          console.log(this.message);
          this.displayDialog = false;
          this.submitted=false;
          if(this.newperemeter){
          this.showToast('success', 'view.projecthome.createdMsg', '');}

          else{this.showToast('success', 'view.projecthome.updatedMsg', '');}
        }
        else {
          this.message = data.SavePerimeterDetailsResult.Message;
        }
      },
      (error: any) => this.errorMessage = <any>error
    );

    //}
    //else{   
    console.log('Edit Report data');
    // Create new config

    }else {return false}
    //}
  }

  deletePerimeter(ID) {

    let parmDelete = 
    { "perimeterReportID": ID,
    "userLocale":this.commonservice.getUserlocaleName() 
  }
    this.confirmationService.confirm({
      message: this.translate.instant(this.msg),
      header: this.translate.instant(this.headerMsg),
      icon: 'pi pi-exclamation-triangle',
      acceptLabel:this.translate.instant(this.acceptMsg),
          rejectLabel:this.translate.instant(this.rejectMsg),
      accept: () => {
        this._projecthome.deleteProject(JSON.stringify(parmDelete)).subscribe(
          (data: any) => {
            if (data.result) {
              this.getProjectReportData(this.dropdownValue);
              this.getPerimeterCountList();
              this.blockedDocument = false;
              //this.selectColReportData = null;
              this.showToast('success', 'view.projecthome.deletedMsg', '');
              //this.showToast('success', 'Report Deleted successfully.', '');
            }
            else {
              //this.messageService.add({severity:'success', summary: 'Successful', detail: 'Report Deleted', life: 3000});
            }

          },
          (error: any) => this.errorMessage = <any>error
        );

      }
    });

  }

  toolFormValue(){
    this.toolForm.patchValue({
     NAME:this.toolRecord['NAME'] ,
     URL:this.toolRecord['URL']
    })
  }

  getContentSectionDetailsOfTool(){
  let reqparams={
    "Type":TOOL_TYPE_ID,
    "UserLocale":this.commonservice.getProjectLocale(),
    "ProjectID":this.commonservice.getProjectId()
  }
  this._projecthome.getContentSectionDetailsByType(reqparams).subscribe(
    (data:any)=>{
      this.toolList=data;
    }
  )
  }

  getContentSectionDetailsOfLink(){
    let reqparams={
      "Type":LINK_TYPE_ID,
      "UserLocale":this.commonservice.getProjectLocale(),
      "ProjectID":this.commonservice.getProjectId()
    }
    this._projecthome.getContentSectionDetailsByType(reqparams).subscribe(
      (data:any)=>{
        this.linkList=data;
      }
    )
    }
  /*create tool */
  createTools(name) {
    this.toolSubmitted=false;
    this.resultToolMsg=""
    this.toolForm.reset();
    if(name==TOOL_HEADER){
    this.dialogHeader = 'Create New Tool';
    this.typeParams=TOOL_TYPE_ID
  }
    else if(name==LINK_HEADER){
      this.dialogHeader = 'Create New Link';
      this.typeParams=LINK_TYPE_ID
    }
    this.saveAction = 'Save';
    this.deleteAction = 'Cancel';
    this.projectReportData = {};
    this.displayTool = true;
    this.newTool = true;

  }

  EditTool(ID) {
    this.toolSubmitted=false;
    this.toolForm.reset();
    this.resultToolMsg=""
    this.dialogHeader = 'Edit Tool';
    this.saveAction = 'Update';
    this.deleteAction = 'Cancel';
    this.displayTool = true;
    this.newTool = false;
    let reqparams={
      "ID":ID,
      "UserLocale":this.commonservice.getUserlocaleName()
    }
    this._projecthome.getContentSectionDetails(reqparams).subscribe(
      (data:any)=>{
        this.toolRecord=data;
        console.log(data)
        this.toolFormValue()
      }
    )
  }
saveTool(){
  this.toolSubmitted=true;
  if(this.toolForm.valid){
  let formdata=this.toolForm.value;
  let reqParams={
    "saveContentSectionDetails":{
      "ID":"0",
      "NAME":formdata.NAME,
      "URL":formdata.URL,
      "TYPE":this.typeParams,
      "PROJECT_ID":this.commonservice.getProjectId(),
      "USER_CREATION":this.commonservice.getUserID(),
      "USER_MAJ":this.commonservice.getUserID(),
      
      
    },
    "type":"",
    "userLocale":this.commonservice.getUserlocaleName()
  }
  if(this.newTool){
    reqParams.type=RECORD_TYPE_UPDATE
    reqParams.saveContentSectionDetails.ID=formdata.ID != null ? formdata.ID : 0
  }
  else
  {
    reqParams.type=RECORD_TYPE_SAVE
    reqParams.saveContentSectionDetails.ID=this.toolRecord['ID']
    reqParams.saveContentSectionDetails.TYPE=this.toolRecord['TYPE']
    reqParams.saveContentSectionDetails.PROJECT_ID=this.toolRecord['PROJECT_ID']
    reqParams.saveContentSectionDetails.USER_CREATION=this.toolRecord['USER_CREATION']
   
  }
  this._projecthome.saveContentSectionDetails(reqParams).subscribe(
    (response:any)=>{
      if(response.SaveContentSectionDetailsResult.result){
        this.displayTool=false
        if(this.newTool){
        this.showToast('success', 'view.tool.successMsg', '');}
        else{
          this.showToast('success', 'view.tool.updatedMsg', '');
        }
        this.getContentSectionDetailsOfLink()
        this.getContentSectionDetailsOfTool()
      }
      else
      this.resultToolMsg=response.SaveContentSectionDetailsResult.Message
    }
  )
 
  
}else {return false;}
}



  deleteTool(ID) {
    let reqparams={
    "ID":ID,
    "userLocale":this.commonservice.getUserlocaleName()
    }
    this.confirmationService.confirm({
      message: this.translate.instant(this.msg),
      header: this.translate.instant(this.headerMsg),
      icon: 'pi pi-exclamation-triangle',
      acceptLabel:this.translate.instant(this.acceptMsg),
          rejectLabel:this.translate.instant(this.rejectMsg),
      accept: () => {
        this._projecthome.deleteContentSectionByID(reqparams).subscribe(
          (response:any)=>{
            if(response.DeleteContentSectionByIDResult.result){
              this.getContentSectionDetailsOfLink()
              this.getContentSectionDetailsOfTool()
              this.showToast('success', 'view.tool.successDeleteMsg', '')
            }
          }
        )
      }
    });

  }

  cancel() {
    this.displayDialog = false;
    this.displayTool = false;
    this.blockedDocument = false;
    this.submitted=false;
    this.toolSubmitted=false;
    this.resultToolMsg=""
    this.toolForm.reset()
    
  }
  testURL(){
    let url=this.reportForm.get("URL").value
    if(url!=null && url!="" &&  url!=undefined)
    {
      let URL_REGEXP =  "^https?:\/\/(.*)"
     let valid= url.match(URL_REGEXP)
    if(valid!=null && valid!="" &&  valid!=undefined)
      window.open(url, "_blank");
    }
    else{
      return false
    }
  }
/*get rich text box content section*/
getRichtextBoxContent()
{
  let req={
    "projectID":this.commonservice.getProjectId(),
    "userLocale":this.commonservice.getUserlocaleName()
  }
  this._projecthome.getRichBoxtextContentByProjectId(req).subscribe((data:any)=>{
     this.contentSectionText=data.COMMENTS 
  })
  }
  /*save content section rich text box*/
  saveContentSection(comments){
    let req={
      "contentRichTextBoxDetails":
      {
        "PROJECT_ID":this.commonservice.getProjectId(),
       "COMMENTS":comments,
       "UserLocale":this.commonservice.getUserlocaleName()
      }
    }
    this._projecthome.saveContentSectionRichTextBox(req).subscribe((response:any)=>{
      if(response.SaveContentSectionRichTextBoxResult.result){
        this.message=response.SaveContentSectionRichTextBoxResult.Message;
        this.showToast('success', 'view.projecthome.saveContentMsg', '');
      }
      else
      this.message=response.SaveContentSectionRichTextBoxResult.Message;
    })

  }
/* Auto Complete */
searchName(event) {
  // this..getResults(event.query).then(data => {
  //     this.results = data;
  // });
}

  textareaTextChange(event){
    console.log(event);
    this.isToolBarActive = false;
  }

// reportUrlNavigation(url){ 
// let projectName=this.commonservice.getProjectName();
// if(projectName!="" && projectName!=null && projectName!="undefined")
// {
//   let str=url.concat(REPORT_URL)
//   let strConcat= REPORT_URL_TEXT.concat(projectName,"]")

//  let encodedURL= encodeURIComponent(strConcat)
//  let str1=str.concat(encodedURL)
//   window.open(url,"_blank")


// }
}
