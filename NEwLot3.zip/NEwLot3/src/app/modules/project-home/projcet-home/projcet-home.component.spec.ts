import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjcetHomeComponent } from './projcet-home.component';

describe('ProjcetHomeComponent', () => {
  let component: ProjcetHomeComponent;
  let fixture: ComponentFixture<ProjcetHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjcetHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjcetHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
