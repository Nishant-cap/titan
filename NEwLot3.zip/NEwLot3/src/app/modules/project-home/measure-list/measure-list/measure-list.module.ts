import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MeasureListRoutingModule } from './measure-list-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { LeaveGuard } from '../../beforeunload/leave.guard';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MeasureListRoutingModule,
    TranslateModule
  ],
  providers: [
    LeaveGuard
   ]
})
export class MeasureListModule { 
  
}
