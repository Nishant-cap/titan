import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { CodificationGuard } from 'src/app/guards/codification.guard';
import { Role } from 'src/app/shared/model/role';
import { LeaveGuard } from '../../beforeunload/leave.guard';
import { CodificationSeaComponent } from '../../codification-sea/codification-sea.component';
import { MeasureListComponent } from '../measure-list.component';


const routes: Routes = [
  {path:'',component:MeasureListComponent},
  {path:'codification/:id',canDeactivate:[LeaveGuard],data: { breadcrumb: 'Codification',traskey:'Codification',isProjectPage:true,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ]},canActivate:[AuthGuard],component:CodificationSeaComponent},
  {path:'codification/:id/:grossNo',canDeactivate:[LeaveGuard],data: { breadcrumb: 'Codification',traskey:'Codification',isProjectPage:true,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ]},canActivate:[CodificationGuard],component:CodificationSeaComponent},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MeasureListRoutingModule { }
