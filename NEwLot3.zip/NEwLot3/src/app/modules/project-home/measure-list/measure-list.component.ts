import { Component, OnInit, SimpleChanges } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { TranslateService } from '@ngx-translate/core';
import { MeasurelistService } from 'src/app/service/measurelist.service';
import { DateAdapter } from '@angular/material/core';
import * as _ from 'node_modules/lodash';
import { FormControl } from '@angular/forms';
import { CommonService } from 'src/app/service/common.service';
import { DatePipe } from '@angular/common';
import { config } from 'src/app/shared/config/config';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router'
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ProjectService } from 'src/app/service/project.service';
import { MeasureSearchPipe } from 'src/app/shared/pipes/measure-search.pipe';
@Component({
  selector: 'app-measure-list',
  templateUrl: './measure-list.component.html',
  styleUrls: ['./measure-list.component.scss'],
  providers: [DatePipe, MeasureSearchPipe]
})

export class MeasureListComponent implements OnInit {
  datePickerCtrl = new FormControl();
  unsubscribe$: Subject<boolean> = new Subject();
  x: any;
  sortList: any[];
  mainList: any[];
  constructor(private _router: Router, private comonservice: CommonService, private headerService: HeaderChangeService,
    private activerouter: ActivatedRoute, private dateAdapter: DateAdapter<any>,
    public projectservice: ProjectService,
    public measureSearchPipeData: MeasureSearchPipe,
    private httpClient: HttpClient, private translate: TranslateService,private datePipe: DatePipe,
    private measureservice: MeasurelistService, private activateRoute: ActivatedRoute) {

  }
  enableLoader: boolean = true
  pageIndex: number = 1
  projectid:any
  measures = {
    "records": [],
    "pagination": null
  }
  errorMessage: string = ""
  sortObj = {
    currentColumn: '',
    previousColumn: '',
    order: 'ASC'
  };
  filter = {
    "testType": "",
    "contremarque": "",
    "vis": "",
    "silhouette": "",
    "phase": "",
    "dateEmonfrom": "",
    "dateEmonto": "",
    "dateModifSparteNeo": { "from": "", "to": "" },
    "seriousDefects": "",
    "totalPoints": "",
    "statutSparteNeo": [],
    "statutTitan": [],
    "datelastModFrom": "",
    "datelastModTo": ""
  };
  statutSparteNeoMap = {
    "VAL": { "value": "valide1", "srcIcon": "assets/images/check.png", "i18nTooltip": "status.sparteNeo.val1.tooltip", "order": 1 },
    "CNF": { "value": "valide2", "srcIcon": "assets/images/check_green.png", "i18nTooltip": "status.sparteNeo.val2.tooltip", "order": 2 },
    "PUB": { "value": "valide2", "srcIcon": "assets/images/check_green.png", "i18nTooltip": "status.sparteNeo.val2.tooltip", "order": 2 },
    "ENV": { "value": "crayon", "srcIcon": "assets/images/edit.png", "i18nTooltip": "status.sparteNeo.pencil.tooltip", "order": 0 },
    "ANNUL": { "value": "poubelle", "srcIcon": "assets/images/papelera.png", "i18nTooltip": "status.sparteNeo.trash.tooltip", "order": 3 },
    "SOLDE": { "value": "valide2", "srcIcon": "assets/images/check_green.png", "i18nTooltip": "status.sparteNeo.val2.tooltip", "order": 2 },
    "NONSOLDE": { "value": "valide1", "srcIcon": "assets/images/check.png", "i18nTooltip": "status.sparteNeo.val1.tooltip", "order": 1 }
  };
  statutTitanMap = {
    0: { "srcIcon": "assets/images/blocked.png", "i18nTooltip": "status.titan.nodata.tooltip", "order": 4 },
    10: { "srcIcon": "assets/images/initial.png", "i18nTooltip": "status.titan.draft.tooltip", "order": 0 },
    20: { "srcIcon": "assets/images/edit.png", "i18nTooltip": "status.titan.pencil.tooltip", "order": 1 },
    30: { "srcIcon": "assets/images/check.png", "i18nTooltip": "status.titan.valid.tooltip", "order": 2 },
    40: { "srcIcon": "assets/images/mail.png", "i18nTooltip": "status.titan.envelop.tooltip", "order": 3 }
  };

  statutTitanMapnew: any[] = [

    { "id": 0, "srcIcon": "assets/images/blocked.png", "i18nTooltip": "status.titan.nodata.tooltip", "order": 4 },
    { "id": 10, "srcIcon": "assets/images/initial.png", "i18nTooltip": "status.titan.draft.tooltip", "order": 0 },
    { "id": 20, "srcIcon": "assets/images/edit.png", "i18nTooltip": "status.titan.pencil.tooltip", "order": 1 },
    { "id": 30, "srcIcon": "assets/images/check.png", "i18nTooltip": "status.titan.valid.tooltip", "order": 2 },
    { "id": 40, "srcIcon": "assets/images/mail.png", "i18nTooltip": "status.titan.envelop.tooltip", "order": 3 }
  ];
  statutSparteNeoMapnew = [
    { "id": "ENV", "value": "crayon", "srcIcon": "assets/images/edit.png", "i18nTooltip": "status.sparteNeo.pencil.tooltip", "order": 0 },
    { "id": "ANNUL", "value": "poubelle", "srcIcon": "assets/images/papelera.png", "i18nTooltip": "status.sparteNeo.trash.tooltip", "order": 3 },
    { "id": "VAL", "value": "valide1", "srcIcon": "assets/images/check.png", "i18nTooltip": "status.sparteNeo.val1.tooltip", "order": 1 },
    {
      "id": "SOLDE", "value": "valide2", "srcIcon": "assets/images/check_green.png", "i18nTooltip": "status.sparteNeo.val2.tooltip", "order": 2

    }];

  codifStateIconMap = {
    "INIT": { "srcIcon": "assets/images/completion_empty.png" },
    "DRAFT": { "srcIcon": "assets/images/completion_middle.png" },
    "CODED": { "srcIcon": "assets/images//completion_full.png" }
  };
  

  ngOnInit() {
   const projectId = this.activateRoute.snapshot.paramMap.get('id');   
   this.comonservice.setProjectId(projectId);
   this.projectid = this.comonservice.getProjectId()
   this.projectservice.getprojectDetailById(this.projectid).subscribe((data: any) => {      
     this.comonservice.setProjectName(data.URL_SITE)
     this.comonservice.setProjectLocale(data.LOCALE)
 })
    this.headerService.changeLeftpanel(true)
   

    this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => {
      let selectedlanguage = language
      if (selectedlanguage != null && selectedlanguage != "" && selectedlanguage != undefined) {
        this.measures.records = []; this.measures.pagination = "";
        this.getmeasureList();
        let dataUserLang = this.comonservice.getUserlocaleName();
         let changedlocale = dataUserLang.replace(/_/, "-")
        // this.dateAdapter.setLocale(changedlocale);
      }
      else{
        this.getmeasureList();
      }
    });

    // fixing for NE28061-47 UserAcceptanceTesting:Upload and Export ManualImport Issues 
    // this.getmeasureList();
    
  }

  getmeasureList() {
  
  let reqParams = {
    "pageNumber": 0,
    "pageSize": config.pageSize,
    "locale": "",
    "projectId": this.projectid
  }

    this.enableLoader = true;
    reqParams.pageNumber = this.pageIndex
    reqParams.locale = this.comonservice.getUserlocaleName()
    this.measureservice.getRecords(reqParams).subscribe(res => {
    
      // this.measures = res;
      let dataarray = res.data
      let resresult = [];
      if (!_.isNil(dataarray) && dataarray.length > 0) {

        dataarray.forEach(element => {
          let currentStatutSparteNeoMap = this.statutSparteNeoMap[element.STATUT];
          if (!currentStatutSparteNeoMap) {
            currentStatutSparteNeoMap = { "value": "default", "srcIcon": "assets/image/question.png", "order": 100 }
          }
          let currentStatutTitanMap = this.statutTitanMap[element.STATUT_TITAN];
          if (!currentStatutTitanMap) {
            currentStatutTitanMap = { "srcIcon": "assets/image/question.png", "order": 100 }
          }

          let measureEnabled = true;
          let statutTitan = element.STATUT_TITAN;
          if (statutTitan == "0" || statutTitan == "00")
            measureEnabled = false;

          let currentMeasure = {
            "id": element.ID,
            "silhouette": element.CODE_SILHOUETTE,
            "contremarque": !element.CONTREMARQUE ? "" : element.CONTREMARQUE.toString(),
            "creationDate": !element.DATE_CREATION ? null : new Date(parseInt(element.DATE_CREATION.substr(6))),
            "dateEmon": !element.DATE_EMON ? null : new Date(parseInt(element.DATE_EMON.substr(6))),
            "testDate": !element.DATE_ESSAI ? null : new Date(parseInt(element.DATE_ESSAI.substr(6))),
            "modifiedDateSparteNeo": !element.DATE_MAJ_BRUT ? null : new Date(parseInt(element.DATE_MAJ_BRUT.substr(6))),
            "modificationDateBrut": !element.DATE_MAJ_BRUT ? null : new Date(parseInt(element.DATE_MAJ_BRUT.substr(6))),
            "modificationDateDefTitan": !element.DATE_MAJ_DEF_TITAN ? null : new Date(parseInt(element.DATE_MAJ_DEF_TITAN.substr(6))),
            "idProjectNeo": element.ID_PROJET_NEO != null ? element.ID_PROJET_NEO : "",
            "idProjectSparte": element.ID_PROJET_SPARTE != null ? element.ID_PROJET_SPARTE : "",
            "idProjectTitan": element.ID_PROJET_TITAN != null ? element.ID_PROJET_TITAN : "",
            "idVehicle": element.ID_VEHICULE != null ? element.ID_VEHICULE : "",
            "phase": element.STADE_PROJET != null ? element.STADE_PROJET.toString() : "",
            "statutSparteNeoOriginal": element.STATUT != null ? element.STATUT : "",
            "statutSparteNeo": currentStatutSparteNeoMap.value != null ? currentStatutSparteNeoMap.value : "",
            "statutSparteNeoIconSrc": currentStatutSparteNeoMap.srcIcon != null ? currentStatutSparteNeoMap.srcIcon : "",
            "statutSparteNeoIconTooltip": currentStatutSparteNeoMap.i18nTooltip != null ? currentStatutSparteNeoMap.i18nTooltip : "",
            "statutSparteNeoOrder": currentStatutSparteNeoMap.order != null ? currentStatutSparteNeoMap.order : "",
            "statutTitan": statutTitan,
            "statutTitanIconSrc": currentStatutTitanMap.srcIcon != null ? currentStatutTitanMap.srcIcon : "",
            "statutTitanIcon18nTooltip": currentStatutTitanMap.i18nTooltip != null ? currentStatutTitanMap.i18nTooltip : "",
            "statutTitanOrder": currentStatutTitanMap.order != null ? currentStatutTitanMap.order : "",
            "seriousDefects": element.TOTAL_DEFAUTS_GRAVES != null ? element.TOTAL_DEFAUTS_GRAVES : "",
            "totalPoints": element.TOTAL_POINTS != null ? element.TOTAL_POINTS : "",
            "testType": element.LIB_TYPE_ESSAI != null ? element.LIB_TYPE_ESSAI : "",
            "userCreation": element.USER_CREATION != null ? element.USER_CREATION : "",
            "userModification": element.USER_MAJ != null ? element.USER_MAJ : "",
            "vis": element.VIN != null ? element.VIN : (element.VIS != null ? element.VIS : ""),
            "measureEnabled": measureEnabled,
            "emailSentDate": !element.DATE_ENVOI_EMAIL ? null : new Date(parseInt(element.DATE_ENVOI_EMAIL.substr(6))),
            "numDefautsNotLinked": element.numDefautsNotLinked != null ? element.numDefautsNotLinked : "",
            "numDefautsAnnulleLinked": element.numDefautsAnnulleLinked != null ? element.numDefautsAnnulleLinked : "",
            "NumDefautsAddedAfterMailSendingNotCoded": element.numDefautsAddedAfterMailSendingNotCoded != null ? element.numDefautsAddedAfterMailSendingNotCoded : "",
            "NumDefautsDeletedAfterMailSendingLinked": element.numDefautsDeletedAfterMailSendingLinked != null ? element.numDefautsDeletedAfterMailSendingLinked : "",
            "showWarning": !(!element.numDefautsNotLinked && !element.numDefautsAddedAfterMailSendingNotCoded && !element.numDefautsDeletedAfterMailSendingLinked),

          };
          
          resresult.push(currentMeasure);

        })
        this.enableLoader = false
      }
     
      this.measures.pagination = res.pagination;
      this.measures.records = this.measures.records.concat(resresult);
      this.sortList = this.measures.records;
      this.mainList = this.measures.records;
      this.enableLoader = false
    },
      responseError => {

        this.errorMessage = JSON.stringify(responseError);
        console.log(JSON.stringify(responseError))
        this.enableLoader = false;
      }
    )
  }

  onFilter(event){

  }

  // sorting 
  sortFTs(prop, evt) {
    console.log("this.sortList sort first", this.sortList);
    let asc = false;
    this.sortObj.currentColumn = prop;
    this.sortObj.order = this.sortObj.order == "DESC" ? 'ASC' : 'DESC';
    if (this.sortObj.currentColumn != this.sortObj.previousColumn) {
      this.sortObj.previousColumn = this.sortObj.currentColumn
    }
    if (this.sortObj.order == 'ASC') { asc = true }
    else { asc = false };

    if(this.filter.contremarque == "" && this.filter.dateEmonfrom == "" && this.filter.dateModifSparteNeo.from == "" &&
    this.filter.dateModifSparteNeo.to == "" && this.filter.datelastModTo == "" && this.filter.phase == "" && 
    this.filter.seriousDefects == "" && this.filter.silhouette == "" && this.filter.statutSparteNeo.length == 0 && 
    this.filter.statutTitan.length == 0 && this.filter.testType == "" && this.filter.totalPoints == "" && 
    this.filter.vis == "" ){
        this.measures.records = this.sortList;
        console.log(this.sortList, "sort list");  
      }
      else{
        let abc = localStorage.getItem('measureData')
        this.x = JSON.parse(abc);
        this.sortList = this.x;
      }

    this.measures.records = this.sortList.sort(function (a, b) {
      if (asc) return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
      else return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);  
    });
    // return false;

  }
  // lazy loading 
  onScroll() {
    if (!this.enableLoader) {
      if (this.measures.pagination.nextPage > 0) {
        this.pageIndex += 1;
        this.getmeasureList();
      }
    }
  }
  
  selectMeasure(fect) {
    console.log(fect, "fect");
    
    if (fect.measureEnabled) {
      this._router.navigate(['codification', fect.id], { relativeTo: this.activerouter.parent });
    }
  }

  updateMFD(obj) {
    this.enableLoader = true;
    console.log("item", obj)
    let req =
    {
      "CM": obj.contremarque,
      "VIS": obj.vis,
      "VIN": "",
      "EmonDate": obj.dateEmon,
      "UserName": this.comonservice.getUserID()
    }


    this.measureservice.updateTNTQTB2DateEmon(req).subscribe(res => {
      if (res.UpdateTNTQTB2DateEmonResult) {
        this.enableLoader = false
      }
      else {
        this.enableLoader = false
      }
    }, error => {
      this.enableLoader = false
      console.log(JSON.stringify(error))
    })

  }
  clearFilters = function () {
    this.filter = {
      "testType": "",
      "contremarque": "",
      "vis": "",
      "silhouette": "",
      "phase": "",
      "dateEmonfrom": "",
      "dateEmonto": "",
      "dateModifSparteNeo": { "from": "", "to": "" },
      "seriousDefects": "",
      "totalPoints": "",
      "statutSparteNeo": [],
      "statutTitan": [],
      "datelastModFrom": "",
      "datelastModTo": ""
    };
      return this.measures.records = this.mainList;

  }
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}