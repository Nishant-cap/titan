import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CodificationETSComponent } from './codification-ets.component';

describe('CodificationETSComponent', () => {
  let component: CodificationETSComponent;
  let fixture: ComponentFixture<CodificationETSComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CodificationETSComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CodificationETSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
