import { Component, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { UploadAndExportService } from 'src/app/service/upload-and-export.service';
import { VehicleService } from 'src/app/service/vehicle.service';
import { CommonService } from 'src/app/service/common.service';
import * as _ from 'node_modules/lodash';
import { EventEmitter } from 'events';
import { CodificationSeaComponent } from '../codification-sea/codification-sea.component';
import { ProjectService } from 'src/app/service/project.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-codification-ets',
  templateUrl: './codification-ets.component.html',
  styleUrls: ['../../../../styles/titan.scss','./codification-ets.component.scss'],
})
export class CodificationETSComponent implements OnInit {
  @Input('function') function: any;
  image; @Input('source') source: any; vehicalForm: FormGroup; errormessage: string
  vehicleInfo: any; launchList: any; submitted: boolean = false; tagList: any[]; enablesaveBtn: boolean = false
  togglemodel: boolean = false
  projectid: any
  vinErrorMgs = ""
  constructor(private fb: FormBuilder, private uploadExportService: UploadAndExportService, private commonservice: CommonService,
    private translate: TranslateService, private vehicleservice: VehicleService, private projectservice: ProjectService,
    private activateRoute: ActivatedRoute,
  ) {
    this.vehicalForm = this.fb.group({
      CM: [''],
      CMNonEditable: [''],
      SiteFab: ['', Validators.required],
      VIS: [''],
      VISNonEditable: [''],
      StadeProject: [''],
      CONTREMARQUE: [''],
      VIN: [''],
      VINNonEditable: [''],
      EMON: ['', Validators.required],
      Silhouette: ['', Validators.required],
      NiveauFinition: ['', Validators.required],
      Direction: ['', Validators.required],
      Moteur: ['', Validators.required],
      BV: ['', Validators.required],
      CouleurdeCaisse: [''],
      Autre1: [''],
      Autre3: [''],
      Autre2: [''],
      Tags: [''],
      Lancement: ['', Validators.required]

    });

  }

  ngOnInit() {



  }
  get f() { return this.vehicalForm.controls; }
  ngOnChanges(changes: SimpleChanges) {
    this.vehicleInfo = this.source.vehicleInfo

  }
  /***
    * calls on pop up toggle
    * Author:Shweta
    * created 19/03/2021
    * updated:
    */
  changeToggle(): void {
    this.vinErrorMgs = ""
    this.launchList = []
    this.errormessage = ""
    this.enablesaveBtn = false
    this.togglemodel = !this.togglemodel
    if (this.togglemodel) {
      this.getLaunchId();
      this.getVehiclerecord();
    }
  }
  /***
   * to get vehicle details on load
   * Author:Shweta
   * created 19/03/2021
   * updated:
   */
  getVehiclerecord() {

    const projectId = this.activateRoute.parent.snapshot.params.id;
    //this.projectid = this.commonservice.decryptID(projectId)
    this.commonservice.setProjectId(projectId);

    this.projectservice.getprojectDetailById(projectId).subscribe((data: any) => {
      this.commonservice.setProjectName(data.URL_SITE)
      this.commonservice.setProjectLocale(data.LOCALE)
    })
    let launchId = this.source.vehicleInfo.id
    let tagvalues = ""
    if (launchId > 0) {
      let req = {
        "VehicleID": launchId,
        "ProjectID": this.commonservice.getProjectId(),
        "Locale": this.commonservice.getUserlocaleName(),
        "UserName": this.commonservice.getUserID()

      }
      this.vehicleservice.getvehicles(req).subscribe(
        (data: any) => {
          let vehicle: any;
          if (data != null) {
            let element = data;
            vehicle = {
              "id": element.ID,
              "SITEFAB": !_.isNil(element.CODE_CENTRE_FABRICATION) ? element.CODE_CENTRE_FABRICATION : "",
              "Couleurdecaisseisse": !_.isNil(element.CODE_COULEUR_CAISSE) ? element.CODE_COULEUR_CAISSE : "",
              "CouleurHabInt": !_.isNil(element.CODE_COULEUR_HAB_EXT) ? element.CODE_COULEUR_HAB_EXT : "",
              "Direction": !_.isNil(element.CODE_DIRECTION) ? element.CODE_DIRECTION : "",
              "TypehabillageExt": !_.isNil(element.CODE_HAB_EXT) ? element.CODE_HAB_EXT : "",
              "HabillageInt": !_.isNil(element.CODE_HAB_INT) ? element.CODE_HAB_INT : "",
              "NiveauFinition": !_.isNil(element.CODE_NIV_FINITION) ? element.CODE_NIV_FINITION : "",
              "Silhouette": !_.isNil(element.CODE_SILHOUETTE) ? element.CODE_SILHOUETTE : "",
              "BV": !_.isNil(element.CODE_TYPE_BOITE) ? element.CODE_TYPE_BOITE : "",
              "Moteur": !_.isNil(element.CODE_TYPE_MOTEUR) ? element.CODE_TYPE_MOTEUR : "",
              "CM": !_.isNil(element.CONTREMARQUE) ? element.CONTREMARQUE : "",
              "EMON": !element.DATE_EMON ? null : new Date(parseInt(element.DATE_EMON.substr(6))),
              "STADE_PROJET": !_.isNil(element.STADE_PROJET) ? element.STADE_PROJET : "",
              "VISV": !_.isNil(element.VIS) ? element.VIS : "",
              "VIN": !_.isNil(element.VIN) ? element.VIN : "",
              "Tags": !_.isNil(element.TAGS) ? element.TAGS : "",
              "Lancement": !_.isNil(element.ID_LANCEMENT) ? element.ID_LANCEMENT : 0,


            };
            if (!_.isEmpty(vehicle.Tags))
              tagvalues = vehicle.Tags.map(x => x).join(";")
            this.vehicalForm.patchValue({
              CM: vehicle.CM,
              CMNonEditable: vehicle.CM,
              SiteFab: vehicle.SITEFAB,
              VIS: vehicle.VISV,
              VISNonEditable: vehicle.VISV,
              StadeProject: vehicle.STADE_PROJET,
              VIN: vehicle.VIN,
              VINNonEditable: vehicle.VIN,
              EMON: vehicle.EMON,
              Lancement: vehicle.Lancement,
              Silhouette: vehicle.Silhouette,
              NiveauFinition: vehicle.NiveauFinition,
              Direction: vehicle.Direction,
              Moteur: vehicle.Moteur,
              BV: vehicle.BV,
              CouleurdeCaisse: vehicle.Couleurdecaisseisse,
              Autre1: vehicle.TypehabillageExt,
              Autre3: vehicle.HabillageInt,
              Autre2: vehicle.CouleurHabInt,
              Tags: tagvalues
            });
          }
          this.vehicalForm.disable()

        },
        responseError => {
          this.errormessage = JSON.stringify("Internal server error")
          this.vehicalForm.disable()
        });
    }
  }
  /*check validation before save*/
  checkValidation() {
    this.errormessage = ""
    this.vinErrorMgs = ""
    this.submitted = true
    if (this.vehicalForm.valid) {

      let vin = this.vehicalForm.controls['VIN'].value
      let vis = this.vehicalForm.controls['VIS'].value
      let vinlast8Digit = vin.substr(-8)
      if (vin != null && vin != "" && vin != undefined) {
        if (vin.length != 17) {
          this.vinErrorMgs = "vin.main.validation"
          //this.vehicalForm.controls["VIN"].enable();
        } else {
          if (vis && vin) {
            if (vis == vinlast8Digit) {
              this.addvehicldetail()
            }
            else {
              this.errormessage = "vis.main.validation"
            }
          }
          else {
            this.vinErrorMgs = ""
            this.addvehicldetail()
          }
        }
      } else {
        this.vinErrorMgs = ""
        this.addvehicldetail()
      }
    }
  }
  /***
     * to save vehicle details
     * Author:Shweta
     * created 19/03/2021
     * updated:
     */
  addvehicldetail() {

    let formdata = this.vehicalForm.value
    
    let params =
    {
      "vehicleUpdateRequest":
      {
        "CODE_CENTRE_FABRICATION": formdata.SiteFab,
        "CODE_COULEUR_CAISSE": formdata.CouleurdeCaisse,
        "CODE_COULEUR_HAB_EXT": formdata.Autre2,
        "CODE_DIRECTION": formdata.Direction,
        "CODE_HAB_EXT": formdata.Autre1,
        "CODE_HAB_INT": formdata.Autre3,
        "CODE_NIV_FINITION": formdata.NiveauFinition,
        "CODE_SILHOUETTE": formdata.Silhouette,
        "CODE_TYPE_BOITE": formdata.BV,
        "CODE_TYPE_MOTEUR": formdata.Moteur,
        "DATE_EMON": formdata.EMON,
        "ID_LANCEMENT": formdata.Lancement,
        "STADE_PROJET": formdata.StadeProject,
        // "CONTREMARQUE": formdata.CMNonEditable,
        "CONTREMARQUE": this.vehicalForm.controls['CM'].value,
        "USER_MAJ": this.commonservice.getUserID(),
        // "VIS": formdata.VISNonEditable,:- commented because new requirement to enable vis and vin if empty
        "VIS": this.vehicalForm.controls['VIS'].value,
        // "VIN": formdata.VINNonEditable,
        "VIN": this.vehicalForm.controls['VIN'].value,
        "Tags": formdata.Tags,
        "ProjectID": this.commonservice.getProjectId(),
        "Locale": this.commonservice.getUserlocaleName(),
        "UserName": this.commonservice.getUserID(),
        "ID": this.source.vehicleInfo.id
      },
      "userLocale": this.commonservice.getUserlocaleName()
    }
    
    if(params.vehicleUpdateRequest.VIN && (_.isNil(params.vehicleUpdateRequest.VIS) || (_.isEmpty(params.vehicleUpdateRequest.VIS)) ) ){
      let vinlast8Digit = params.vehicleUpdateRequest.VIN.substr(-8)
      params.vehicleUpdateRequest.VIS=vinlast8Digit
    }
    this.vehicleservice.savevehicles(params).subscribe(data => {
      if (data[0].Key) {
        this.getVehiclerecord()
        this.errormessage = data[0].Value
        this.function()
      }
      else{
        this.errormessage = data[0].Value;
       
      }
    },
      responseError => {
        this.errormessage = JSON.stringify(responseError)
      });

  }
  /***
   * calls on click of edit button to enable disable form controls
   * Author:Shweta
   * created 19/03/2021
   * updated:
   */
  editvehicleInfo() {
    this.vinErrorMgs = ""
    this.errormessage = ""
    this.enablesaveBtn = true
    this.vehicalForm.enable()
    // new reuirement to enable vis, vin, cm when empty

    if (this.vehicalForm.controls["VIS"].value) {
      this.vehicalForm.controls["VIS"].disable();
    }
    if (this.vehicalForm.controls["CM"].value) {

      this.vehicalForm.controls["CM"].disable();
    }
    if (this.vehicalForm.controls["VIN"].value) {
      this.vehicalForm.controls["VIN"].disable();
    }
  }
  /***
   * get lauchments for binding the laucment dropdown
   * Author:Shweta
   * created 19/03/2021
   * updated:
   */
  getLaunchId() {
    const projectId = this.activateRoute.parent.snapshot.params.id;
    //this.projectid = this.commonservice.decryptID(projectId)
    this.commonservice.setProjectId(projectId);

    this.projectservice.getprojectDetailById(projectId).subscribe((data: any) => {
      this.commonservice.setProjectName(data.URL_SITE)
      this.commonservice.setProjectLocale(data.LOCALE)
    })
    let param = {
      ProjectID: this.commonservice.getProjectId()
    }
    this.uploadExportService.getLaunch(param).subscribe(data => {
      this.launchList = data
    },
      responseError => {
        this.errormessage = JSON.stringify(responseError)
      })
  }
/* on select launch from dropdown*/
  onSelectLaunch($event){
    this.errormessage="Check the VOM impact and the part of Issue /TE if already codified before modifying Launch. If you absolutely want to change the Launch, you have to de-Link each Issue / TE, before to re-Link them with new Launch."
  }
}
