import { Inject, Injectable, Optional } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { CommonService } from 'src/app/service/common.service';


@Injectable({
  providedIn: 'root'
})
export class LeaveGuard implements CanDeactivate<any> {

  constructor(
    private commonService: CommonService,
  
  ) { }

  canDeactivate(
    component: any,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
  
    const  isleave=this.commonService.getChangedCod()
    if(!isleave)
    {
      if(confirm("There are unsaved changes. Do you want to continue without saving?")){
        return true}
        else{
        return false;
        }
    
    }
    else
    return true;
    
  }
}
