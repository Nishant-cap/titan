import { HttpClient, HttpHeaders } from '@angular/common/http';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { config } from 'src/app/shared/config/config';
import * as _ from 'node_modules/lodash';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmationService, MessageService } from 'primeng';
import { min, takeUntil } from 'rxjs/operators';
import { CommonService } from 'src/app/service/common.service';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { ProjectHomeService } from 'src/app/service/launch.service';
import { MailrecipientService } from 'src/app/service/mailrecipient.service';
import { ProjectService } from 'src/app/service/project.service';
import { VehicleDetailsService } from 'src/app/service/vehicle-details.service';
import { Subject } from 'rxjs';
import { EventEmitter } from 'protractor';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-vehicle-details',
  templateUrl: './vehicle-details.component.html',
  styleUrls: ['./vehicle-details.component.scss'],
  providers: [MessageService, ConfirmationService,DatePipe],
})
export class VehicleDetailsComponent implements OnInit {
  cols:any[];
  
  pageIndex: number = 1
  vehicles = {
    "records": [],
    "pagination": null
  }
  msg:string='view.deleteMsg';
headerMsg:string='view.confirmDelete';
acceptMsg:string='view.acceptMsg';
rejectMsg:string='view.rejectMsg';
nextPage:number
vehcileID:any
  dialogHeader;
  unsubscribe$: Subject<boolean> = new Subject();
  vinErrorMgs = ""
  vehicleListData=[]
  vehicledetail={
    "Key":"",
    "Value":""
  }
  popupLoader:boolean=false;
  errorMessage=""
  vehicleForm:FormGroup
  submitted:boolean=false
  enableLoader:boolean=false;
  displayVehicleDailog:boolean=false
  errorMgs:any
  searchFlag:boolean=false;
  newVehicle:Boolean=false
  emonDateFrom:string
  emonDateTo:string
  launchManageData:any
  filterVin:any;
  filterVis:any;
  filterSiteFab:any;
  filterCM:any;
  filterLaunch:any
  minDate: Date;
  maxDate: Date;
  constructor(
    private activateRoute : ActivatedRoute,
    private projectservice:ProjectService,
    private _launchService: ProjectHomeService,
    private commonservice: CommonService,
    private messageService: MessageService,
    private headerService: HeaderChangeService,
    private http: HttpClient,
    private datePipe: DatePipe,
    private translate:TranslateService,
    private confirmationService:ConfirmationService,
    private vehicleDetailsService:VehicleDetailsService,
    private fb:FormBuilder
  ) {
    const currentYear = new Date().getFullYear();
    console.log("date ",currentYear)
    this.minDate = new Date(2021 - 121, 0, 1);
    this.maxDate = new Date(2021 + 6879, 11, 31);
   }

  ngOnInit(): void {
    const projectId = this.activateRoute.snapshot.paramMap.get('id');
    this.commonservice.setProjectId(projectId);
    this.projectservice.getprojectDetailById(projectId).subscribe((data: any) => {      
      this.commonservice.setProjectName(data.URL_SITE)
      this.commonservice.setProjectLocale(data.LOCALE)
  })
  this.headerService.changeLeftpanel(true)
   

    this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => {
      let selectedlanguage = language
      if (selectedlanguage != null && selectedlanguage != "" && selectedlanguage != undefined) {
        
        this.searchVehicleList();
        
      }
      else{
        this.searchVehicleList();
      }
      this.getLaunchData();
  //this.searchVehicleList()
  this.buildVehicleForm()
    });

  this.cols = [
     { field: 'CM', header: 'CM',inputType: 'textDate',sortInput:'required' },
    { field: 'VIS', header: 'VIS'  ,inputType: 'textDate',sortInput:'required'},
    { field: 'VIN', header: 'VIN' ,inputType: 'textDate',sortInput:'required'},
    { field: 'SITE_FAB', header: 'SiteFab' ,inputType: 'textDate',sortInput:'required'},
    { field: 'LANCEMENT', header: 'Launch',inputType: 'textDate',sortInput:'required'},
    { field: 'EMON', header: 'EMON',inputType: 'textDate',sortInput:'required'},
    { field: 'CREATIONDATE', header: 'Created On',inputType: 'textDate',sortInput:'required'},
   
  ];
  
  }
  
  /* to get launch list*/
  getLaunchData() {
    let param = {
      "ProjectId":this.commonservice.getProjectId(),
      "locale": this.commonservice.getUserlocaleName()
    }
    this._launchService.getLaunchData(param).subscribe(
      responseData => {
        this.launchManageData = responseData.GetLaunchListResult; 
        
      },
    
    (error: any) => this.errorMessage = <any>error

    );
  }

  buildVehicleForm(){
    this.vehicleForm = this.fb.group({
      CM: [''],
      VIS: [''],
      VIN: [''],
      SITE_FAB:['',[Validators.required]],
      STADE_PROJET:[''],
      EMON:['',[Validators.required]],
      SILHOUETTE:['',[Validators.required]],
      NIVEAU_FINITION:['',[Validators.required]],
      DIRECTION:['',[Validators.required]],
      MOTEUR:['',[Validators.required]],
      BV:['',[Validators.required]],
      COULEUR_DE_CAISSE:[''],
      OTHER1:[''],
      OTHER2:[''],
      OTHER3:[''],
      TAGS:[''],
      LANCEMENT:['',Validators.required]
    });
  }
  get f() { return this.vehicleForm.controls; }

  /* when click on create vehicle popup*/
  createVehicle(){
    this.newVehicle=true
    //this.vehicleForm.reset()
    this.vehicleForm.enable()
    this.vehicleForm.patchValue({
      CM:"",
      VIS:"",
      VIN:"",
      SITE_FAB:"",
      STADE_PROJET:"",
      EMON:"",
      SILHOUETTE:"",
      NIVEAU_FINITION:"",
      DIRECTION:"",
      MOTEUR:"",
      BV:"",
      COULEUR_DE_CAISSE:"",
      OTHER1:"",
      OTHER2:"",
      OTHER3:"",
      TAGS:"",
      LANCEMENT:""
    })
    this.errorMessage=""
    this.vinErrorMgs=""
    this.submitted=false;
    this.displayVehicleDailog=true
    this.dialogHeader="Create Vehicle"

  }
  /*check validation before saving vehicle data*/
  checkValidation() {
    this.errorMessage=""
    this.vinErrorMgs = ""
    this.submitted = true
    if (this.vehicleForm.valid) {

      let vin = this.vehicleForm.controls['VIN'].value
      let vis = this.vehicleForm.controls['VIS'].value
      
      if (vin != null && vin != "" && vin != undefined) {
        let vinlast8Digit = vin.substr(-8)
        if (vin.length != 17) {
          this.vinErrorMgs = "vin.main.validation"
          
        } else {
          if (vis && vin) {
            if (vis == vinlast8Digit) {
              this.updatevehicldetail()
            }
            else {
              this.vinErrorMgs = "vis.main.validation"
            }
          }
          else {
            this.vinErrorMgs = ""
            this.updatevehicldetail()
          }
        }
      } else {
        this.vinErrorMgs = ""
        this.updatevehicldetail()
      }
    }
    else{
      return false
    }
  }

  /* add vehicle data*/ 
  updatevehicldetail(){
    debugger
    let launchId;
    let vin = this.vehicleForm.controls['VIN'].value
    let vis = this.vehicleForm.controls['VIS'].value
    let cm = this.vehicleForm.controls['CM'].value
      if(vin || cm || vis){
        
     let formdata=this.vehicleForm.value
     this.popupLoader=true
     let launchname = this.launchManageData.filter(e=>e.Title.toLowerCase()==formdata.LANCEMENT.toLowerCase())
     if(launchname!=undefined && launchname!="" && launchname!=null){
       launchId=launchname[0].LaunchId
     }
     if(this.newVehicle){
      //let formdata= this.vehicleForm.value
      let param =
    {
      "vehicleAddRequest":
      {
        "CODE_CENTRE_FABRICATION": formdata.SITE_FAB,
        "CODE_COULEUR_CAISSE": formdata.COULEUR_DE_CAISSE,
        "CODE_COULEUR_HAB_EXT": formdata.OTHER2,
        "CODE_DIRECTION": formdata.DIRECTION,
        "CODE_HAB_EXT": formdata.OTHER1,
        "CODE_HAB_INT": formdata.OTHER3,
        "CODE_NIV_FINITION": formdata.NIVEAU_FINITION,
        "CODE_SILHOUETTE": formdata.SILHOUETTE,
        "CODE_TYPE_BOITE": formdata.BV,
        "CODE_TYPE_MOTEUR": formdata.MOTEUR,
        "DATE_EMON": formdata.EMON,
        "ID_LANCEMENT": launchId,
        "STADE_PROJET": formdata.STADE_PROJET,
        "CONTREMARQUE":(this.vehicleForm.controls['CM'].value!=null?this.vehicleForm.controls['CM'].value:""),
        "USER_MAJ": this.commonservice.getUserID(),
        "VIS":  (this.vehicleForm.controls['VIS'].value!=null?this.vehicleForm.controls['VIS'].value:""),
        "VIN": (this.vehicleForm.controls['VIN'].value!=null?this.vehicleForm.controls['VIN'].value:""),
        "Tags": formdata.TAGS,
        "ProjectID": this.commonservice.getProjectId(),
        "Locale": this.commonservice.getUserlocaleName(),
        "UserName": this.commonservice.getUserID(),
        "LANCEMENT": formdata.LANCEMENT
        
      },
      "userLocale": this.commonservice.getUserlocaleName()
    }
    
    this.vehicleDetailsService.addVehicleDetails(param).subscribe(data => {
      if (data[0].Key) { 
       this.onSearch()     
        this.errorMessage = data[0].Value
        this.popupLoader=false
       this.displayVehicleDailog=false
       this.submitted=false
       this.showToast('success', data[0].Value, '');
       
      }
      else{
        this.errorMessage = data[0].Value;
       this.popupLoader=false
      }
    },
    responseError => {
      this.popupLoader=false
    }
      ); 

     }
     else{
      let params =
    {
      "vehicleUpdateRequest":
      {
        "CODE_CENTRE_FABRICATION": formdata.SITE_FAB,
        "CODE_COULEUR_CAISSE": formdata.COULEUR_DE_CAISSE,
        "CODE_COULEUR_HAB_EXT": formdata.OTHER2,
        "CODE_DIRECTION": formdata.DIRECTION,
        "CODE_HAB_EXT": formdata.OTHER1,
        "CODE_HAB_INT": formdata.OTHER3,
        "CODE_NIV_FINITION": formdata.NIVEAU_FINITION,
        "CODE_SILHOUETTE": formdata.SILHOUETTE,
        "CODE_TYPE_BOITE": formdata.BV,
        "CODE_TYPE_MOTEUR": formdata.MOTEUR,
        "DATE_EMON": formdata.EMON,
        "ID_LANCEMENT": launchId,
        "STADE_PROJET": formdata.STADE_PROJET,
        "CONTREMARQUE": this.vehicleForm.controls['CM'].value.trim(),
        "USER_MAJ": this.commonservice.getUserID(),
        "VIS":  this.vehicleForm.controls['VIS'].value.trim(),
        "VIN": this.vehicleForm.controls['VIN'].value.trim(),
        "Tags": formdata.TAGS,
        "ProjectID": this.commonservice.getProjectId(),
        "Locale": this.commonservice.getUserlocaleName(),
        "UserName": this.commonservice.getUserID(),
        "ID": this.vehcileID
      },
      "userLocale": this.commonservice.getUserlocaleName()
    }
    this.vehicleDetailsService.updateVehicleDetails(params).subscribe(data => {
      if (data[0].Key) { 
       this.onSearch()     
        this.errorMessage = data[0].Value
        this.popupLoader=false
       this.displayVehicleDailog=false
       this.submitted=false
       this.showToast('success', data[0].Value, '');
       
      }
      else{
        this.errorMessage = data[0].Value;
       this.popupLoader=false
      }
    },
    responseError => {
      this.popupLoader=false
    }
      );
  } }
  else
  {this.vinErrorMgs="You have to specify a value for VIN, VIS or CM"}
  }

formValue() {
  let emonDate=this.vehicledetail.Key['DATE_EMON']
  this.vehicleForm.patchValue({ 
  CM:this.vehicledetail.Key['CONTREMARQUE'], 
  VIS: this.vehicledetail.Key['VIS'],
  VIN:this.vehicledetail.Key['VIN'],
  SITE_FAB:this.vehicledetail.Key['CODE_CENTRE_FABRICATION'],
  STADE_PROJET:this.vehicledetail.Key['STADE_PROJET'],
  EMON:!emonDate ? null : new Date(parseInt(emonDate.substr(6))),
  SILHOUETTE:this.vehicledetail.Key['CODE_SILHOUETTE'],
  NIVEAU_FINITION:this.vehicledetail.Key['CODE_NIV_FINITION'],
  DIRECTION:this.vehicledetail.Key['CODE_DIRECTION'],
  MOTEUR:this.vehicledetail.Key['CODE_TYPE_MOTEUR'],
  BV:this.vehicledetail.Key['CODE_TYPE_BOITE'],
  COULEUR_DE_CAISSE:this.vehicledetail.Key['CODE_COULEUR_CAISSE'],
  OTHER1:this.vehicledetail.Key['CODE_HAB_EXT'],
  OTHER2:this.vehicledetail.Key['CODE_COULEUR_HAB_EXT'],
  OTHER3:this.vehicledetail.Key['CODE_HAB_INT'],
  TAGS:this.vehicledetail.Key['TAGS'],
  LANCEMENT:this.vehicledetail.Key['LANCEMENT']
  
});  
if(this.vehicledetail.Value){
  let vis=this.vehicleForm.controls['VIS'].value
  let cm=this.vehicleForm.controls['CM'].value
  let vin=this.vehicleForm.controls['VIN'].value

  if (vis!="" && vis!=undefined ) {
    this.vehicleForm.controls["VIS"].disable();
  }
  else{this.vehicleForm.controls["VIS"].enable()}
  if (cm!="" && cm!=undefined) {
    this.vehicleForm.controls["CM"].disable();
  }
  else{this.vehicleForm.controls["CM"].enable();}
  if (vin!="" && vin!=undefined) {
    this.vehicleForm.controls["VIN"].disable();
  }
  else{this.vehicleForm.controls["VIN"].enable();}
} 
else{
  this.vehicleForm.enable()
} 
}

/*edit vehicle data*/
editvehicleInfo(ID) {
  this.newVehicle=false
  this.vinErrorMgs = ""
  this.errorMessage = ""
  this.vehicleForm.reset();
  this.dialogHeader="Edit Vehicle"
  this.vehcileID=ID
  this.popupLoader=true
  let reqparams={
    "VehicleID":ID,
    "UserName":this.commonservice.getUserID()
  }
  this.vehicleDetailsService.getVehcileDetailsByID(reqparams).subscribe(data=>{
    if(data!=null){
        this.vehicledetail.Key=data.GetVehicleDetailsByIDResult[0].Key;
        this.vehicledetail.Value=data.GetVehicleDetailsByIDResult[0].Value
        this.displayVehicleDailog=true
        this.formValue()
        this.popupLoader=false;
        console.log("vehicle detail",this.vehicledetail.Key)
  }},
  responseError => {

    this.vehicleForm.disable()
    this.popupLoader=false;
  });

  
  
}

  cancel(){
    this.submitted=false;
    this.displayVehicleDailog=false
  }

  onFilter(event){

  }

  onScroll() {
    if (!this.enableLoader) {
      if(this.nextPage>0){
        this.pageIndex += 1;
        this.searchVehicleList();
      
    }}
  }
  /*toaster to show successful and failure msg*/
  showToast(severity, summary, detail) {
    let res= this.translate.instant(summary)
    this.messageService.add({ key: 'tp', severity: severity, summary: res, detail: detail });
  }

  /*delete vehicle data*/
  deleteVehicleList(ID) {
    let reqParam={
      "VehicleID":ID,
      "UserLocale":this.commonservice.getUserlocaleName()
    }
    
    this.confirmationService.confirm({
      message: this.translate.instant(this.msg),
      header: this.translate.instant(this.headerMsg),
      icon: 'pi pi-exclamation-triangle',
      acceptLabel:this.translate.instant(this.acceptMsg),
      rejectLabel:this.translate.instant(this.rejectMsg),
        accept: () => {
          this.enableLoader=true
          this.vehicleDetailsService.deleteVehicleList(reqParam).subscribe(
            response =>{
              if(response.DeleteVehicleFromListResult[0].Key){
                this.onSearch();
                this.showToast('success', 'Vehicle deleted successfully', '');
                this.enableLoader=false
              }
              else{
                this.showToast('error', this.translate.instant(response.DeleteVehicleFromListResult[0].Value), '');
                this.enableLoader=false;
              }
              
            },
            (error: any) => this.errorMessage = <any>error
          );
        }
        ,
  reject: () => {
    this.enableLoader=false;
}
    });
  }

  /* on search */
  onSearch(){
this.pageIndex=1;
this.vehicleListData=[]
this.searchVehicleList()
  }


/*to filter vehicle data*/
  searchVehicleList(){ 
   this.enableLoader=true
    let launchid

  //   if(this.filterLaunch){
  //  let launchname=  this.launchManageData.filter(e=>e.Title.toLowerCase()==this.filterLaunch.toLowerCase())
  //  if(launchname!=undefined && launchname!="" && launchname!=null){
  //    launchid=launchname[0].LaunchId
  //  }
  //  else
  //  launchid="0"
  //   }
    let reqparams={
    "projectID":this.commonservice.getProjectId(),
    "pageSize":config.pageSizeVehicle,
    "pageNumber":0,
    "EmonDateFrom":this.datePipe.transform(this.emonDateFrom,"dd-MMM-yy"),
    "EmonDateTo":this.datePipe.transform(this.emonDateTo,"dd-MMM-yy"),
    "userName":this.commonservice.getUserID(),
    "b2CustModel":{
      "VIN":this.filterVin,
      "CONTREMARQUE":this.filterCM,
      "VIS":this.filterVis,
      "LANCEMENT":this.filterLaunch,
      "CODE_CENTRE_FABRICATION":this.filterSiteFab
  }
    }
    reqparams.pageNumber=this.pageIndex
  
    this.vehicleDetailsService.searchVehicleList(reqparams).subscribe(
      data=>{
        let dataArray=data;
        let resresult = [];
        if (!_.isNil(dataArray) && dataArray.length > 0) {
        dataArray.forEach(element => {
         
         let currentMeasure = {
           "ID":element.ID,
           "CM":element.CONTREMARQUE,
           "VIS": element.VIS,
           "VIN": element.VIN,
           "SITE_FAB": !element.CODE_CENTRE_FABRICATION ? "" : element.CODE_CENTRE_FABRICATION.toString(),
           "CREATIONDATE": !element.DATE_CREATION ? null : new Date(parseInt(element.DATE_CREATION.substr(6))),
           "EMON": !element.DATE_EMON ? null : new Date(parseInt(element.DATE_EMON.substr(6))),
           "LANCEMENT":!element.LANCEMENT ? "": element.LANCEMENT
         };
         resresult.push(currentMeasure);
        });
        
      }
    
        this.nextPage = config.pageSizeVehicle > data.length ? 0 : this.pageIndex + 1;
        this.vehicleListData = this.vehicleListData.concat(resresult);
        this.vehicleListData=_.uniqBy(this.vehicleListData,"ID");
        console.log("vehicle details",this.vehicleListData);
        this.enableLoader=false;
    },
    responseError => {
      this.enableLoader=false;
    });
  }

  /*to clear the filter*/
  clearFilters(){
    this.vehicleListData=[]
    this.filterCM="";
    this.filterLaunch="";
    this.filterSiteFab="";
    this.filterVis="";
    this.filterVin="";
    this.emonDateFrom="";
    this.emonDateTo="";
    this.pageIndex=1;
    this.searchVehicleList();

  }
  onSelectLaunch(event){
    if(!this.newVehicle){
    this.errorMessage="Check the VOM impact and the part of Issue /TE if already codified before modifying Launch. If you absolutely want to change the Launch, you have to de-Link each Issue / TE, before to re-Link them with new Launch."     
    }
       
  }
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}

