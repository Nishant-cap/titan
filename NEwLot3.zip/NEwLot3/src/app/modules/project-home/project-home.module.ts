import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectHomeRoutingModule } from './project-home-routing.module';
import { LaunchComponent } from './launch/launch.component';
import { MeasureListComponent } from './measure-list/measure-list.component';
import { MAT_DATE_FORMATS, MatNativeDateModule, DateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatListModule } from '@angular/material/list';
import { MatSelectModule } from '@angular/material/select';
import {MatTooltipModule} from '@angular/material/tooltip';
import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MeasureSearchPipe } from 'src/app/shared/pipes/measure-search.pipe';
import { CodificationETSComponent } from './codification-ets/codification-ets.component';
import { CodificationSeaComponent } from './codification-sea/codification-sea.component';
import {AutoCompleteModule} from 'primeng/autocomplete';
import { ProjcetHomeComponent } from './projcet-home/projcet-home.component';
import { CodseaSearchPipe } from 'src/app/shared/pipes/codsea-search.pipe';
import {TabViewModule} from 'primeng/tabview';
import { LaunchmentSearchPipe } from 'src/app/shared/pipes/launchment-search.pipe';
import { AccordionModule } from 'primeng/accordion';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatTabsModule} from '@angular/material/tabs';
import {MatTreeModule} from '@angular/material/tree';
import {MatButtonModule} from '@angular/material/button';
import {MatButtonToggleModule} from '@angular/material/button-toggle';

/*Primeng*/
import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import {CalendarModule} from 'primeng/calendar';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {TooltipModule} from 'primeng/tooltip';
import {ToastModule} from 'primeng/toast';
import {DialogModule} from 'primeng/dialog';
import {ToolbarModule} from 'primeng/toolbar';
import {FieldsetModule} from 'primeng/fieldset';
import { UploadExportComponent } from './upload-export/upload-export.component';
import { MailRecipientsComponent } from './mail-recipients/mail-recipients.component';
import { AuthGuard } from 'src/app/shared/guard';
import {MultiSelectModule} from 'primeng/multiselect';
import { ProjectRoleModule } from 'src/app/shared/modules/project-role/project-role.module';
import { TechnicaleventsListComponent } from '../technicalevents/technicalevents-list/technicalevents-list.component';
import { EditorModule } from 'primeng';
import { AltisOrigionSearchPipe } from 'src/app/shared/pipes/altis-origion-search.pipe';
import { DateFormat } from "src/app/shared/validators/date-format";
import { VehicleDetailsComponent } from './vehicle-details/vehicle-details.component';
@NgModule({
  declarations: [LaunchComponent,MeasureListComponent,MeasureSearchPipe,LaunchmentSearchPipe,AltisOrigionSearchPipe,
    CodseaSearchPipe, CodificationETSComponent, CodificationSeaComponent,  ProjcetHomeComponent, UploadExportComponent,MailRecipientsComponent,VehicleDetailsComponent],
  imports: [
    CommonModule,ReactiveFormsModule,FormsModule,AccordionModule,
    TranslateModule,MatListModule,TabViewModule,ProjectRoleModule,
    MatSelectModule,MatDatepickerModule,MatNativeDateModule,InfiniteScrollModule,AutoCompleteModule,
    MatNativeDateModule, ProjectHomeRoutingModule,
    MatSlideToggleModule,FieldsetModule,
    MatTabsModule,
    MatTreeModule,
    MatButtonModule,
    MatButtonToggleModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    CalendarModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    DialogModule,
    ToolbarModule,
    EditorModule,
    MatTooltipModule
    
  ],
  providers: [
     
    AuthGuard,
   { provide: DateAdapter, useClass: DateFormat },
   ]
  
 
})
export class ProjectHomeModule {
  constructor(private dateAdapter: DateAdapter<Date>) {
    dateAdapter.setLocale("fr-FR"); // DD/MM/YYYY
  }
 }
