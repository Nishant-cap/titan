import { Component, OnInit, ViewContainerRef, ViewChild, Output, EventEmitter, Input, DebugElement, HostListener } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { DatePipe } from '@angular/common';
import { CodificationSeaService } from 'src/app/service/codification-sea.service';
import { CommonService } from 'src/app/service/common.service';
import LocalStorage from 'src/app/util/local-storage';
import * as _ from 'node_modules/lodash';
import { MessageService } from 'primeng/api';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, Validators, RequiredValidator } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { saveAs } from "file-saver";
import { PROJECT_IMAGE_TYPES } from 'src/app/constant/auth-constant';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { MailrecipientService } from 'src/app/service/mailrecipient.service';
import { AccessManagementService } from 'src/app/service/access-management.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { threadId } from 'worker_threads';
import { LoginOptions } from 'angular-oauth2-oidc';
import { ProjectService } from 'src/app/service/project.service';




@Component({
  selector: 'app-codification-sea',
  templateUrl: './codification-sea.component.html',
  styleUrls: ['../../../../styles/titan.scss', './codification-sea.component.scss'],
  providers: [MessageService, DatePipe]
})
export class CodificationSeaComponent implements OnInit {
  headerText: string; reqId: string; vehicleInfo: any = []; defects: any; measureInfo: any = []; measureSynthesis: any[] = []; errorMessage: string; emailConfigured: boolean = false
  sythesisExportDisabled: boolean = false;  selectedPiece: any; isChange:boolean=false;filename:string=""
  statusChecked: boolean = false; filteredpiecesList: any[]; defectsAttachments = {}; piecesList: any[] = []; tagList: any[] = [];
  tagFilteredList: any[] = []; altisLink: string = ""; searchFilter: string = ""; statutsAltis: any;
  selectedAltisStatus: any[]; selectedLancment: any[]; selectedDecison: any[]; projectParameters: any; altisOrigins: any = []; changeDestinationTypePiece: any
  changeDestinationTypeAltistePlm: any; changeDestinationTypePieceID: any; changeDestinationDefectObject: any; currentDefectAttachId: any; currentAttachment: any
  attchmntType: any;attchmntname:string; attchmntId: any; linkUrlForm: FormGroup; selectedPrinciple: boolean = false;
  severities = ['S', 'P', 'A', 'B', 'C', 'D']; states = ["N", "C"]; codifs = ['INIT', 'DRAFT', 'CODED'];
  launchfilter = { "id": "", "title": "", "defectsNumber": "" }
  activeState: boolean[] = [true, false, false];recentdefectId:any="";usersList:any;cols:any[];
  userSearch:any[];
  userSearchText:string;
  defectidForuser:any;addUser:any;
  UserList:any
  searchErorMsg;
  type:string;
  parentRecordsFunction:any=this.getAllRecords.bind(this);
  infoModalBody: string = ""; activeIndex: number = 0
  messageLinkFTError: string = ""
  /*Image Attachments*/
  selectedImage: any
  imageValidationMessage: string = ""
  selectedurl: any
  reqParams = {
    "locale": "",
    "id": "",
    "defectid": ""
  }
  imageValue:any
  defectInfo = { "uncoded": {}, "coded": {} };
 defectInfoCopy = { "uncoded": {} }

 defectInfoCopyCoded={ "coded": {} };

  sortObj = {
    currentColumn: '',
    previousColumn: '',
    order: 'ASC'
  };
  tradeActionId:any;
  tradeId:any
  peiceInfo:any
  filter = {
    "grossnbrTxt": "",
    "gravityTxt": [],
    "stateTxt": [],
    "copTxt": []
  };
  measureData = {
    "measureInfo": {},
    "vehicleInfo": {},
    "defects": {}
  }
  dataDetailDefect = {
    "vehicleInfo": {},
    "headertext": "",
    "headerDate":""
  };
  requestParam = {
    langId: "",
    ftId: "",
  }
  submitted: false
  codifStateIconMap = {
    "INIT": { "srcIcon": "assets/images/old/completion_empty.png" },
    "DRAFT": { "srcIcon": "assets/images/old/completion_middle.png" },
    "CODED": { "srcIcon": "assets/images/old/completion_full.png" }
  };
  dataUserLang: string = ""
  enableLoader: boolean = false
  popupLoader:boolean=false;
  validFT = /^[0-9]{1,19}$/;
  validIssue = /^[a-zA-Z0-9\-]{1,19}$/;
  chgStateDefect:any;
  chgStateTargetState = "";
  /**measure synthesis */
  sendEmailTooltipMsg: string = ""
  peopledisplayDialog:boolean=false
  confirmationModal:boolean=false
  deleteconfirmationModal:boolean=false
  UploadImage:boolean=false
  UploadMlmModal:boolean=false
  flag:boolean=false
  InfoModal:boolean=false
 statechangeModal:boolean=false
  //statuSparteNeoMap = { "VAL": "valide1", "CNF": "valide2", "PUB": "valide2", "ENV": "crayon", "ANNUL": "poubelle", "SOLDÉ": "valide2", "NON SOLDÉ": "crayon" };
  statuSparteNeoMap = [
    { "id": "VAL", "value": "valide1", "srcIcon": "assets/images/check.png", "i18nTooltip": "status.sparteNeo.val1.tooltip", "order": 1 },
    { "id": "CNF", "value": "valide2", "srcIcon": "assets/images/check_green.png", "i18nTooltip": "status.sparteNeo.val2.tooltip", "order": 2 },
    { "id": "PUB", "value": "valide2", "srcIcon": "assets/images/check_green.png", "i18nTooltip": "status.sparteNeo.val2.tooltip", "order": 2 },
    { "id": "ENV", "value": "crayon", "srcIcon": "assets/images/edit.png", "i18nTooltip": "status.sparteNeo.pencil.tooltip", "order": 0 },
    { "id": "ANNUL", "value": "poubelle", "srcIcon": "assets/images/papelera.png", "i18nTooltip": "status.sparteNeo.trash.tooltip", "order": 3 },
    { "id": "SOLDE", "value": "valide2", "srcIcon": "assets/images/check_green.png", "i18nTooltip": "status.sparteNeo.val2.tooltip", "order": 2 },
    { "id": "NONSOLDE", "value": "valide1", "srcIcon": "assets/images/check.png", "i18nTooltip": "status.sparteNeo.val1.tooltip", "order": 1 }

  ];
  unsubscribe$: Subject<boolean> = new Subject();
 projectid:any
  constructor(private fb: FormBuilder,private modalService: NgbModal,
    private headerChangeService:HeaderChangeService,
    public projectservice: ProjectService,
    private commonService: CommonService, private translate: TranslateService, private datePipe: DatePipe,
    private codSeaservice: CodificationSeaService, private activatedRoute: ActivatedRoute,private accessservice:AccessManagementService) {
    }

  ngOnInit() {
   
    console.log(this.activatedRoute.parent.snapshot.params.id, "measure id");
    const projectId = this.activatedRoute.parent.snapshot.params.id;
    this.commonService.setProjectId(projectId);
    this.projectid = this.commonService.getProjectId()
    this.projectservice.getprojectDetailById(this.projectid).subscribe((data: any) => {      
      this.commonService.setProjectName(data.URL_SITE)
      this.commonService.setProjectLocale(data.LOCALE)
  })

    this.activatedRoute.paramMap.subscribe(params => {
      this.reqId = params.get('id');
      console.log(this.reqId,"this.reqId" )
    });
    this.activatedRoute.paramMap.subscribe(params => {
      let val = params.get('grossNo');
      if(val!=undefined && val!="" && val!=null){
        this.filter.grossnbrTxt=val
      }
      
    });
    this.headerChangeService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => 
      {let selectedlanguage = language
        this.flag=false
        this.dataUserLang = this.commonService.getUserlocaleName();
      this.getOriginsAltis()
      if(selectedlanguage!=null && selectedlanguage!="" && selectedlanguage!=undefined)
      this.setIntialCalls();
      
    });
     
    this.headerChangeService.changeLeftpanel(true)
    this.commonService.setChangedCod(true)
    this.dataUserLang = this.commonService.getUserlocaleName();
    //let URL_REGEXP = /^[A-Za-z][A-Za-z\d.+-]*:\/*(?:\w+(?::\w+)?@)?[^\s/]+(?::\d+)?(?:\/[\w#!:.?+=&%@\-/]*)?$/
    let URL_REGEXP ="^https?:\/\/(.*)"
    const reg = '(http?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?';
    this.linkUrlForm = this.fb.group({
      urlLink: ['', [Validators.required, Validators.pattern(URL_REGEXP)]],
      linkName: ['', [Validators.required]],

    });
    
  
    this.cols = [
      { field: 'TITLE', header: 'Title',inputType: 'textDate' },
      { field: 'LAUNCHNAME', header: 'Launch Name'  ,inputType: 'textDate'},
      { field: 'FROMMAIL', header: 'From' ,inputType: 'textDate'},
      { field: 'TOMAIL', header: 'To' ,inputType: 'textDate'},
      { field: 'SUBJECTTEMPLATE', header: 'Subject Template',inputType: 'textDate' },
    ];
    this.userSearch = [
      { field: 'NAME', header: 'NAME'},
      { field: 'TITLE', header: 'TITLE'},
      { field: 'Department', header: 'Department'},
      { field: 'E-Mail', header: 'E-Mail'},
      { field: 'MobileNumber', header: 'Mobile Number'},
      { field: 'AccountName', header: 'Account Name'}
    ];
    this.setIntialCalls()

  }
  get f() { return this.linkUrlForm.controls; }
  toggletab(index: number,brutNumber_defect) {
    this.activeIndex = index;
    this.viewDefect(brutNumber_defect)

  }
  setIntialCalls(){
    this.getAllRecords();
    this.getProjectParameters()
    this.getTags();
    this.getmeasureSynthesis()
  
  }
/***
 * After clicking on any row on metier this function open that records in sea screen
 */
viewDefect(brutNumber_defect) 
{
  
  if (brutNumber_defect != "" && brutNumber_defect != undefined) {
     

      if (this.defects != null) {
          let defect = _.filter(this.defects, function(item) { return item.nBrut == brutNumber_defect.toString() });
          if (defect != null && defect != undefined && defect.length > 0) {
            this.launchfilter.id=defect[0].id
              this.toggleDefectDetails(defect[0].id, true);

          }
      }

     
  }

}

  /**
  * Gets intial records
  */
  getAllRecords() {
    this.defectInfo={ "uncoded": {}, "coded": {} }
    this.enableLoader = true
    this.reqParams.locale = this.commonService.getUserlocaleName()
    this.reqParams.id = this.projectid
    this.reqParams.defectid = this.reqId
    if(this.dataUserLang){
    this.codSeaservice.getRecords(this.reqParams).subscribe(
      (data: any) => {
        this.enableLoader = false
        if (data != null) {
          let element = data;
          let measureEnabled = true;
          let statutTitan = element.MeasureInfo.STATUT_TITAN;
          if (statutTitan == "0" || statutTitan == "00")
            measureEnabled = false;
          let currentStatutSparteNeoMap = this.statuSparteNeoMap.filter(x => x.id == element.MeasureInfo.STATUT);
          if (!currentStatutSparteNeoMap[0]) {

            currentStatutSparteNeoMap[0] = { "id": "", "value": "default", "i18nTooltip": "status.sparteNeo.val1.tooltip", "srcIcon": "assets/images/old/question.png", "order": 100, }
          }

          if (data.MeasureInfo != undefined) {
            let measure = {
              "id": element.MeasureInfo.ID,

              "silhouette": element.MeasureInfo.CODE_SILHOUETTE,
              "contremarque": element.MeasureInfo.CONTREMARQUE,
              "creationDate": !element.MeasureInfo.DATE_CREATION ? null : new Date(parseInt(element.MeasureInfo.DATE_CREATION.substr(6))),
              "dateEmon": !element.MeasureInfo.DATE_EMON ? null : new Date(parseInt(element.MeasureInfo.DATE_EMON.substr(6))),
              "testDate": !element.MeasureInfo.DATE_ESSAI ? null : new Date(parseInt(element.MeasureInfo.DATE_ESSAI.substr(6))),
              "modifiedDateSparteNeo": !element.MeasureInfo.DATE_MAJ_BRUT ? null : new Date(parseInt(element.MeasureInfo.DATE_MAJ_BRUT.substr(6))),
              "modificationDateBrut": !element.MeasureInfo.DATE_MAJ_BRUT ? null : new Date(parseInt(element.MeasureInfo.DATE_MAJ_BRUT.substr(6))),
              "modificationDateDefTitan": !element.MeasureInfo.DATE_MAJ_DEF_TITAN ? null : new Date(parseInt(element.MeasureInfo.DATE_MAJ_DEF_TITAN.substr(6))),
              "idProjectNeo": element.MeasureInfo.ID_PROJET_NEO,
              "idProjectSparte": element.MeasureInfo.ID_PROJET_SPARTE,
              "idProjectTitan": element.MeasureInfo.ID_PROJET_TITAN,
              "idVehicle": element.MeasureInfo.ID_VEHICULE,
              "phase": element.MeasureInfo.STADE_PROJET,
              "statutSparteNeoOriginal": element.MeasureInfo.STATUT,
              "statutSparteNeo": currentStatutSparteNeoMap[0].value,
              "statutSparteNeoIconSrc": currentStatutSparteNeoMap[0].srcIcon,
              "statutSparteNeoIconTooltip": currentStatutSparteNeoMap[0].i18nTooltip,
              "statutTitan": statutTitan,
              "seriousDefects": element.MeasureInfo.TOTAL_DEFAUTS_GRAVES,
              "totalPoints": element.MeasureInfo.TOTAL_POINTS,
              "testType": element.MeasureInfo.LIB_TYPE_ESSAI,
              "userCreation": element.MeasureInfo.USER_CREATION,
              "userModification": element.MeasureInfo.USER_MAJ,
              "vis": element.MeasureInfo.VIS,
              "measureEnabled": measureEnabled,
              "emailSentDate": !element.MeasureInfo.DATE_ENVOI_EMAIL ? null : new Date(parseInt(element.MeasureInfo.DATE_ENVOI_EMAIL.substr(6))),
              "codedDefectsCount": "", "defautsNotAnulle": ""
            };
            this.dataDetailDefect.headerDate=this.datePipe.transform(measure.dateEmon,'dd/MM/yyyy')
            this.measureData.measureInfo = measure;
            this.measureInfo = measure
            console.log("this.measureInfo", this.measureInfo)
            this.headerText = (measure.testType == null ? "" : measure.testType) + " - " + (measure.contremarque == null ? "" : measure.contremarque) + " - " +
              (measure.vis == null ? "" : measure.vis) + " - emon: "
          
          }
          if (element.VehicleInfo != undefined) {
            let vehicle = {
              "id": element.VehicleInfo.ID,
              "codeCentreFabric": element.VehicleInfo.CODE_CENTRE_FABRICATION,
              "codeCoulCaisse": element.VehicleInfo.CODE_COULEUR_CAISSE,
              "codeCoulHabExt": element.VehicleInfo.CODE_COULEUR_HAB_EXT,
              "codeDirection": element.VehicleInfo.CODE_DIRECTION,
              "codeHabExt": element.VehicleInfo.CODE_HAB_EXT,
              "codeHabInt": element.VehicleInfo.CODE_HAB_INT,
              "codeNivFinition": element.VehicleInfo.CODE_NIV_FINITION,
              "codeSilhouette": element.VehicleInfo.CODE_SILHOUETTE,
              "codeTypeBoitte": element.VehicleInfo.CODE_TYPE_BOITE,
              "codeTypeMoteur": element.VehicleInfo.CODE_TYPE_MOTEUR,
              "contremarque": element.VehicleInfo.CONTREMARQUE,
              "dateCreation": !element.VehicleInfo.DATE_CREATION ? null : new Date(parseInt(element.VehicleInfo.DATE_CREATION.substr(6))),
              "dateEmon": !element.VehicleInfo.DATE_EMON ? null : new Date(parseInt(element.VehicleInfo.DATE_EMON.substr(6))),
              "dateMaj": !element.VehicleInfo.DATE_MAJ ? null : new Date(parseInt(element.VehicleInfo.DATE_MAJ.substr(6))),
              "idLanzament": element.VehicleInfo.ID_LANCEMENT,
              "libLanzement": element.VehicleInfo.LIB_LANCEMENT,
              "stadeProjet": element.VehicleInfo.STADE_PROJET,
              "userCreation": element.VehicleInfo.USER_CREATION,
              "userModification": element.VehicleInfo.USER_MAJ,
              "vis": element.VehicleInfo.VIS,
              "tags": element.VehicleInfo.TAGS,
              "link": element.VehicleInfo.linkVehicle,
              "existVehicleInSP": element.VehicleInfo.existVehicleInSP
              //,												_spPageContextInfo.webServerRelativeUrl + "/Lists/Vehicles/DispForm.aspx?ID=aa" + element.VehicleInfo.ID
            };
            this.measureData.vehicleInfo = vehicle;
            this.vehicleInfo = vehicle
            this.dataDetailDefect.vehicleInfo = vehicle
            this.dataDetailDefect.headertext = this.headerText

          }
          let defects = [];

          let dataObj = this.parseMeasure(element.Defects)

          this.requestParam.langId = this.commonService.getUserlocaleName()
          this.requestParam.ftId = this.vehicleInfo.idLanzament
          this.getPieces(this.requestParam);
          this.measureData.defects = dataObj
          this.defects = dataObj;
        
          let defectCount = _.filter(this.defects, function (defect, i) {
            return (defect.codifState == "CODED")
          });
          this.measureInfo.codedDefectsCount = defectCount.length
          let annulecount = _.filter(this.defects, function (defect, i) {
            return (defect.annule == undefined || defect.annule == null || defect.annule != 1)
          })
          this.measureInfo.defautsNotAnulle = annulecount.length
        
        }

      },

      responseError => {
        this.enableLoader = false
        this.errorMessage = responseError;
      });
    }
  }

  getmeasureSynthesis() {
    this.reqParams.locale = this.commonService.getUserlocaleName()
    this.reqParams.id = this.reqId
    this.codSeaservice.getMeasureSynthesis(this.reqParams).subscribe(
      (data: any) => {
      
        let result = data;
        let defectsMetierlist = [];
        result.forEach(element => {

          let defectsMetier = {
            "Metier": element.Metier,
            "TOTAL_POIDS": element.TOTAL_POIDS,
            "TOT_DEFAUTS": element.TOT_DEFAUTS,
            "TOT_DEFAUTS_CODIFIES": element.TOT_DEFAUTS_CODIFIES,
            "TOT_DEFAUT_CON": element.TOT_DEFAUT_CON,
            "TOT_DEFAUT_GRAV": element.TOT_DEFAUT_GRAV,
            "TOT_DEFAUT_NEW": element.TOT_DEFAUT_NEW,
            "TOT_DEFAUT_REC": element.TOT_DEFAUT_REC,
            "Defects": []
          }

          element.Defects.forEach(element => {
            let projectParameters = LocalStorage.getItem("PROJECT_PARAMETRS");
            let altisLink = "";
            if (element.QTA0_IDENTIFIANT_FT_ALTIS != undefined && element.QTA0_IDENTIFIANT_FT_ALTIS != "") {
              let altisproject = _.find(projectParameters, function (o) { return o.Key == 'altis_link'; })
              if (altisproject != null && altisproject != undefined) {
                altisLink = altisproject.Value;
                altisLink = altisLink.replace("[QTA0_IDENTIFIANT_FT]", element.QTA0_IDENTIFIANT_FT_ALTIS);
              }
            }
            let PLMLink = "";
            if (element.IDENTIFIANT_ISSUE != undefined && element.IDENTIFIANT_ISSUE != "") {
              let plmLink = _.find(projectParameters, function (o) { return o.Key == 'PLM_link'; })
              if (plmLink != null && plmLink != undefined) {
                PLMLink = plmLink.Value;
                PLMLink = PLMLink.replace("[QTA0_ID_ISSUE]", element.ID_ISSUE);
              }
            }

            let nBrutLink = "";
            let ORIGINE_DEFAUT = element.ORIGINE_DEFAUT != null ? element.ORIGINE_DEFAUT.trim() : "";
            if (ORIGINE_DEFAUT === "SPA") {
              let sparteproject = _.find(projectParameters, function (o) { return o.Key == 'sparte_link'; })
              if (sparteproject != null && sparteproject != undefined) {
                nBrutLink = sparteproject.Value
                nBrutLink = nBrutLink.replace("[NUMERO_DEFAUT_BRUT]", element.NUMERO_DEFAUT_BRUT);
              }


            }
            if (element.ORIGINE_DEFAUT === "NEO") {
              let neoproject = _.find(projectParameters, function (o) { return o.Key == 'neo_link'; })
              if (neoproject != undefined && neoproject != null) {
                nBrutLink = neoproject.Value;
                nBrutLink = nBrutLink.replace("[LIB_SIT]", element.LIB_SIT);
                nBrutLink = nBrutLink.replace("[NOF]", element.NOF);
                nBrutLink = nBrutLink.replace("[BDG]", element.BDG);
                nBrutLink = nBrutLink.replace("[VIS]", element.VIS);
              }
            }
  
            let currentDefet = {
              "AVEC_PJ": element.AVEC_PJ,
              "GRAVITE": element.GRAVITE,
              "IDENTIFIANT_FT_ALTIS": element.IDENTIFIANT_FT_ALTIS,
              "IDENTIFIANT_ISSUE": element.IDENTIFIANT_ISSUE,
              "altisLink": altisLink,
              "PLMLink": PLMLink,
              "nBrutLink": nBrutLink,
              "ID_LANCEMENT_TITAN": element.ID_LANCEMENT_TITAN,
              "ID_MESURE": element.ID_MESURE,
              "LIBELLE": element.LIBELLE,
              "MAX_DATE_SOLS": !element.MAX_DATE_SOLS ? null : new Date(parseInt(element.MAX_DATE_SOLS.substr(6))),
              "METIER_POUR_ACTION": element.METIER_POUR_ACTION,
              "NOUVEAUTE": element.NOUVEAUTE,
              "NUMERO_DEFAUT_BRUT": element.NUMERO_DEFAUT_BRUT,
              "NUM_SOLS": element.NUM_SOLS,
              "ORIGINE_DEFAUT": element.ORIGINE_DEFAUT,
              "POIDS": element.POIDS,
              "TYPE_APPARITION": element.TYPE_APPARITION
            }
            defectsMetier.Defects.push(currentDefet);
          });
          defectsMetierlist.push(defectsMetier)
        })
        this.measureSynthesis = defectsMetierlist,
          console.log(this.measureSynthesis)
      },
      (error: any) => this.errorMessage = <any>error);

  }
  getTags() {
    //project id need to be send
   
    
    let reqparams = {
      projectId: this.projectid,
      loacle: this.commonService.getUserlocaleName()
    }
    this.codSeaservice.getTags(reqparams).subscribe(
      (data: any) => {
        this.tagList=[];
        data.GetAllTNTQTB3EntitysResult.forEach(element => {
          let currenttag = { "key": "", "value": "" }
          currenttag.key = element.ID_TAG;
          currenttag.value = element.TAG;
          this.tagList.push(currenttag);
         
          this.tagFilteredList.push(currenttag);
        });
        console.log("1",this.tagList)
      },
      (error: any) => this.errorMessage = <any>error
    );
  }
  getProjectParameters() {
    this.commonService.getParameters().subscribe(
      (data: any) => {
        this.projectParameters = data;
        LocalStorage.addItem("PROJECT_PARAMETRS", data);

      },
      (error: any) => this.errorMessage = <any>error
    );
  }

//refresh defect
refreshDefect(defectID, force, coded, imageIndexSelect) {
 
if(force){
this.getmeasureSynthesis()
}
    let index = 0;
    let defect = null;

    this.defects.forEach((element, counter) => {
      if (element.id == defectID) {
        index = counter;
        defect = element;
        this.enableLoader=false
        return false;
       
      }
    });
    if (force || ((!coded && !this.defectInfo.uncoded[defectID]) || (coded && !this.defectInfo.coded[defect.uniqueCodedID]))) {
      let dataProjectLang = _.find(this.projectParameters, function (o) { return o.Key == 'LCID'; })
      this.enableLoader = true
      if (dataProjectLang) {
        let req = { "defectid": defectID, "locale": this.commonService.getUserlocaleName(), "projectId":  this.projectid }
        this.codSeaservice.getTechFactInfo(req).subscribe(
          (data: any) => {
            let item = data.GetDefectInfoResult;
            let tagsArray = [];
            let tagItem = [];
          
            if (!!item.TAGS) {
              item.TAGS.forEach(element => {
                let obj = _.filter(this.tagList, function (obj, index) {
                  if (obj.value.toLowerCase().trim() == element.toLowerCase().trim()) {
                    tagsArray.push(obj);
                  }
                });
              });
            }
            
            let solutionsArray = [];
            if (!!item.Solutions) {
              item.Solutions.forEach(val => {
                let solutionItem = {};
                let number = val.IDENTIFIANT_SOLUTION ? val.IDENTIFIANT_SOLUTION : val.ECRNAME;
                solutionItem["number"] = number;
                solutionItem["solutionType"] = val.LIBELLE_TYPE_SOLUTION ? val.LIBELLE_TYPE_SOLUTION : val.TYPE_SOLUTION;
                solutionItem["name"] = val.LIBELLE;
                solutionItem["status"] = val.LIBELLE_ETAT ? val.LIBELLE_ETAT : val.ETAT;
                solutionItem["datePrevi"] = (!val.DATE_PREVI_APPLIQUE_SOL ? "" : new Date(parseInt(val.DATE_PREVI_APPLIQUE_SOL.substr(6))));
                solutionItem["dateReele"] = (!val.DATE_REELLE_APPLIQUE_SOL ? "" : new Date(parseInt(val.DATE_REELLE_APPLIQUE_SOL.substr(6))));
                solutionItem["efficiencyDG"] = val.LIBELLE_EFFICACITE_DG ? val.LIBELLE_EFFICACITE_DG : val.CODE_EFFICACITE_DG;
                solutionItem["efficiencyPoint"] = val.LIBELLE_EFFICACITE_PT ? val.LIBELLE_EFFICACITE_PT : val.CODE_EFFICACITE_PT;
                solutionItem["pelletizing"] = val.PASTILLAGE;
                solutionsArray.push(solutionItem);
              });

            }

            let relatedFTsArray = [];
            if (!!item.FTs) {
              item.FTs.forEach(element => {
                let currentFT = {
                  "nom_lancement": element.NOM_LANCEMENT.replace(/\n/g, "\n\r"),
                  "id": !element.IDENTIFIANT_FT_ALTIS ? element.IDENTIFIANT_ISSUE : element.IDENTIFIANT_FT_ALTIS,
                  "title": element.LIBELLE.replace(/\n/g, "\n\r").replace(/,/g, ", "),
                  "description": element.DESCR_DETAIL_FT.replace(/\n/g, "\n\r").replace(/,/g, ", "),
                  "defectsNumber": element.NB_DEFAUTS,
                  "tradeForAction": element.METIER_POUR_ACTION.replace(/\n/g, "\n\r"),
                  "stateProgressCode": element.CODE_ETAT_AVANCEMENT_FT,
                  "stateProgress": element.ETAT_AVANCEMENT_FT,
                  "nature": item.LIB_NATURE_DEFAUT,
                  "codeNature": item.CODE_NATURE_DEFAUT,
                  "local": element.LOCALE,
                  "detectedLocationCode": element.CODE_LOCALISATION_DETECTE,
                  "idProject": element.ID_PROJET,
                  "severity": element.GRAV_EFFET_CLIENT,
                  "psaFtNat": "",

                };
                currentFT.psaFtNat = currentFT.title + " - " + currentFT.codeNature;
                relatedFTsArray.push(currentFT);
              });
            }
            let dataFT = this.parseDefect(item, tagsArray, solutionsArray, relatedFTsArray);

            if (typeof (dataFT.detail.idFTTItan) != "number") {
              let observationsPreValue = this.vehicleInfo.contremarque == null ? this.vehicleInfo.vis : this.vehicleInfo.contremarque;
              let prevDescription = dataFT.detail.FTDescription;
              dataFT.detail.FTDescription = "1er Veh. concern\xe9: " + observationsPreValue + " - " + prevDescription;
            }
            if (force) {
              
              for (let attrname in dataFT.basic) { this.defects[index][attrname] = dataFT.basic[attrname]; }
              let countDe = _.filter(this.defects, function (defect, i) {
                return (defect.codifState == "CODED");
              });
              this.measureInfo.codedDefectsCount = countDe.length
            }
            //uncoded part
            if (!coded) {
          
              this.defectInfo.uncoded[defectID] = dataFT.detail;
              
              this.defectInfoCopy.uncoded[defectID]=_.cloneDeep(JSON.stringify(this.defectInfo.uncoded[defectID]));
              
           
              if (dataFT.basic.status == 'N' && !dataFT.basic.altisId) {
               this.checkImageAttachments(defectID,dataFT,imageIndexSelect)
              }
              if (dataFT.basic.status == 'N' && !dataFT.basic.issueId) {
                this.checkImageAttachments(defectID,dataFT,imageIndexSelect)

              }

              if (!this.piecesList) {

                if (this.dataUserLang) {

                  let eq = { ftId: "", langId: "" }
                  eq.ftId = this.vehicleInfo.idLanzament
                  eq.langId = this.dataUserLang;
                  this.codSeaservice.getpiecesFilter(eq).subscribe(
                    (res: any) => {
                      this.piecesList = [];
                      res.GetPiecesResult.array.forEach(element => {
                        let currentPiece = { "label": "", "value": "" }
                        currentPiece.label = element.Value;
                        currentPiece.value = element.Key;
                        this.piecesList.push(currentPiece);
                        this.filteredpiecesList.push(currentPiece)
                      });
                      console.log("this.filteredpiecesList", this.filteredpiecesList)
                      this.configurePiecesInput(coded, defectID)
                      this.enableLoader = false
                    }
                  );
                }
                //this.defectInfo.coded[defect.uniqueCodedID].pieceInfo=this.getassociatedInfo();
              }
              else {
               this.configurePiecesInput(coded, defectID);
                this.enableLoader = false
              }
              
              
            }
            //coded part
            
            else {
              

              this.defectInfo.coded[defect.uniqueCodedID] = dataFT.detail;
              
              this.defectInfoCopyCoded.coded[defect.uniqueCodedID]=_.cloneDeep(JSON.stringify(this.defectInfo.coded[defect.uniqueCodedID]));
             let val=JSON.parse(this.defectInfoCopyCoded.coded[defect.uniqueCodedID]).tradeForAction
             
             
            console.log("data ft detail",JSON.parse(this.defectInfoCopyCoded.coded[defect.uniqueCodedID]));
           
              if (!this.piecesList) {
                if (this.dataUserLang) {
                  let eq = { ftId: "", langId: "" }
                  eq.ftId = this.vehicleInfo.idLanzament
                  eq.langId = this.dataUserLang;
                  this.getPieces(eq)
                  this.enableLoader = false;
                  this.configurePiecesInput(coded, defect.uniqueCodedID)
                }
              } else {
                this.configurePiecesInput(coded, defect.uniqueCodedID)
                this.enableLoader = false
              }
              let reqparms = {
                launchid: this.vehicleInfo.idLanzament,
                choiceId: dataFT.detail.workpieceChoiceID,
                locale: this.dataUserLang,
                defectid: defectID
              }
              let pieceInfo = []
              // this.codSeaservice.getPieceAssociatedInfo(reqparms).subscribe(
              //   (result: any) => {
              //      this.tradeActionId=result
              //     result.forEach(element => {
              //       let currentPiece = {
              //         "ID": element.ID,
              //         "CODE_DECOUPAGE_PSA": element.CODE_DECOUPAGE_PSA,
              //         "COFOR": element.COFOR,
              //         "lot": element.METIER_POUR_ACTION_NIV_3,
              //         "businessDriverName": element.PILOTE,
              //         "businessDriverDisplayName": element.PILOTE_DISPLAY,
              //         "tradeForAction": element.METIER_POUR_ACTION_NIV_1 + " - " + element.METIER_POUR_ACTION_NIV_2,
              //         "altistePlm": element.ALTISTE_PLM

              //       };
              //       //item.QTB9_METIER_POUR_ACTION!="0" ?item.QTB9_METIER_POUR_ACTION:
              //       let AlreadyExists = _.filter(pieceInfo, function (ele) {
              //         return ele.CODE_DECOUPAGE_PSA == currentPiece.CODE_DECOUPAGE_PSA &&
              //           ele.COFOR == currentPiece.COFOR &&
              //           ele.lot == currentPiece.lot &&
              //           ele.businessDriverName == currentPiece.businessDriverName &&
              //           ele.businessDriverDisplayName == currentPiece.businessDriverDisplayName &&
              //           ele.tradeForAction == currentPiece.tradeForAction;
              //       });
              //       //We only can add pieceInfo if it doesn´t exist [SPT-2473]
              //       if (AlreadyExists == null || AlreadyExists.length == 0)
              //         pieceInfo.push(currentPiece);


              //     });
          
                //  let val1=this.tradeActionId.filter(e=>(e.METIER_POUR_ACTION_NIV_1 + " - " + e.METIER_POUR_ACTION_NIV_2)==val)
                //  if(val1!=undefined){
                //   this.tradeId=val1[0].ID
                // }
              //     this.defectInfo.coded[defect.uniqueCodedID].pieceInfo = pieceInfo
                
              //   })
             
              this.enableLoader = false
           
            }
          },
         err => {
         this.errorMessage = JSON.stringify(err)
         this.enableLoader = false
        }
        );

      }
    }
    

  }
checkImageAttachments(defectID, dataFT,imageIndexSelect)
{
  this.defectsAttachments[defectID] = {};
  if(!_.isNil(dataFT.detail.imageAttachments)){
  this.defectsAttachments[defectID].images = dataFT.detail.imageAttachments;
  if (!imageIndexSelect && imageIndexSelect != 0) {
    let imagesMainIndexes = _.filter(dataFT.detail.imageAttachments, function (obj, index) {
      if (obj.Main) {
        return index;
      }
    });
    this.defectsAttachments[defectID].images.index = imagesMainIndexes.length > 0 ? imagesMainIndexes[0] : 0;
  } else {
    this.defectsAttachments[defectID].images.index = imageIndexSelect;
  }
}
else{
  this.defectsAttachments[defectID].images=[]
}
if(!_.isNil(dataFT.detail.imageAttachments))
  this.defectsAttachments[defectID].links = dataFT.detail.linkAttachments;
  else
  this.defectsAttachments[defectID].links =[]
}
  parseMeasure(defectData) {

    this.defects = [];
    //NEO
    //SPA 
    //FIC 
    //let ORIGINE_DEFAUT = item.ORIGINE_DEFAUT != null ? item.ORIGINE_DEFAUT.trim() : "";
    let projectParameters = LocalStorage.getItem("PROJECT_PARAMETRS");
    defectData.forEach(item => {
      let altisId = item.QTA0_IDENTIFIANT_FT;
      let issueId = item.QTA0_IDENTIFIANT_ISSUE;


      let nBrutLink = "";
      let ORIGINE_DEFAUT = item.ORIGINE_DEFAUT != null ? item.ORIGINE_DEFAUT.trim() : "";
      if (ORIGINE_DEFAUT === "SPA") {
        let sparteproject = _.find(projectParameters, function (o) { return o.Key == 'sparte_link'; })
        if (sparteproject != null && sparteproject != undefined) {
          nBrutLink = sparteproject.Value
          nBrutLink = nBrutLink.replace("[NUMERO_DEFAUT_BRUT]", item.NUMERO_DEFAUT_BRUT);
        }


      }
      if (item.ORIGINE_DEFAUT === "NEO") {
        let neoproject = _.find(projectParameters, function (o) { return o.Key == 'neo_link'; })
        if (neoproject != undefined && neoproject != null) {
          nBrutLink = neoproject.Value;
          nBrutLink = nBrutLink.replace("[LIB_SIT]", item.LIB_SIT);
          nBrutLink = nBrutLink.replace("[NOF]", item.NOF);
          nBrutLink = nBrutLink.replace("[BDG]", item.BDG);
          nBrutLink = nBrutLink.replace("[VIS]", item.VIS);
        }
      }
     
      let altisLink = "";
      if (altisId != undefined && altisId != "") {
        let altisproject = _.find(projectParameters, function (o) { return o.Key == 'altis_link'; })
        if (altisproject != null && altisproject != undefined) {
          altisLink = altisproject.Value;
          altisLink = altisLink.replace("[QTA0_IDENTIFIANT_FT]", item.QTA0_IDENTIFIANT_FT);
        }
      }
      let statutTitan = "";
      if (item.ANNULE != undefined && item.ANNULE === 1) {
        statutTitan = this.translate.instant('view.defects.statut.supressed');
      } else if (item.DATE_MAJ_TITAN != undefined && item.DATE_MAJ_TITAN != null && item.DATE_MAJ_TITAN < item.DATE_MAJ_BRUT) {
        statutTitan = this.translate.instant('view.defects.statut.modified');
      }

      let LinklistFT = "";
      let linkedListft = _.find(projectParameters, function (o) { return o.Key == 'LinklistFT'; })
      if (altisId != undefined && altisId != "") {
        if (linkedListft != null && linkedListft != undefined) {
          LinklistFT = linkedListft.Value;
          LinklistFT = LinklistFT.replace("[QTA0_IDENTIFIANT_FT]", altisId);
          //  LinklistFT = LinklistFT.replace("[PROJET]", _spPageContextInfo.webServerRelativeUrl.replace(_spPageContextInfo.siteServerRelativeUrl, '').replace('/', ''));
        }
      }
      if (issueId != undefined && issueId != "") {
        if (linkedListft != null && linkedListft != undefined) {
          LinklistFT = linkedListft.Value;
          LinklistFT = LinklistFT.replace("[QTA0_IDENTIFIANT_FT]", issueId);
          //  LinklistFT = LinklistFT.replace("[PROJET]", _spPageContextInfo.webServerRelativeUrl.replace(_spPageContextInfo.siteServerRelativeUrl, '').replace('/', ''));
        }
      }



      let PLMLink = "";
      if (item.QTA0_ID_ISSUE != undefined && item.QTA0_ID_ISSUE != "") {
        let plmLink = _.find(projectParameters, function (o) { return o.Key == 'PLM_link'; })
        if (plmLink != null && plmLink != undefined) {
          PLMLink = plmLink.Value;
          PLMLink = PLMLink.replace("[QTA0_ID_ISSUE]", item.QTA0_ID_ISSUE);
        }
      }
      let LinklistIssue = "";
      if (issueId != undefined && issueId != "") {
        linkedListft = _.find(projectParameters, function (o) { return o.Key == 'LinklistFT'; })

        if (linkedListft != null && linkedListft != undefined) {
          LinklistIssue = linkedListft.Value;
          LinklistIssue = LinklistIssue.replace("[QTA0_ID_ISSUE]", issueId);
          // LinklistIssue = LinklistIssue.replace("[PROJET]", _spPageContextInfo.webServerRelativeUrl.replace(_spPageContextInfo.siteServerRelativeUrl, '').replace('/', ''));
        }
      }




      //TODO: check this contidition in defetcs it´s the same but altisId get QTA0_IDENTIFIANT_FT_ALTIS not QTA0_IDENTIFIANT_FT

      let HasFTorISSUE_ID = altisId != undefined || issueId != undefined;
      let uniqueCodedID = null;
      let ALTISTE_PLM = null;
      if (altisId != undefined && altisId != null) {
        ALTISTE_PLM = "A";
        uniqueCodedID = altisId;
      }
      if (issueId != undefined && issueId != null) {
        ALTISTE_PLM = "P";
        uniqueCodedID = issueId;
      }
      let currentDefect = {
        "id": item.ID,
        "idMeasure": item.ID_MESURE,
        "defectisInputModified":false,
        "isdetailtableselected": false,
        "isInputModified": false,
        "ismodifyaltishselected": false,
        "ismodifyissueselected": false,
        "attach": item.AVEC_PJ,
        "user": item.CODE_DECOUPAGE_BRUT != null ? item.CODE_DECOUPAGE_BRUT : "",
        "userToolTip": item.LIB_DECOUPAGE_BRUT != null ? item.LIB_DECOUPAGE_BRUT : "",
        "codeLoc": item.CODE_LOCALISATION_DETECTE != null ? item.CODE_LOCALISATION_DETECTE : "",
        "localisation": item.LIB_LOCALISATION_DETECTE != null ? item.LIB_LOCALISATION_DETECTE : "",
        "nature": item.LIB_NATURE_DEFAUT != null ? item.LIB_NATURE_DEFAUT : "",
        "codeNature": item.CODE_NATURE_DEFAUT != undefined && item.CODE_NATURE_DEFAUT != null ? item.CODE_NATURE_DEFAUT : "",
        "reporDate": item.CODE_NATURE_DEFAUT != null ? item.CODE_NATURE_DEFAUT : "",
        "severity": { "code": item.GRAVITE, "points": item.POIDS },
        "status": item.NOUVEAUTE != null ? item.NOUVEAUTE : "",
        "currentStatus": item.NOUVEAUTE != null ? item.NOUVEAUTE : "",
        "nBrut": item.NUMERO_DEFAUT_BRUT != null ? item.NUMERO_DEFAUT_BRUT : "",
        "observations": item.OBSERVATION != null ? item.OBSERVATION : "",
        "side": item.LIB_COTE_DEFAUT != null ? item.LIB_COTE_DEFAUT : "",
        "sideCode": item.CODE_COTE_DEFAUT != null ? item.CODE_COTE_DEFAUT : "",
        "aparitionType": item.TYPE_APPARITION != null ? item.TYPE_APPARITION : "",
        "altisId": altisId,
        "issueId": issueId,
        "hasFTorISSUE_ID": HasFTorISSUE_ID,
        "ALTISTE_PLM": ALTISTE_PLM,
        "uniqueCodedID": uniqueCodedID,
        "altisLink": altisLink,
        "PLMLink": PLMLink,
        "codifState": item.ETAT_CODIFICATION != null ? item.ETAT_CODIFICATION : "",
        "codifStateIconSrc": this.codifStateIconMap[item.ETAT_CODIFICATION].srcIcon != null ? this.codifStateIconMap[item.ETAT_CODIFICATION].srcIcon : "",
        "origine": ORIGINE_DEFAUT != null ? ORIGINE_DEFAUT : "",
        "nBrutLink": nBrutLink,
        "allowQuickStateChange": item.ETAT_CODIFICATION != "CODED" && (item.ANNULE == undefined || item.ANNULE == null || item.ANNULE != 1),
        "qtb9_id": item.QTB9_ID,
        "annule": item.ANNULE,
        "date_maj_titan": item.DATE_MAJ_TITAN,
        "date_maj_brut": item.DATE_MAJ_BRUT,
        "linklistFT": LinklistFT,
        "linklistIssue": LinklistIssue,
        "filterableText": (!item.NUMERO_DEFAUT_BRUT ? "" : item.NUMERO_DEFAUT_BRUT) + (!item.CODE_LOCALISATION_DETECTE ? "" : item.CODE_LOCALISATION_DETECTE) +
          (!item.OBSERVATION ? "" : item.OBSERVATION) + (!item.LIB_LOCALISATION_DETECTE ? "" : item.LIB_LOCALISATION_DETECTE) +
          (!item.CODE_DECOUPAGE_BRUT ? "" : item.CODE_DECOUPAGE_BRUT) + (!item.CODE_NATURE_DEFAUT ? "" : item.CODE_NATURE_DEFAUT) +
          (!item.LIB_NATURE_DEFAUT ? "" : item.LIB_NATURE_DEFAUT) + (!item.LIB_COTE_DEFAUT ? "" : item.LIB_COTE_DEFAUT) + statutTitan

      };
      /**In new implimentation if status is unknown it should be shown and known */
      if (currentDefect.status == 'I' || currentDefect.currentStatus=='I')
        currentDefect.status = 'C';currentDefect.currentStatus = 'C'
      this.defects.push(currentDefect);
    })
    return this.defects;




  }
  stausChange(item,state){
    
    item.status= state
    this.changeState(item,state, true)
  }
  getOriginsAltis() {
    
    if (this.dataUserLang) {
      this.codSeaservice.getAltisOrigins(this.dataUserLang).subscribe((data: any) => {
        this.altisOrigins = data;
    
        
      })
    }

  }

  getPieces(requestParam) {
   
    this.piecesList=[]
    this.codSeaservice.getpiecesFilter(requestParam).subscribe(
      (data: any) => {
        data.GetPiecesResult.forEach(element => {
          let currentPiece = { "key": "", "value": "" }
          currentPiece.key = element.Key;
          currentPiece.value = element.Value;
          this.piecesList.push(currentPiece);
        });
        this.filteredpiecesList = this.piecesList;
        console.log("piecelist",this.piecesList);
        
        
        
      },
      (error: any) => this.errorMessage = JSON.stringify(error)
    );
  }
  configurePiecesInput(coded, id) {
    let defectCodedType = !coded ? "uncoded" : "coded";
    let pieceNameByIDArray = []
    let workvalue = this.defectInfo[defectCodedType][id].workpieceChoiceID
    if (workvalue != "" && workvalue != null) {
      pieceNameByIDArray = _.filter(this.piecesList, function (item) {
        return item.key == workvalue;
      });
    }
    if (pieceNameByIDArray.length > 0) {
      this.defectInfo[defectCodedType][id].workpieceChoice = pieceNameByIDArray[0].value;
      this.defectInfo[defectCodedType][id].workpieceChoiceData = { key: pieceNameByIDArray[0].key, value: pieceNameByIDArray[0].value }
      if(defectCodedType=='uncoded' && _.isNil(this.defectInfoCopy.uncoded[id])){
       JSON.parse(this.defectInfoCopy.uncoded[id]).workpieceChoice = JSON.stringify(pieceNameByIDArray[0].value);
       JSON.parse(this.defectInfoCopy.uncoded[id]).workpieceChoiceData =  JSON.stringify({ key: pieceNameByIDArray[0].key, value: pieceNameByIDArray[0].value })
      }
     
      if(defectCodedType=='coded' && _.isNil(this.defectInfoCopyCoded.coded[id])){
        JSON.parse(this.defectInfoCopyCoded.coded[id]).workpieceChoice = JSON.stringify(pieceNameByIDArray[0].value);
        JSON.parse(this.defectInfoCopyCoded.coded[id]).workpieceChoiceData =  JSON.stringify({ key: pieceNameByIDArray[0].key, value: pieceNameByIDArray[0].value })
       }
    }

    if (!this.defectInfo[defectCodedType][id].idFTTItan) {


      if (this.dataUserLang) {
        let defect = _.filter(this.defects, function (item) { return item.id == id });
        let reqparams = {
          launchid: this.vehicleInfo.idLanzament,
          locale: this.dataUserLang,
          codLoc: defect[0].codeLoc
        }
        this.codSeaservice.getDefaultPiece(reqparams).subscribe(
          (data: any) => {
            if (data.GetDefaultPieceChoiceResult != undefined && data.GetDefaultPieceChoiceResult.length > 0) {
              this.defectInfo[defectCodedType][id].workpieceChoiceID = data.GetDefaultPieceChoiceResult[0].Key;
              this.defectInfo[defectCodedType][id].workpieceChoice = data.GetDefaultPieceChoiceResult[0].Value;
              this.defectInfo[defectCodedType][id].workpieceChoiceData = { key: data.GetDefaultPieceChoiceResult[0].Key, value: data.GetDefaultPieceChoiceResult[0].Value }
            
           if(defectCodedType=='uncoded' && _.isNil(this.defectInfoCopy.uncoded[id])){
            JSON.parse(this.defectInfoCopy.uncoded[id]).workpieceChoice = JSON.stringify(pieceNameByIDArray[0].value);
              JSON.parse(this.defectInfoCopy.uncoded[id]).workpieceChoiceData =  JSON.stringify({ key: pieceNameByIDArray[0].key, value: pieceNameByIDArray[0].value })
          }
     
            if(defectCodedType=='coded' && _.isNil(this.defectInfoCopyCoded.coded[id])){
             JSON.parse(this.defectInfoCopyCoded.coded[id]).workpieceChoice = JSON.stringify(pieceNameByIDArray[0].value);
             JSON.parse(this.defectInfoCopyCoded.coded[id]).workpieceChoiceData =  JSON.stringify({ key: pieceNameByIDArray[0].key, value: pieceNameByIDArray[0].value })
              }
              this.changePiece(this.defectInfo[defectCodedType][id], true, coded);
            }
           
            //else {
            //   if (!!callBack) callBack();
            // }
          })

      }
    } else {
      this.changePiece(this.defectInfo[defectCodedType][id], false, coded);
    }
    console.log(this.defectInfo[defectCodedType][id])
  }
  //get enginerring team

  getPieceAssociatedInfo(pieceid) {
    let reqparms = {
      launchid: this.vehicleInfo.idLanzament,
      choiceId: pieceid,
      locale: this.dataUserLang
    }
    this.codSeaservice.getPieceAssociatedInfo(reqparms).subscribe(
      (result: any) => {
        let pieceInfo = []
        result.forEach(element => {
          let currentPiece = {
            "ID": element.ID,
            "CODE_DECOUPAGE_PSA": element.CODE_DECOUPAGE_PSA,
            "COFOR": element.COFOR,
            "lot": element.METIER_POUR_ACTION_NIV_3,
            "businessDriverName": element.PILOTE,
            "businessDriverDisplayName": element.PILOTE_DISPLAY,
            "tradeForAction": element.METIER_POUR_ACTION_NIV_1 + " - " + element.METIER_POUR_ACTION_NIV_2,
            "altistePlm": element.ALTISTE_PLM

          };
          pieceInfo.push(currentPiece);

        });
      })
  }
  //when piece will change this function will be called to get enginerring team data
  changePiece(defectObject, forceAssociatedData, coded) {
  
    //let coded:boolean;if()
    if (defectObject.workpieceChoiceData != null && defectObject.workpieceChoiceData != undefined) {
      if (defectObject.workpieceChoiceData.key != "" && defectObject.workpieceChoiceData.key != null) {
        defectObject.workpieceChoiceID = defectObject.workpieceChoiceData.key
        let reqparms = {
          locale: this.dataUserLang,
          launchid: this.vehicleInfo.idLanzament,
          choiceId: defectObject.workpieceChoiceData.key
        }
        this.codSeaservice.getPieceAssociatedInfo(reqparms).subscribe(
          (data: any) => {
          
            let result = data;
            let pieceInfo = [];
            result.forEach(element => {

              let currentPiece = {
                "ID": element.ID,
                "CODE_DECOUPAGE_PSA": element.CODE_DECOUPAGE_PSA,
                "COFOR": element.COFOR,
                "lot": element.METIER_POUR_ACTION_NIV_3,
                "businessDriverName": element.PILOTE,
                "businessDriverDisplayName": element.PILOTE_DISPLAY,
                "tradeForAction": element.METIER_POUR_ACTION_NIV_1 + " - " + element.METIER_POUR_ACTION_NIV_2,
                "altistePlm": element.ALTISTE_PLM

              };
              
              let AlreadyExists = _.filter(pieceInfo, function (element, index) {
                return element.CODE_DECOUPAGE_PSA == currentPiece.CODE_DECOUPAGE_PSA &&
                  element.COFOR == currentPiece.COFOR &&
                  element.lot == currentPiece.lot &&
                  element.businessDriverName == currentPiece.businessDriverName &&
                  element.businessDriverDisplayName == currentPiece.businessDriverDisplayName &&
                  element.tradeForAction == currentPiece.tradeForAction;
              });
              //We only can add pieceInfo if it doesn´t exist [SPT-2473]
              if (AlreadyExists == null || AlreadyExists.length == 0)
                pieceInfo.push(currentPiece);
            });

            defectObject.pieceInfo = pieceInfo;

            let existsStoredPiece = _.filter(defectObject.pieceInfo, function (p) {
              return p.tradeForAction + p.lot == defectObject.tradeForAction + defectObject.lot;
            })
        
            if (!!defectObject.workpieceChoiceID && existsStoredPiece.length == 0 && defectObject.tradeForAction!="") {
              let storedPiece = {
                "ID": -1,
                "COFOR": defectObject.COFOR,
                "lot": defectObject.lot,
                "businessDriverName": defectObject.businessDriverName,
                "businessDriverDisplayName": defectObject.businessDriverDisplayName,
                "tradeForAction": defectObject.tradeForAction,
              };
              pieceInfo.push(storedPiece);
            }

            if (defectObject.pieceInfo.length > 0) {
              if (!!forceAssociatedData) {
                let defaultPieceInfo = _.filter(pieceInfo, function (p) {
                  return defectObject.workpieceChoiceID == p.ID;
                });
              
                if (defaultPieceInfo.length > 0) {
                  defectObject.tradeForAction = defaultPieceInfo[0].tradeForAction;
                  defectObject.tradeForActionID = defaultPieceInfo[0].ID;
                  defectObject.lot = defaultPieceInfo[0].lot;
                  
                  if (!coded) {
                    defectObject.defaultPieceInfo = defaultPieceInfo[0];
                    defectObject.altistePlm = defaultPieceInfo[0].altistePlm;
                    defectObject.COFOR = defaultPieceInfo[0].COFOR;
                    defectObject.businessDriverName = defaultPieceInfo[0].businessDriverName;
                    defectObject.businessDriverDisplayName = defaultPieceInfo[0].businessDriverDisplayName;
                    
                    if( !_.isNil(JSON.parse(this.defectInfoCopy.uncoded[defectObject.id]))){
                      JSON.parse(this.defectInfoCopy.uncoded[defectObject.id]).defaultPieceInfo = JSON.stringify(defaultPieceInfo[0]);
                      JSON.parse(this.defectInfoCopy.uncoded[defectObject.id]).altistePlm =  JSON.stringify(defaultPieceInfo[0].altistePlm)
                      JSON.parse(this.defectInfoCopy.uncoded[defectObject.id]).COFOR =JSON.stringify( defaultPieceInfo[0].COFOR);
                      JSON.parse(this.defectInfoCopy.uncoded[defectObject.id]).businessDriverName = JSON.stringify(defaultPieceInfo[0].businessDriverName);
                      JSON.parse(this.defectInfoCopy.uncoded[defectObject.id]).businessDriverDisplayName = JSON.stringify(defaultPieceInfo[0].businessDriverDisplayName);
                    }
                     
                  }
                }
              } else {
                if (existsStoredPiece.length == 0) {
                  defectObject.tradeForActionID = -1;
                } else {
                  defectObject.tradeForActionID = existsStoredPiece[0].ID;
                  
                }
              }
             
            }
         
          });
      }
    }
    
  }
  parseDefect(item, tagsArray, solutionsArray, relatedFTsArray) {
    let nBrutLink = "";
   
    let ORIGINE_DEFAUT = item.ORIGINE_DEFAUT != null ? item.ORIGINE_DEFAUT.trim() : "";
    let projectParameters = LocalStorage.getItem("PROJECT_PARAMETRS");
    if (ORIGINE_DEFAUT === "SPA") {
      let sparteproject = _.find(projectParameters, function (o) { return o.Key == 'sparte_link'; })
   
      if (sparteproject != null && sparteproject != undefined) {
        nBrutLink = sparteproject.Value;
        nBrutLink = nBrutLink.replace("[NUMERO_DEFAUT_BRUT]", item.NUMERO_DEFAUT_BRUT);
      }


    }
    if (item.ORIGINE_DEFAUT === "NEO") {
      let neoproject = _.find(projectParameters, function (o) { return o.Key == 'neo_link'; })
      if (neoproject != undefined && neoproject != null) {
        nBrutLink = neoproject.Value;
        nBrutLink = nBrutLink.replace("[LIB_SIT]", item.LIB_SIT);
        nBrutLink = nBrutLink.replace("[NOF]", item.NOF);
        nBrutLink = nBrutLink.replace("[BDG]", item.BDG);
        nBrutLink = nBrutLink.replace("[VIS]", item.VIS);
      }
    }
    let altisLink = "";

    if (item.QTA0_IDENTIFIANT_FT_ALTIS != undefined && item.QTA0_IDENTIFIANT_FT_ALTIS != "") {
      let altisproject = _.find(projectParameters, function (o) { return o.Key == 'altis_link'; })
      if (altisproject != null && altisproject != undefined) {
        altisLink = altisproject.Value;
        altisLink = altisLink.replace("[QTA0_IDENTIFIANT_FT]", item.QTA0_IDENTIFIANT_FT_ALTIS);
      }
    }

    let PLMLink = "";
    if (item.QTA0_ID_ISSUE != undefined && item.QTA0_ID_ISSUE != "") {
      let plmLink = _.find(projectParameters, function (o) { return o.Key == 'PLM_link'; })
      if (plmLink != null && plmLink != undefined) {
        PLMLink = plmLink.Value;
        PLMLink = PLMLink.replace("[QTA0_ID_ISSUE]", item.QTA0_ID_ISSUE);
      }
    }
    let LinklistFT = "";
    let linkedListft = _.find(projectParameters, function (o) { return o.Key == 'LinklistFT'; })
    if (item.QTA0_IDENTIFIANT_FT_ALTIS != undefined && item.QTA0_IDENTIFIANT_FT_ALTIS != "") {
      if (linkedListft != null && linkedListft != undefined) {
        LinklistFT = linkedListft.Value;
        LinklistFT = LinklistFT.replace("[QTA0_IDENTIFIANT_FT]", item.QTA0_IDENTIFIANT_FT_ALTIS);
        // LinklistFT = LinklistFT.replace("[PROJET]", _spPageContextInfo.webServerRelativeUrl.replace(_spPageContextInfo.siteServerRelativeUrl, '').replace('/', ''));
      }
    }
    let LinklistIssue = "";
    if (item.QTA0_IDENTIFIANT_ISSUE != undefined && item.QTA0_IDENTIFIANT_ISSUE != "") {

      LinklistIssue = linkedListft.Value;
      LinklistIssue = LinklistFT.replace("[QTA0_IDENTIFIANT_FT]", item.QTA0_IDENTIFIANT_ISSUE);
      //  LinklistIssue = LinklistFT.replace("[PROJET]", _spPageContextInfo.webServerRelativeUrl.replace(_spPageContextInfo.siteServerRelativeUrl, '').replace('/', ''));

    }
    let altisId = typeof (item.QTA0_IDENTIFIANT_FT) == "undefined" ? item.QTA0_IDENTIFIANT_FT_ALTIS : item.QTA0_IDENTIFIANT_FT;
    let issueId = item.QTA0_IDENTIFIANT_ISSUE;
    let HasFTorISSUE_ID = altisId != undefined || issueId != undefined;
    let uniqueCodedID = null;
    let ALTISTE_PLM = null;

    if (altisId != undefined && altisId != null) {
      ALTISTE_PLM = "A";
      uniqueCodedID = altisId;
    }
    if (issueId != undefined && issueId != null) {
      ALTISTE_PLM = "P";
      uniqueCodedID = issueId;
    }


    let defect = {
      "basic": {
        "id": item.ID,
        "idMeasure": item.ID_MESURE,
        "attach": item.AVEC_PJ,
        "user": item.CODE_DECOUPAGE_BRUT != null ? item.CODE_DECOUPAGE_BRUT : "",
        "userToolTip": item.LIB_DECOUPAGE_BRUT != null ? item.LIB_DECOUPAGE_BRUT : "",
        "codeLoc": item.CODE_LOCALISATION_DETECTE != null ? item.CODE_LOCALISATION_DETECTE : "",
        "localisation": item.LIB_LOCALISATION_DETECTE != null ? item.LIB_LOCALISATION_DETECTE : "",
        "nature": item.LIB_NATURE_DEFAUT != null ? item.LIB_NATURE_DEFAUT : "",
        "codeNature": item.CODE_NATURE_DEFAUT != undefined && item.CODE_NATURE_DEFAUT != null ? item.CODE_NATURE_DEFAUT : "",
        "reporDate": item.CODE_NATURE_DEFAUT != null ? item.CODE_NATURE_DEFAUT : "",
        "severity": { "code": item.GRAVITE, "points": item.POIDS },
        "status": item.NOUVEAUTE != null ? item.NOUVEAUTE : "",
        "currentStatus": item.NOUVEAUTE != null ? item.NOUVEAUTE : "",
        "nBrut": item.NUMERO_DEFAUT_BRUT != null ? item.NUMERO_DEFAUT_BRUT : "",
        "observations": item.OBSERVATION != null ? item.OBSERVATION : "",
        "side": item.LIB_COTE_DEFAUT != null ? item.LIB_COTE_DEFAUT : "",
        "sideCode": item.CODE_COTE_DEFAUT != null ? item.CODE_COTE_DEFAUT : "",
        "aparitionType": item.TYPE_APPARITION != null ? item.TYPE_APPARITION : "",
        "altisId": altisId,
        "issueId": issueId,
        "hasFTorISSUE_ID": HasFTorISSUE_ID,
        "ALTISTE_PLM": ALTISTE_PLM,
        "uniqueCodedID": uniqueCodedID,
        "altisLink": altisLink,
        "PLMLink": PLMLink,
        "codifState": item.ETAT_CODIFICATION != null ? item.ETAT_CODIFICATION : "",
        "codifStateIconSrc": this.codifStateIconMap[item.ETAT_CODIFICATION].srcIcon != null ? this.codifStateIconMap[item.ETAT_CODIFICATION].srcIcon : "",
        "origine": ORIGINE_DEFAUT != null ? ORIGINE_DEFAUT : "",
        "nBrutLink": nBrutLink,
        "allowQuickStateChange": item.ETAT_CODIFICATION != "CODED" && (item.ANNULE == undefined || item.ANNULE == null || item.ANNULE != 1),
        "qtb9_id": item.QTB9_ID,
        "annule": item.ANNULE,
        "date_maj_titan": item.DATE_MAJ_TITAN,
        "date_maj_brut": item.DATE_MAJ_BRUT,
        "linklistFT": LinklistFT,
        "linklistIssue": LinklistIssue,

        "filterableText": (!item.NUMERO_DEFAUT_BRUT ? "" : item.NUMERO_DEFAUT_BRUT) + (!item.CODE_LOCALISATION_DETECTE ? "" : item.CODE_LOCALISATION_DETECTE) +
          (!item.OBSERVATION ? "" : item.OBSERVATION) + (!item.LIB_LOCALISATION_DETECTE ? "" : item.LIB_LOCALISATION_DETECTE) +
          (!item.CODE_DECOUPAGE_BRUT ? "" : item.CODE_DECOUPAGE_BRUT) + (!item.CODE_NATURE_DEFAUT ? "" : item.CODE_NATURE_DEFAUT) +
          (!item.LIB_NATURE_DEFAUT ? "" : item.LIB_NATURE_DEFAUT) + (!item.LIB_COTE_DEFAUT ? "" : item.LIB_COTE_DEFAUT)


      },

      "detail":
        !item.QTB9_ID_FT_TITAN ? //DB Fields sources to Input
          {
            "id": item.ID,

            "workpieceChoice": item.QTR4_LIB_DECOUPAGE_PSA != null ? item.QTR4_LIB_DECOUPAGE_PSA : "",
            "workpieceChoiceCode": item.QTR4_CODE_DECOUPAGE_PSA,
            "workpieceChoiceID": item.QTB9_ID_DECOUPAGE_PSA != null ? item.QTB9_ID_DECOUPAGE_PSA : "",
            "workpieceChoiceData": { key: item.QTB9_ID_DECOUPAGE_PSA != null ? item.QTB9_ID_DECOUPAGE_PSA : "", value: (!item.QTR4_LIB_DECOUPAGE_PSA? "" : item.QTR4_LIB_DECOUPAGE_PSA+" - ")+(!item.QTR4_DESIGNATION_SUPPL ? "" : item.QTR4_DESIGNATION_SUPPL) },
            "additionalDesignation": item.QTR4_DESIGNATION_SUPPL,
            "workpieceChoiceAndAditional": (!item.QTR4_LIB_DECOUPAGE_PSA ? "" : item.QTR4_LIB_DECOUPAGE_PSA + "-") + (!item.QTR4_DESIGNATION_SUPPL ? "" : item.QTR4_DESIGNATION_SUPPL),
            "tradeForAction": !item.QTB9_METIER_POUR_ACTION ? "" : item.QTB9_METIER_POUR_ACTION,

            "lot": !item.QTB9_LOT ? "" : item.QTB9_LOT,
            "altistePlm": !item.QTB9_ALTISTE_PLM ? "" : item.QTB9_ALTISTE_PLM,
            "titanWord": (!item.LIB_LOCALISATION_DETECTE ? "" : item.LIB_LOCALISATION_DETECTE) + " – " + (!item.LIB_NATURE_DEFAUT ? "" : item.LIB_NATURE_DEFAUT),
            "FTText": (!item.LIB_LOCALISATION_DETECTE ? "" : item.LIB_LOCALISATION_DETECTE) + " – " + (!item.LIB_NATURE_DEFAUT ? "" : item.LIB_NATURE_DEFAUT),
            "FTDescription": (!item.OBSERVATION ? "" : (item.OBSERVATION + "\n")) +
              (!item.LIB_SITUATION_VIE ? "" : (item.LIB_SITUATION_VIE + "\n")) +
              (!item.LIB_NATURE_DEFAUT ? "" : (item.LIB_NATURE_DEFAUT + "\n")) +
              (!item.KILOMETRAGE ? "" : "KM = " + item.KILOMETRAGE),
            "FTOrigin": item.QTA0_CODE_ORIGINE_FT,
            "COFOR": item.QTR4_COFOR,
            //"ALTISTE_PLM": item.QTR4_ALTISTE_PLM,
            "businessDriverName": item.QTA0_PILOTE_FT,
            "imageAttachments": item.ImageAttachments,
            "linkAttachments": item.LinkAttachments,
            //"attachments": [{ "type": "image", "url": "../../Style Library/img/image_gallery.png", "main": true }, { "type": "video", "name": "video1", "url": "" }], //TODO
            "tags": tagsArray,
            "origine": item.ORIGINE_DEFAUT,
            "filter": { "id": "", "title": "", "defectsNumber": "" },
            "idFTTItan": item.QTB9_ID_FT_TITAN,
            "solutions": solutionsArray,
            "FTs": relatedFTsArray,
            "pieceInfo": [],
            "defaultPieceInfo": []
          } : //DB Fields to store/view data
          {
            "id": item.ID,

            "workpieceChoice": item.QTR4_LIB_DECOUPAGE_PSA != null ? item.QTR4_LIB_DECOUPAGE_PSA : "",
            "workpieceChoiceCode": item.QTR4_CODE_DECOUPAGE_PSA != null ? item.QTR4_CODE_DECOUPAGE_PSA : "",
            "workpieceChoiceID": item.QTB9_ID_DECOUPAGE_PSA != null ? item.QTB9_ID_DECOUPAGE_PSA : "",
            "workpieceChoiceData": { key: item.QTB9_ID_DECOUPAGE_PSA != null ? item.QTB9_ID_DECOUPAGE_PSA : "", value: (!item.QTR4_LIB_DECOUPAGE_PSA? "" : item.QTR4_LIB_DECOUPAGE_PSA+" - ")+(!item.QTR4_DESIGNATION_SUPPL ? "" : item.QTR4_DESIGNATION_SUPPL) },

            "additionalDesignation": item.QTR4_DESIGNATION_SUPPL,
            "workpieceChoiceAndAditional": (!item.QTR4_LIB_DECOUPAGE_PSA ? "" : item.QTR4_LIB_DECOUPAGE_PSA + "-") + (!item.QTR4_DESIGNATION_SUPPL ? "" : item.QTR4_DESIGNATION_SUPPL),
            "tradeForAction": item.QTB9_METIER_POUR_ACTION != null ? item.QTB9_METIER_POUR_ACTION : "",
            "lot": !item.QTB9_LOT != null ? item.QTB9_LOT : "",
            "altistePlm": item.QTB9_ALTISTE_PLM != null ? item.QTB9_ALTISTE_PLM : "",
            "titanWord": item.QTB9_LIBELLE != null ? item.QTB9_LIBELLE : "",
            "FTText": item.QTA0_LIBELLE_FT != null ? item.QTA0_LIBELLE_FT : "",
            "FTDescription": item.QTA0_DESCR_DETAIL_FT != null ? item.QTA0_DESCR_DETAIL_FT : "",
            "COFOR": item.QTR4_COFOR != null ? item.QTR4_COFOR : "",
            //"ALTISTE_PLM": item.QTR4_ALTISTE_PLM,
            "businessDriverName": item.QTA0_PILOTE_FT ? item.QTA0_PILOTE_FT : "",
            "businessDriverDisplayName": (!item.QTA0_PILOTE_FT_DISPLAYNAME ? "" : item.QTA0_PILOTE_FT_DISPLAYNAME),
            "imageAttachments": item.ImageAttachments,
            "linkAttachments": item.LinkAttachments,
            //"attachments": [{ "type": "image", "url": "../../Style Library/img/image_gallery.png", "main": true }, { "type": "video", "name": "video1", "url": "" }], //TODO
            "tags": tagsArray,
            "FTOrigin": item.QTA0_CODE_ORIGINE_FT,
            "FTOriginLib": item.QTA0_LIB_ORIGINE_FT,
            "filter": { "id": "", "title": "", "defectsNumber": "" },
            "idFTTItan": item.QTB9_ID_FT_TITAN,
            "solutions": solutionsArray,
            "FTs": relatedFTsArray,
            "pieceInfo": [],
            "defaultPieceInfo": []
          }
    };
    if(defect.basic.currentStatus=='I' || defect.basic.status=='I')
    {
      defect.basic.currentStatus='C';defect.basic.status='C'
    }
    return defect;
  }
  toggleDefectDetails(itemId, open) {

    let filtered_array = _.filter(
      this.defects, function (item) {
        if (item.id == itemId) {
          item.isdetailtableselected = !item.isdetailtableselected;
          if (!item.isdetailtableselected)
            return false;
        }

      }
    );
    this.enableLoader=true
    let defect = _.filter(this.defects, function (item) { return item.id == itemId });
    // fixed issue NE28061-43 
    this.refreshDefect(itemId, (defect[0].status != 'N' && defect[0].uniqueCodedID), !!(defect[0].uniqueCodedID), "");
    this.getOriginsAltis()
  
  }
  sortFTs(prop, evt) {

    let asc = false;
    this.sortObj.currentColumn = prop;
    this.sortObj.order = this.sortObj.order == "DESC" ? 'ASC' : 'DESC';
    if (this.sortObj.currentColumn != this.sortObj.previousColumn) {
      this.sortObj.previousColumn = this.sortObj.currentColumn
    }
    if (this.sortObj.order == 'ASC') { asc = true }
    else { asc = false };

    this.defects = this.defects.sort(function (a, b) {
      if (asc) return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
      else return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
    });
    return false;
  }
  //called on status change
  changeState(defect, targetStatus, prev) {
    if (defect.codifState == 'DRAFT' && prev) {
      this.chgStateDefect = defect;
      this.chgStateTargetState = targetStatus;
      this.recentdefectId=defect.id
      if (defect.currentStatus != targetStatus) {
        this.statechangeModal=true
        defect.isdetailtableselected = false
      }
      return false;
    }
    this.enableLoader = true
    if (!!defect.altisId) {
      let reqdata = {
        input: {},
        LoginName:this.commonService.getUserID()
      };
      reqdata.input = {
        identifiantFt: defect.altisId, numeroDefaut: defect.id
      }

      this.codSeaservice.unlinkFromFT(reqdata).subscribe((respons: any) => {
        let codeStatusAltis = respons.statusAltis;
        let AltisUnLinkResponse = respons.AltisUnLinkResponse;
        if (AltisUnLinkResponse != undefined && AltisUnLinkResponse != null) {

          if (respons.statusAltis.toString().charAt(0) == "3") {
            defect.currentStatus = targetStatus;
            // $("#defect-info-" + defect.id).hide();
            let req = { "state": targetStatus, "ID": defect.id,"LoginName": this.projectid };
            this.codSeaservice.changeState(req).subscribe(
              (data: any) => {
                defect.altisId = undefined;
                this.refreshDefect(defect.id, true, "", "");
              },
              err => {
                //this.changeStateError = JSON.stringify(err);
                this.enableLoader = false
              });
          } else {
            this.enableLoader = false
          }

          if (codeStatusAltis.toString().charAt(0) != "3") {
            this.showModalInfo("altisMessage." + codeStatusAltis, true,"");
          }


        } else {
          this.enableLoader = false
          this.showModalInfo("ERROR: " + respons.resultTitan, "", "");
        }
      },
        err => {
          // this.messageUnlinkFTError = data.error;
          this.enableLoader = false
        });
    } else if (!!defect.issueId) {
      this.unlinkIssue(defect, targetStatus)
    }
    else {
      this.changeStateOnly(defect, targetStatus)
    }

  }
  closeStateChangeModel()
  {
    
    let con=this.defects.forEach(x => {
      if(x.id==this.recentdefectId){
        x.status=this.chgStateDefect.currentStatus
      }
    });
    this.chgStateDefect.status = this.chgStateDefect.currentStatus
    this.statechangeModal=false
  }
  confirmStateChange(){
    
    this.changeState(this.chgStateDefect, this.chgStateDefect.status,"");
    this.statechangeModal=false
  }
  unlinkIssue(defect, targetStatus) {
    let reqestdata = {
      input: {},
      LoginName:this.commonService.getUserID()
    };
    reqestdata.input = {
      IssueName: defect.issueId, nDefaut: defect.id
    }
    this.codSeaservice.unlinkFromIssue(reqestdata).subscribe((responseun: any) => {
      let codeStatusPLM = responseun.statusPLM;
      let PLMUnLinkResponse = responseun.PLMUnLinkResponse;
      if (PLMUnLinkResponse != undefined && PLMUnLinkResponse != null) {
        if (PLMUnLinkResponse.Status != "Error") {
          defect.currentStatus = targetStatus;
          // $("#defect-info-" + defect.id).hide();
          let req = { "state": targetStatus, "ID": defect.id,"LoginName": this.commonService.getUserID()};
          this.codSeaservice.changeState(req).subscribe(
            (data: any) => {
              defect.issueId = undefined;
              this.refreshDefect(defect.id, true, "", "");
            },
            err => {
              // this.changeStateError = data.error;
              this.enableLoader = false
            });

        } else {
          this.enableLoader = false
        }
        if (PLMUnLinkResponse.Status === "Error") {
          let PLMCode = this.filterPLMMessage(PLMUnLinkResponse.Message);
          this.showModalInfo('plmMessage.' + PLMCode, true, "ERROR: ");
        }

      } else {
        this.enableLoader = false
        this.showModalInfo("ERROR: " + responseun.resultTitan, "", "");
      }

    },
      err => {
        // this.messageUnlinkFTError = data.error;
        this.enableLoader = false
      });
  }
  changeStateOnly(defect, targetStatus) {
    defect.currentStatus = targetStatus;
    let req = { "state": targetStatus, "ID": defect.id,"LoginName":this.commonService.getUserID() };
    this.codSeaservice.changeState(req).subscribe(
      (data: any) => {
        defect.altisId = undefined;
        defect.issueId = undefined;
        if (defect.status == 'C') {

          this.refreshDefect(defect.id, true, "", "");
          this.enableLoader = false
        } else
          this.enableLoader = false
      },
      err => {
        //changeStateError = data.error;
        this.enableLoader = false
      });
  }

  changeMetier(defectObject, coded) {

    let associatedMetierInfo = _.filter(defectObject.pieceInfo, function (p) {
      return p.ID == defectObject.tradeForActionID;
    })
    if (associatedMetierInfo.length > 0) {
      defectObject.lot = associatedMetierInfo[0].lot;
      if (coded) {
        defectObject.businessDriverName = associatedMetierInfo[0].businessDriverName;
        defectObject.businessDriverDisplayName = associatedMetierInfo[0].businessDriverDisplayName;
      }
      defectObject.tradeForAction = associatedMetierInfo[0].tradeForAction;
    }
  }
  /* change of Altis/plm */
  changeDestinationType(defectObject) {
   
    this.changeDestinationTypePiece = undefined;
    this.changeDestinationTypeAltistePlm = undefined;
    if (defectObject != undefined &&
      defectObject != null &&
      defectObject.defaultPieceInfo != undefined &&
      defectObject.defaultPieceInfo != null 
       &&
      defectObject.altistePlm != defectObject.defaultPieceInfo.altistePlm) {
        if(defectObject.defaultPieceInfo.ID>0){
      this.changeDestinationTypePieceID = defectObject.defaultPieceInfo.ID;
      this.changeDestinationTypeAltistePlm = defectObject.altistePlm;
      this.changeDestinationDefectObject = defectObject;
      this.confirmationModal=true
    }
    }
        
    //Calculate value for mapped field FTOrigin
    if (defectObject != undefined && defectObject != null) {
      if (defectObject.FTOrigin != null && defectObject.FTOrigin != "") {
        //Mapped information is inthis.altisOrigins
        if (defectObject.altistePlm == "A") {
          //Changed from P=>A search by field codeValeurAltis set value from codeValeurPLM                                          
          let mapped = _.filter(this.altisOrigins, function (item) { return item.codeValeurPLM == defectObject.FTOrigin });
          if (mapped.length > 0) {
            defectObject.FTOrigin = mapped[0].codeValeurAltis;
          }

        }
        if (defectObject.altistePlm == "P") {
          //Changed from A=>P by field codeValeurPLM set value from codeValeuAltis
          let mapped = _.filter(this.altisOrigins, function (item) { return item.codeValeurAltis == defectObject.FTOrigin });
          if (mapped.length > 0) {
            defectObject.FTOrigin = mapped[0].codeValeurPLM;
          }
        }

      }


    }

    //defectObject.ALTISTE_PLM = associatedMetierInfo[0].ALTISTE_PLM;
  }
  /*Enable disable create technical event buton*/
  createFTEnabled(itemId) {
    this.flag=false
    let result = false;

    if (!_.isUndefined(this.defectInfo.uncoded[itemId])) {
      let FTText = this.defectInfo.uncoded[itemId].FTText != null ? this.defectInfo.uncoded[itemId].FTText : "";
      let FTDescription = this.defectInfo.uncoded[itemId].FTDescription ? this.defectInfo.uncoded[itemId].FTDescription : "";
      let businessDriverName = this.defectInfo.uncoded[itemId].businessDriverName ? this.defectInfo.uncoded[itemId].businessDriverName : "";

      let FTOrigin = this.defectInfo.uncoded[itemId].FTOrigin ? this.defectInfo.uncoded[itemId].FTOrigin : "";
      result = _.isEmpty(FTText) ||
        _.isEmpty(FTDescription) ||
        _.isEmpty(businessDriverName) ||
        _.isEmpty(FTOrigin) ||
        this.defectInfo.uncoded[itemId].altistePlm != 'A';
    }

    return result;
  };

  /*Altis drop down change (modal click confirm) */
  changePieceAltistePlm() {
    
    //Clicked on yes in modal change destination type
    if (this.changeDestinationTypePieceID != undefined &&
      this.changeDestinationTypeAltistePlm != undefined) {
      this.enableLoader = true

      let reqchangepiece = {
        R4_ID: this.changeDestinationTypePieceID,
        ALTISTE_PLM: this.changeDestinationTypeAltistePlm
      }
      this.codSeaservice.updatePieceAltistePlm(reqchangepiece).subscribe(
        (data: any) => {
          this.changeDestinationDefectObject.defaultPieceInfo.altistePlm = this.changeDestinationTypeAltistePlm;
          this.enableLoader = false
        this.confirmationModal=false
        },
        err => {
          this.enableLoader = false
          this.confirmationModal=false
          console.log(JSON.stringify(err))
        });


    }
    this.confirmationModal=false

  }
  /* Add Image  pop up*/
  addNewImage(itemId) {
    this.imageValue=undefined
    this.selectedImage=""
    this.currentDefectAttachId = itemId;
    this.currentAttachment = { "linkUrl": "", "linkDesc": "", "image": "", "imageMain": false };
      this.UploadImage=true;
      this.filename=""

  }
   /* Add link  pop up*/
   addNewlink(itemId) {
     this.linkUrlForm.reset()
    this.currentDefectAttachId = itemId;
    this.currentAttachment = { "linkUrl": "", "linkDesc": "", "image": "", "imageMain": false };
      this.UploadMlmModal=true
  }
  selectImage(event) {
   // this.imageValue=undefined
    this.selectedImage = event.target.files;
      this.filename = event.target.files[0].name;
    
    
  }
  /* get images by defect id*/
  // getDefectAttachments(defectid)
  // {
  //  this.currentDefectAttachId
  //   this.codSeaservice.getImageAttachment().subscribe((imageattres:any)=>{
  //     let imageuploadres=imageattres.GetDefectAttachmentsResult


  //   })
  // }
  /* save Image  attachment*/
  saveImageAttachment() {
    
    console.log("current defect attach id",this.currentDefectAttachId);
    
if(this.currentDefectAttachId!=null && this.currentDefectAttachId>0 && this.currentDefectAttachId!=undefined){
    let se = this.selectedPrinciple
    this.popupLoader = true
    let encryptData;
    let filedata: File = this.selectedImage[0];
    let fileReader: FileReader = new FileReader();
    fileReader.onloadend = (e) => {
      encryptData = fileReader.result;
      let reqParams =
      {
        "saveimageAttachment":
          [{ "TITLE": "", "DEFAULTPICTURE": 0, "EDMU": "", "DEFECTID": "", "FILENAME": "", "CREATEDBY": "", "image": "" }]
      }
      let jsonData = JSON.stringify(fileReader.result).replace(PROJECT_IMAGE_TYPES.PNG, "").replace(PROJECT_IMAGE_TYPES.JPEG, "").replace(PROJECT_IMAGE_TYPES.BMP, "")
      reqParams.saveimageAttachment[0].TITLE = ""
      reqParams.saveimageAttachment[0].DEFAULTPICTURE = this.selectedPrinciple ? 1 : 0
      reqParams.saveimageAttachment[0].EDMU = ""
      reqParams.saveimageAttachment[0].DEFECTID = this.currentDefectAttachId
      reqParams.saveimageAttachment[0].FILENAME = this.selectedImage[0].name,
        reqParams.saveimageAttachment[0].CREATEDBY = this.commonService.getUserID(),
        reqParams.saveimageAttachment[0].image = JSON.parse(jsonData)
    console.log("image",reqParams)
        this.codSeaservice.saveImageAttachment(reqParams).subscribe(response => {
          if (response.SaveImageAttachmentResult == "Success") {
           
            this.linkUrlForm.reset()
            
           
           let val =this.defectsAttachments[this.currentDefectAttachId]
           if(val!=undefined && val!=null && val!=""){
           console.log("not undefined",this.defectsAttachments)
            this.refreshAttachments(this.currentDefectAttachId, val.images.length)
           }
           else{
            //previuously this condition was not here (which was same as the existing code) , we changed it to resolve the image
           // upload issue
            console.log("undefined",this.defectsAttachments)
            this.refreshAttachments(this.currentDefectAttachId,1 )
           }
          this.popupLoader=false
           this.UploadImage=false
            this.imageValue=undefined
           
          }
          else{
            this.linkUrlForm.reset()
            this.popupLoader=false
            this.UploadImage=false
            this.imageValue=undefined
            this.showModalInfo(response.SaveImageAttachmentResult,"","")
          }
          this.filename="";
      },
      err=>{
        this.linkUrlForm.reset()
        this.popupLoader = false;
        this.filename="";
      }
      )
    }
    fileReader.readAsDataURL(filedata);
  }

  }
  setImageAsPrinciple(event) {
    this.selectedPrinciple = !this.selectedPrinciple
  }
  /*get next image */
  goNextImage(itemId) {
    this.defectsAttachments[itemId].images.index++;
  }
  /*get previous image */
  goPreviousImage = function (itemId) {
    this.defectsAttachments[itemId].images.index--;
  }
  /**Delete image */
  removeAttachedItem() {
    
    this.enableLoader=true
    if(this.attchmntType.toLowerCase()=='image'){
    let reqParams = {
      "deleteimageAttachment": [{ "ID": "", "DEFECTID": "", "FILENAME": "" }
      ]
    }
    reqParams.deleteimageAttachment[0].ID = this.attchmntId
    reqParams.deleteimageAttachment[0].DEFECTID = this.currentDefectAttachId
    reqParams.deleteimageAttachment[0].FILENAME = this.attchmntname


    this.codSeaservice.deleteImageAttachment(reqParams).subscribe(
      res => {
        if(res.DeleteImageAttachmentResult=="Success"){
          this.enableLoader=false 
        this.refreshAttachments(this.currentDefectAttachId,0)
        this.deleteconfirmationModal=false
        }
        else{
          this.deleteconfirmationModal=false
          this.enableLoader=false 
          this.showModalInfo(res.DeleteImageAttachmentResult,"","")
        }
      },
      err => {
        this.deleteconfirmationModal=false
       this.enableLoader=false
       this.showModalInfo(JSON.parse(err),"","");
      });
    }
   else if(this.attchmntType.toLowerCase()=='link'){
      let delParams = {
        "deleteLinkAttachment": [{ "ID": "", "DEFECTID": "", "FILENAME": "" }
        ]
      }
      delParams.deleteLinkAttachment[0].ID = this.attchmntId
      delParams.deleteLinkAttachment[0].DEFECTID = this.currentDefectAttachId
      this.codSeaservice.deleteAttachmentLink(delParams).subscribe(
        res => {
          if(res.DeleteLinkAttachmentResult=="Success"){
            this.enableLoader=false 
          this.refreshAttachments(this.currentDefectAttachId,0)
          this.deleteconfirmationModal=false
          }
          else{
            this.deleteconfirmationModal=false
            this.enableLoader=false 
            this.showModalInfo(res.DeleteLinkAttachmentResult,"","")
          }
         
        },
        err => {
          this.deleteconfirmationModal=false
          this.enableLoader=false
          this.showModalInfo(JSON.parse(err),"","");
        
        });
      }
  }
   /* setImageAsMain */
  setImageAsMain(defectId,imageId){
    let imagedata = {
      "defectId":"",
      "imageId":"",
      "LoginName":this.commonService.getUserID()
    };
    imagedata.defectId = defectId;
    imagedata.imageId = imageId;
this.codSeaservice.setMainImage(imagedata).subscribe((response:any)=>{
  this.refreshAttachments(defectId,0)
})

  }
  /* Add Mutimedia */
  defectAttachAssociated(itemId, type, attachment) {
    this.currentDefectAttachId = itemId;
    this.attchmntType = type;
    this.attchmntname = attachment.FileName
    this.attchmntId = attachment.ID;
    this.currentAttachment = { "linkUrl": "", "linkDesc": "", "image": "", "imageMain": false };
   this.deleteconfirmationModal=true
  }
  /* Add link pop up save click */
  addDefectLinkAttachment() {
    let formvalue = this.linkUrlForm.value
    if (this.linkUrlForm.valid) {
      this.enableLoader = true; let url = ""; let description = "";
      url = !formvalue.urlLink ? this.currentAttachment.linkUrl : formvalue.urlLink;
      description = !formvalue.linkName ? this.currentAttachment.linkDesc : formvalue.linkName;
      let data = {
        "saveLinkAttachment": [
          {
            "DEFECTID": this.currentDefectAttachId,
            "URL": url,
            "DESCRIPTION": description,
            "CREATEDBY": this.commonService.getUserID(),
            "NOTES": ""
          }]
      }
      this.codSeaservice.addAttachmentLink(data).subscribe(
        response => {
          if (response.SaveLinkAttachmentResult == "Success") {
            this.refreshAttachments(this.currentDefectAttachId, 0)
            this.enableLoader = false
            this.UploadMlmModal=false
          }
          else
          {
            this.UploadMlmModal=false
            this.enableLoader = false
           this.showModalInfo(response.SaveLinkAttachmentResult ,"","")
          }
        },
        error => {
          this.enableLoader = false
          this.modalService.dismissAll()
          //this.showModalInfo(data);
        });
    }
    else {
      return false
    }
  }

  refreshAttachments(defectID, imageIndexSelect) {
    //  $('#waitDialog').modal('show');
    let index = 0;
    let defect = null;
    this.defects.forEach((element, counter) => {
      if (element.id == defectID) {
        index = counter;
        defect = element;
        return false;
      }
    });
    
    let reqp={locale:this.dataUserLang,defectid:defectID}
    this.codSeaservice.getImageAttachment(reqp).subscribe(
       (data:any)=> {
         
        this.defectsAttachments[defectID] = {};
        this.defectsAttachments[defectID].images =  data.ImageAttachments;
        let imagesMainIndexes=0
        if (!imageIndexSelect && imageIndexSelect != 0) {
          let imagesMainIndexes = _.map(data.ImageAttachments, function (obj, index) {
            if (obj.Main) {
              return index;
            }
          });
          this.defectsAttachments[defectID].images.index = imagesMainIndexes.length > 0 ? imagesMainIndexes[0] : 0;
        } else if (data.ImageAttachments.length <= imageIndexSelect) {
          this.defectsAttachments[defectID].images.index = data.ImageAttachments.length - 1;
        } else {
          this.defectsAttachments[defectID].images.index = imageIndexSelect;
        }
        this.defectsAttachments[defectID].links = data.LinkAttachments;
        this.enableLoader=false

      },
      err=>{
         this.enableLoader=false
       
        this.showModalInfo("ERROR: " +  JSON.parse(err),"","");
      }
    );
  };
  createIssueEnabled(itemId) {
    
    let result = false;

    if (!_.isUndefined(this.defectInfo.uncoded[itemId])) {
      let FTText = this.defectInfo.uncoded[itemId].FTText != null ? this.defectInfo.uncoded[itemId].FTText : "";
      let FTDescription = this.defectInfo.uncoded[itemId].FTDescription ? this.defectInfo.uncoded[itemId].FTDescription : "";
      let businessDriverName = this.defectInfo.uncoded[itemId].businessDriverName ? this.defectInfo.uncoded[itemId].businessDriverName : "";

      let FTOrigin = this.defectInfo.uncoded[itemId].FTOrigin ? this.defectInfo.uncoded[itemId].FTOrigin : "";
      result = _.isEmpty(FTText) ||
        _.isEmpty(FTDescription) ||
        _.isEmpty(businessDriverName) ||
        _.isEmpty(FTOrigin) ||
        this.defectInfo.uncoded[itemId].altistePlm != 'P';
    }

    return result;
  };
  defectModified(itemId) {
    return false;
  }
  filterPieces(event, id) {

    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.piecesList.length; i++) {
      let pc = this.piecesList[i];

      if (pc.value.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(pc);
      }
    }

    this.filteredpiecesList = _.uniqBy(filtered,"key");
  }
  filterTags(event, id) {
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.tagList.length; i++) {
      let pc = this.tagList[i];
      if (pc.value.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(pc);
      }
    }
    console.log("4",this.tagList)
    this.tagFilteredList = filtered;
  }
  clearFilters = function () {
    this.defectsSize = 20;
    this.filter = {
      "grossnbrTxt": "",
      "gravityTxt": [],
      "stateTxt": [],
      "copTxt": []
    };
    this.selectedDecison=[]
    this.selectedLancment = []; this.selectedAltisStatus = []; this.selectedDecison = []

  };
  /*Measure Synthesis*/

  totalGraveDefectsText(graves, points) {
    let stringi18n = this.translate.instant('view.defectsSynthesis.totalGraveDefects');
    let result = JSON.stringify(stringi18n).replace("{{points}}", points).replace("{{graves}}", graves);
    result = JSON.parse(result)
    return result
  }
  sythesisEmailDisable() {    
    if (_.isArray(this.defects) && !_.isUndefined(this.measureInfo)) {
      if (this.measureInfo.defautsNotAnulle > this.measureInfo.codedDefectsCount || this.measureInfo.statutSparteNeo != "valide2") {
        this.sendEmailTooltipMsg = this.translate.instant('view.defectsList.codingProgressNotFinished');
        return true;
      } else if (!_.isUndefined(this.emailConfigured)) {
        if (this.emailConfigured == false) {
          this.sendEmailTooltipMsg = this.translate.instant('view.defectsList.mailRecipientsNeeded');
          // return true;
        } else {
          this.sendEmailTooltipMsg = "";
        }
      } else if (this.measureInfo.emailSentDate) {
        this.sendEmailTooltipMsg = this.translate.instant('view.defectsSynthesis.emailAlreadySent') + this.measureInfo.emailSentDate
        //+ $filter('date')(this.measureInfo.emailSentDate, 'dd-MM-yyyy');
      } else {
        this.sendEmailTooltipMsg = "";
      }
      return false;
    }
    return true;
  }
  sendEmail() {
   this.enableLoader=true
  
            if (this.dataUserLang) {
              
              let req={ LOCALE:this.commonService.getProjectLocale(),  
                IDMeasure:this.measureInfo.id,
                  UserName:this.commonService.getUserID()}
                this.codSeaservice.sendEmail(req).subscribe(
                    (data:any)=> {
                      this.enableLoader=false
                        if (data.SendEmailResult == "False") {
                            let msg = this.translate.instant('view.defectsSynthesis.errorEmail');
                          this.showModalInfo(msg,"","");
                        } else if (data.SendEmailResult == "True") {
                            let msg =this.translate.instant('view.defectsSynthesis.emailSent');
                            this.showModalInfo(msg,"","");
                        } else if (data.SendEmailResult.indexOf(',') > -1) {
                            let msg =this.translate.instant('view.defectsSynthesis.errorEmailNoEmails');
                            this.showModalInfo(msg + data.SendEmailResult,"","");
                            
                        } else if (data.SendEmailResult.length > 0) {
                            let msg =this.translate.instant('view.defectsSynthesis.errorEmailNoEmail');
                            this.showModalInfo(msg + data.SendEmailResult,"","");
                        } else {
                            let msg =this.translate.instant('view.defectsSynthesis.errorEmail');
                            this.showModalInfo(msg,"","");
                        }
                        this.getAllRecords();
                    },
                    err =>{
                       this.enableLoader=false
                        let msg =this.translate.instant('view.defectsSynthesis.errorSendingEmail');
                        this.showModalInfo(msg,"","");
                    })
            }
        
    
};
  /*Measure Synthesis*/
  /**To inset id on clicking any row on lauch table */
  selectFTorIssue(id, defect) {
    //SPT-2645 - Change parameter defectIndex by parameter defect, we´ll search this index in $scope.defects
    let indexDefect = this.defects.indexOf(defect);
    this.defects[indexDefect].idIdPrev = id;
  }
  searchdansAltis() {
    let projectParameters = LocalStorage.getItem("PROJECT_PARAMETRS")
    let altisproject = _.find(projectParameters, function (o) { return o.Key.trim() == 'altis_search'; })
    if (altisproject != null && altisproject != undefined) {
      window.open(altisproject.Value, '_blank');
      return false;
    }
  }
  searchdansPLM() {
    let projectParameters = LocalStorage.getItem("PROJECT_PARAMETRS")
    let plmproject = _.find(projectParameters, function (o) { return o.Key == 'plm_search'; })
    if (plmproject != null && plmproject != undefined) {
      window.open(plmproject.Value, '_blank');
      return false;
    }
  }
  /**link to issue called on assign issue  */
  linkToIssue(issueId, nDefaut) {
    
    this.enableLoader = true
    let params = { "state": "C", "ID": nDefaut ,"LoginName":this.commonService.getUserID()};
    this.codSeaservice.changeState(params).subscribe((res: any) => {
      let inputObj = {
        "input": { "IssueName": "", "nDefaut": "","projet": "", "site": "" },
        "LoginName":this.commonService.getUserID()
      }
      inputObj.input.IssueName = issueId; inputObj.input.nDefaut = nDefaut;
      this.codSeaservice.linkToIssue(inputObj).subscribe((data: any) => {
        let LinkIssueResponsePLM = data.LinkIssueResponsePLM;
        if (LinkIssueResponsePLM != undefined && LinkIssueResponsePLM != null) {
          if (LinkIssueResponsePLM.Status !== "Error") {
            this.refreshDefect(nDefaut, true, true, "");
          } else {
            this.enableLoader = false;
          }

          if (LinkIssueResponsePLM.Status === "Error") {
            let PLMCode = this.filterPLMMessage(LinkIssueResponsePLM.Message);
            this.showModalInfo('plmMessage.' + PLMCode, true, "ERROR: ");
            this.enableLoader = false
          }
        } else {
          this.showModalInfo("ERROR: " + data.resultTitan, null, null);
          this.enableLoader = false
        }
      },
        err => {
          this.enableLoader = false
          this.messageLinkFTError = JSON.stringify(err)
          console.log(JSON.stringify(err))
        });
    },
      err => {
        this.enableLoader = false
        this.messageLinkFTError = JSON.stringify(err)
        console.log(JSON.stringify(err))
      });

  }
  /**link to Ft  */
  linkToFT(ftId, defectId) {
    
    this.enableLoader = true
    let params = { "state": "C", "ID": defectId,"LoginName":this.commonService.getUserID() };

    this.codSeaservice.changeState(params).subscribe((data: any) => {
      let inputObj = {
        "input": { "identifiantFt": "", "numeroDefaut": "" },
        "LoginName":this.commonService.getUserID()
      }
      inputObj.input.identifiantFt = ftId;
      inputObj.input.numeroDefaut = defectId;
      this.codSeaservice.linkAltis(inputObj).subscribe((data: any) => {
        let AltisLinkResponse = data.AltisLinkResponse;
        if (AltisLinkResponse != undefined && AltisLinkResponse != null) {
          let codeStatusAltis = data.statusAltis;
          if (data.statusAltis.toString().charAt(0) == "3") {
            this.refreshDefect(defectId, true, true, "");
            this.enableLoader = false
          } else
            this.enableLoader = false
          if (codeStatusAltis.toString().charAt(0) != "3") {
            this.showModalInfo("altisMessage." + codeStatusAltis, true, "");
          }

        } else {
          this.showModalInfo("ERROR: " + data.resultTitan, null, null);
          this.enableLoader = false
        }
      },
        err => {
          this.enableLoader = false
          this.messageLinkFTError = JSON.stringify(err)
          console.log(JSON.stringify(err))
        });
    },
      err => {
        this.enableLoader = false
        this.messageLinkFTError = JSON.stringify(err)
        console.log(JSON.stringify(err))
      });

  }

  filterPLMMessage(plmMessageResponse) {
    //Sometimes PLM returns in message field some information after code. Example: ISSUE_NOT_LINKED:ISS-000016                               
    //On this case, we get only code discarding text after ":"
    let PLMCode = plmMessageResponse.indexOf(":") === -1 ? plmMessageResponse : plmMessageResponse.substring(0, plmMessageResponse.indexOf(":"));

    return PLMCode;

  }

  showModalInfo(msgText, localize, prefix) {
    if (!prefix) {
      prefix = "";
    }
    if (!localize) {
      this.infoModalBody = prefix + msgText

    } else {
      this.infoModalBody = prefix + this.translate.instant(msgText)
    }
    this.InfoModal=true
   
  }
  
  /***
   * Author:Shweta
   * Created:March 1 2021
   * function gets called when user click on Export button on codification screen
   * all param is true of cod sea screen and false for ets screen
   * /**/
  downloadExportFile($event, all) {
    let exportParams = {
      "locale": this.commonService.getUserlocaleName().replace("_", "-"),
      "measureid": this.measureInfo.id,
      "userid": this.commonService.getUserID(),
      "alldefects": 1
    }
    if (this.sythesisExportDisabled) {
      $event.preventDefault();
    } else {
      if (all) {
        exportParams.alldefects = 1;
      }
      else {
        exportParams.alldefects = 0;
      }
      this.codSeaservice.measureExport(exportParams).subscribe((data: any) => {
        let result = data
        if (result.ServiceStatus) {
          if (result.Data != null && result.FileName != "") {
            this.convertToXl(result.Data, result.FileName)
          }
        }
        else {
          console.log("failed to export")
        }

      })

    }
  }
  /**
   * to covert base 64 data
   * Author:shweta
   * created:March 1 2021
   * updated:
   * @param dataURI 
   * @param filename 
   */
  convertToXl(dataURI, filename) {
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      int8Array[i] = byteString.charCodeAt(i);
    }

    let downloadFiletype = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'

    const blob = new Blob([int8Array], { type: downloadFiletype });
    saveAs(blob, filename);
  }
/**
 * api call UpdateDefect called on click of save draft button
 * @param defectObject 
 */
  saveDraft(defectObject) {
    this.flag=false
    this.enableLoader=true;
    let tradeObj=[]
    if(defectObject.pieceInfo.length>0){
     tradeObj=defectObject.pieceInfo.filter(x=>x.ID==defectObject.tradeForActionID)
    }
    let reqparams = {
      id: defectObject.id.toString(),
      ID_DECOUPAGE_PSA: !_.isNil(defectObject.workpieceChoiceID)&&(defectObject.workpieceChoiceID!="") ?defectObject.workpieceChoiceID:null,
      lot: !defectObject.lot ? "" : defectObject.lot,
      altistePlm: !defectObject.altistePlm ? "" : defectObject.altistePlm,
      titanWord: !defectObject.titanWord ? "" : defectObject.titanWord,
      FTText: !defectObject.FTText ? "" : defectObject.FTText,
      FTDescription: !defectObject.FTDescription ? "" : defectObject.FTDescription,
      tradeForAction : tradeObj.length>0 ? tradeObj[0].tradeForAction :"" ,
      businessDriverName: !defectObject.businessDriverName ? "" : defectObject.businessDriverName,
      FTOrigin: !defectObject.FTOrigin ? "" : defectObject.FTOrigin,
      tags: _.map(defectObject.tags, function (n) { return n.value; }),
      LoginName: this.commonService.getUserID(),
      CurrentProjectID:  this.projectid
    };

    this.codSeaservice.saveDefect(reqparams).subscribe(
        (data:any)=> {
          this.enableLoader = true;
          this.clearChangesAfterSave(defectObject.id)
            this.refreshDefect(defectObject.id, true,"","");
           
        },
        err=> {
            this.enableLoader=false
            this.showModalInfo("ERROR: " + JSON.stringify(err),"","");
        });
}
  /**
   * calls on enrich screen cliking onbutton  create the technical issue
   * @param defectObject 
   */
  createFT(defectObject) {
   this.flag=false
    this.enableLoader = true;
    let tradeObj=[]
    if(defectObject.pieceInfo.length>0){
     tradeObj=defectObject.pieceInfo.filter(x=>x.ID==defectObject.tradeForActionID)
    }
    let reqparams = {
      id: defectObject.id.toString(),
      ID_DECOUPAGE_PSA: !_.isNil(defectObject.workpieceChoiceID)&&(defectObject.workpieceChoiceID!="") ?defectObject.workpieceChoiceID:null,
      lot: !defectObject.lot ? "" : defectObject.lot,
      altistePlm: !defectObject.altistePlm ? "" : defectObject.altistePlm,
      titanWord: !defectObject.titanWord ? "" : defectObject.titanWord,
      FTText: !defectObject.FTText ? "" : defectObject.FTText,
      FTDescription: !defectObject.FTDescription ? "" : defectObject.FTDescription,
      tradeForAction : tradeObj.length>0 ? tradeObj[0].tradeForAction :"" ,
      businessDriverName: !defectObject.businessDriverName ? "" : defectObject.businessDriverName,
      FTOrigin: !defectObject.FTOrigin ? "" : defectObject.FTOrigin,
      tags: _.map(defectObject.tags, function (n) { return n.value; }),
      LoginName: this.commonService.getUserID(),
      CurrentProjectID: this.projectid
    };


    this.codSeaservice.saveDefect(reqparams).subscribe(
      (res: any) => {
        let inputObj = {
          "input": {  "nDefaut": defectObject.id},
          "LoginName":this.commonService.getUserID(),
          "ProjectID": this.projectid
        }
  
        this.codSeaservice.createFT(inputObj).subscribe((data: any) => {
          this.clearChangesAfterSave(defectObject.id)
          this.refreshDefect(defectObject.id, true, true, "");
        
          let $altisCreateFTResponse = data.altisCreateFTResponse;
          if ($altisCreateFTResponse != undefined && $altisCreateFTResponse != null) {

            if ($altisCreateFTResponse.Status.toString().charAt(0) != "3") {
              this.showModalInfo("altisMessage." + $altisCreateFTResponse.Status, true, "");
            }
            this.sythesisExportDisabled = false;
            let checkemailparams={id:this.vehicleInfo.idLanzament,loacle:this.dataUserLang}
            this.codSeaservice.checkEmailConfig(checkemailparams).subscribe((data: any) => {
              this.emailConfigured = data.EmailSettingsConfiguredResult;
            })
          } else {
            this.showModalInfo("ERROR: " + data.resultTitan, false, "");
          }
        },
          err=> {
            this.refreshDefect(defectObject.id, true,"","");
            this.enableLoader=false
           
            this.showModalInfo("ERROR: " + JSON.stringify(err),"","");
          }
            )

      },
      err => {
        this.enableLoader = false
        this.showModalInfo("ERROR: " + err, "", "");
      });
  }
  /**
   * calls on enrich screen cliking on create the create issue
   * @param defectObject 
   */
  createIssue(defectObject) {
   this.flag=false;
    this.enableLoader = true;
    let tradeObj=[]
    if(defectObject.pieceInfo.length>0){
     tradeObj=defectObject.pieceInfo.filter(x=>x.ID==defectObject.tradeForActionID)
    }
    let reqparams = {
      id: defectObject.id.toString(),
      ID_DECOUPAGE_PSA: !_.isNil(defectObject.workpieceChoiceID)&&(defectObject.workpieceChoiceID!="") ?defectObject.workpieceChoiceID:null,
      lot: !defectObject.lot ? "" : defectObject.lot,
      altistePlm: !defectObject.altistePlm ? "" : defectObject.altistePlm,
      titanWord: !defectObject.titanWord ? "" : defectObject.titanWord,
      FTText: !defectObject.FTText ? "" : defectObject.FTText,
      FTDescription: !defectObject.FTDescription ? "" : defectObject.FTDescription,
      tradeForAction : tradeObj.length>0 ? tradeObj[0].tradeForAction :"" ,
      businessDriverName: !defectObject.businessDriverName ? "" : defectObject.businessDriverName,
      FTOrigin: !defectObject.FTOrigin ? "" : defectObject.FTOrigin,
      tags: _.map(defectObject.tags, function (n) { return n.value; }),
      LoginName: this.commonService.getUserID(),
      CurrentProjectID:  this.projectid
    };

    this.codSeaservice.saveDefect(reqparams).subscribe((data: any) => {
      let inputObj = {
        "input": {  "nDefaut": defectObject.id},
        "LoginName":this.commonService.getUserID(),
        "ProjectID": this.projectid
      }
    
      this.codSeaservice.createIssue(inputObj).subscribe(
        (data: any) => {
          this.enableLoader = false;
          this.refreshDefect(defectObject.id, true, true, "");
       this.clearChangesAfterSave(defectObject.id);
       
          //$altisCreateFTResponse
          let PLMCreateResponse = data.CreateResponse;
          if (PLMCreateResponse != undefined && PLMCreateResponse != null) {

            if (PLMCreateResponse.Status == "Error") {
              let PLMCode = this.filterPLMMessage(PLMCreateResponse.Message);
              this.showModalInfo('plmMessage.' + PLMCode, true, "ERROR: ");

            }
            this.sythesisExportDisabled = false;
            let checkemailparams={id:this.vehicleInfo.idLanzament,loacle:this.dataUserLang}
            this.codSeaservice.checkEmailConfig(checkemailparams).subscribe((data: any) => {
              this.emailConfigured = data.EmailSettingsConfiguredResult;
              this.enableLoader = false;
            })
          } else {
            this.enableLoader = false;
            this.showModalInfo("ERROR: " + data.resultTitan, "", "");
          }
        },
        err => {
          this.refreshDefect(defectObject.id, true, "", "");
          this.enableLoader = false;
          this.showModalInfo("ERROR: " + err, "", "");
        })


    },
      err => {
        this.enableLoader = false
        this.showModalInfo("ERROR: " + err, "", "");
      });

  }
  /**
   * save defects
   */
  saveDefect(defectObject) {

    this.enableLoader = true;
    let tradeObj=[]
    if(defectObject.pieceInfo.length>0){
     tradeObj=defectObject.pieceInfo.filter(x=>x.ID==defectObject.tradeForActionID)
    }
    let reqparams = {
      id: defectObject.id.toString(),
     ID_DECOUPAGE_PSA: !_.isNil(defectObject.workpieceChoiceID)&&(defectObject.workpieceChoiceID!="") ?defectObject.workpieceChoiceID:null,
      lot: !defectObject.lot ? "" : defectObject.lot,
      altistePlm: !defectObject.altistePlm ? "" : defectObject.altistePlm,
      titanWord: !defectObject.titanWord ? "" : defectObject.titanWord,
      FTText: !defectObject.FTText ? "" : defectObject.FTText,
      FTDescription: !defectObject.FTDescription ? "" : defectObject.FTDescription,
      tradeForAction : tradeObj.length>0 ? tradeObj[0].tradeForAction :"" ,
      businessDriverName: !defectObject.businessDriverName ? "" : defectObject.businessDriverName,
      FTOrigin: !defectObject.FTOrigin ? "" : defectObject.FTOrigin,
      tags: _.map(defectObject.tags, function (n) { return n.value; }),
      LoginName: this.commonService.getUserID(),
      CurrentProjectID:  this.projectid
    };

    this.codSeaservice.saveDefect(reqparams).subscribe((data: any) => {
      let response = data
      this.clearChangesAfterSave(defectObject.id);
      this.refreshDefect(defectObject.id, true, "", "");
    },
      err => {
        this.enableLoader = false
        this.showModalInfo("An error occured saving defect: " + JSON.stringify(err), "", "");
      });
  }
  /**Section technical event */
  modifyAltis(itemId) {

    let filtered_array = _.filter(
      this.defects, function (item) {
        if (item.id == itemId) {
          item.isdetailtableselected = false
          item.ismodifyaltishselected = true
          if (!item.ismodifyaltishselected)
            return false;
        }

      }
    );

  }
clearChangesAfterSave(id){
  let filteredData = _.filter(
  this.defects, function (item) {
    if (item.id == id) {
      item.defectisInputModified = false
    }
  });
  this.commonService.setChangedCod(true)
}
  closeModifyAltis(defect, targetStatus, prev) {
    let filteredData = _.filter(
      this.defects, function (item) {
        if (item.id == defect.id) {
          item.isdetailtableselected = true
          item.ismodifyaltishselected = false
        }
      });
    this.changeState(defect, targetStatus, prev)
  }
  closeModifyIssue(defect, targetStatus, prev) {
    let filteredData = _.filter(
      this.defects, function (item) {
        if (item.id == defect.id) {
          item.isdetailtableselected = false
          item.ismodifyaltishselected = false
        }
      });
    this.changeState(defect, targetStatus, prev)
  }
  //In case of known previous window shows in case on new all detail close
  cancelModifymodal(id) {
    let filteredData = _.filter(
      this.defects, function (item) {
        if (item.id == id) {
          item.isdetailtableselected = true
          item.ismodifyaltishselected = false
        }
      });
  }
  /**
   * gets calls to get user details
   */
  getuser(){
  
    this.UserList=[]
    this.searchErorMsg="";
      if(!this.userSearchText){
        this.searchErorMsg=this.translate.instant('view.accessmanagement.searchErorMsg');
      }
      else if(this.userSearchText.length < 3){
        this.searchErorMsg=this.translate.instant('view.accessmanagement.noResultfound');
      }
      else{
       this.enableLoader=false;
      let reqparams={
      "SearchText":this.userSearchText,
      "UserLocale":this.dataUserLang
    }
    this.accessservice.getUserAndGoalsBySearchText(reqparams).subscribe(
      responseData => {
        if(responseData.RESULT){
        this.UserList = responseData.lstUserInfoLDAP;
        this.enableLoader=false;
        }
        else{
          this.searchErorMsg=this.translate.instant('view.accessmanagement.noResultfound');
          this.enableLoader=false;
        }
      }, 
      responseError => {
        this.enableLoader = false;}
    );
  }}
  
   /*section pople picker*/
   peoplePicker(id){
     this.userSearchText=""
    this.UserList=[]
    this.searchErorMsg=""
    this.addUser="";
     this.defectidForuser=id
    this.peopledisplayDialog = true;
 }
 onClickRow(username:any){
   
    this.addUser=username
  
  }
  
  
    closePeoplepicker()
    {
      this.peopledisplayDialog = false;
      this.addUser="";
     
    }
    /* Onclick Close email search Popup */
    addUserToForm(){
      if(!_.isNil(this.defectidForuser))
      this.defectInfo.uncoded[this.defectidForuser].businessDriverDisplayName=this.addUser
      this.defectInfo.uncoded[this.defectidForuser].businessDriverName=this.addUser
      this.peopledisplayDialog = false;
      this.changeDetailInput(this.defectInfo.uncoded[this.defectidForuser].id)
      
    }
    
    changeDetailInput(id) {
      
     // this.defectInfoCopy.uncoded[id]=  _.cloneDeep(JSON.stringify(this.defectInfo.uncoded[id]));
      let changed=false
       
      let filteredData = _.filter(
        this.defects, function (item) {
          if (item.id == id) {
            item.defectisInputModified = true
           changed=true
          }
        });
        this.isChange=true
        this.commonService.setChangedCod(false)
      
    }
    discardChanges(id,iscoded){

      this.flag=false
      this.commonService.setChangedCod(true)
      if(iscoded){
        let filteredData = _.filter(
          this.defects, function (item) {
            
            if (item.uniqueCodedID == id) {
              item.defectisInputModified = false
            }
          });
         console.log("before",this.defectInfo.coded[id])
         this.peiceInfo=this.defectInfo.coded[id].pieceInfo
         
          this.defectInfo.coded[id]= JSON.parse(this.defectInfoCopyCoded.coded[id])
        this.defectInfo.coded[id].pieceInfo=this.peiceInfo
        this.defectInfo.coded[id].tradeForActionID="-1"
        
        
          console.log("discard changes",this.defectInfo.coded[id])
         
          
      }
      else{
        let filteredData = _.filter(
          this.defects, function (item) {
            if (item.id == id) {
              item.defectisInputModified = false
            }
          });
          console.log("discard changes",this.defectInfo.uncoded[id])
         this.peiceInfo=this.defectInfo.uncoded[id].pieceInfo
          this.defectInfo.uncoded[id]=JSON.parse(this.defectInfoCopy.uncoded[id])
         this.defectInfo.uncoded[id].tradeForActionID="-1"
         this.defectInfo.uncoded[id].pieceInfo=this.peiceInfo
          console.log("discard changes if not coded",this.defectInfo.uncoded[id])
      }
     
    }
    ngOnDestroy() {
      this.unsubscribe$.next(true);
      this.unsubscribe$.complete();
    }
  /**Section technical event */
}