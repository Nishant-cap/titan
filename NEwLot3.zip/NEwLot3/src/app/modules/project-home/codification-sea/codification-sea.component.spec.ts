import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CodificationSeaComponent } from './codification-sea.component';

describe('CodificationSeaComponent', () => {
  let component: CodificationSeaComponent;
  let fixture: ComponentFixture<CodificationSeaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CodificationSeaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CodificationSeaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
