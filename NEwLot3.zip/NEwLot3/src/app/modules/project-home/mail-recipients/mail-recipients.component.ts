
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MessageService,ConfirmationService } from 'primeng/api';
import {  Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MAIL_TEMPLATE_DEFAULT_VALUE, MAIL_TYPE_BCC, MAIL_TYPE_CC, MAIL_TYPE_FROM, MAIL_TYPE_TO } from 'src/app/constant/auth-constant';
import { AccessManagementService } from 'src/app/service/access-management.service';
import { CommonService } from 'src/app/service/common.service';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { ProjectHomeService } from 'src/app/service/launch.service';
import { MailrecipientService } from 'src/app/service/mailrecipient.service';
import { ProjectService } from 'src/app/service/project.service';
import { NameValidator } from 'src/app/shared/validators/name.validator';
import { Users } from '../../home/access-management/users';

@Component({
  selector: 'app-mail-recipients',
  templateUrl: './mail-recipients.component.html',
  styleUrls: ['./mail-recipients.component.scss'],
  providers: [MessageService, ConfirmationService],
})
export class MailRecipientsComponent implements OnInit {
displayDialog:boolean;
displayEmailDialog:boolean;
dialogHeader;
 accesform:FormGroup
submitted:boolean=false
launchManageData: any;
cols:any[];
mailSearch:any[];
flag:boolean=false;
enableLoader:boolean=false;
popupLoader:boolean=false;
searchPopupLoader:boolean=false;
errorMsg=""
errorMessage:string;
mailData={};
mailListData=[];
searchErorMsg:string
mailValue:any;
emailList:any[];
addmailList:string="";
tempEmailList:any[]
userLanguage:string;
errorRes = '';
list:any[];
message:string="";
addFlag:boolean=true;
msg:string='view.mail.deleteMsg';
headerMsg:string='view.mail.confirmDelete';
acceptMsg:string='view.mail.acceptMsg';
rejectMsg:string='view.mail.rejectMsg';
usersList:Users[];
type:string;
EmailId:any=[]
toEmailId:string="";
fromMailId:string="";
validationFlag:boolean=false
CCmailId:string="";
BCCmailId:string=""
userValidationMsg:string;
fromValidation:string;
toValdiation:string;
CcValidation:string;
BccValidation:string;
toFlag:boolean=false;
fromFlag:boolean=false;
CCflag:boolean=false;
BCCflag:boolean=false;
filterMailList:any;
unknownError = false;
newMail:boolean=false;
filteremail:string;
mailArray:any=[]
userSearch:string;
toMailData:any=[];
setFormData:string=""
noMatchFoundData:string=""
fromMailData:any=[];
CCMailData:any=[];
BCCMailData:any=[]
unsubscribe$: Subject<boolean> = new Subject();
/*parameters for add*/
 reqParams=
{
  "C1MODEL":{
     "LAUNCHID":"",
     "LAUNCHNAME":"",
     "TITLE":"",
     "FROMMAIL":"",
     "TOMAIL":"",
     "BCCMAIL":"",
     "CCMAIL":"",
     "SUBJECTTEMPLATE":"",
     "LOCALE":"",
     "CREATEDBY":"",
     "FROM_NAME":"",
     "TO_NAME":"",
     "BCC_NAME":"",
     "CC_NAME":""
  }
}
/*parameters for update */
reqParameter=
{
  "C1MODEL":{
    "ID":"",
     "LAUNCHID":"",
     "LAUNCHNAME":"",
     "TITLE":"",
     "FROMMAIL":"",
     "TOMAIL":"",
     "BCCMAIL":"",
     "CCMAIL":"",
     "SUBJECTTEMPLATE":"",
     "LOCALE":"",
     "MODIFIEDBY":"",
     "FROM_NAME":"",
     "TO_NAME":"",
     "BCC_NAME":"",
     "CC_NAME":""
  }
}
  projectid:any
  constructor(private fb:FormBuilder,private mailService:MailrecipientService,
    private translate:TranslateService,
    private _launchService: ProjectHomeService,
    private commonservice: CommonService,
    private headerService:HeaderChangeService,
    private accessservice:AccessManagementService,
    private confirmationService:ConfirmationService,
    private messageService: MessageService,
    private activateRoute : ActivatedRoute,
    private projectservice:ProjectService
    ) { }
/***
   * functiona calls on init of page all the intial calls are done here
   * Author:Himanshu
   * created 01/02/2021
   * updated:
   */
  ngOnInit(){ 
    const projectId = this.activateRoute.snapshot.paramMap.get('id');
    this.commonservice.setProjectId(projectId);
    this.projectid = this.commonservice.getProjectId()
    this.projectservice.getprojectDetailById(this.projectid).subscribe((data: any) => {      
      this.commonservice.setProjectName(data.URL_SITE)
      this.commonservice.setProjectLocale(data.LOCALE)
  })

    this.headerService.changeLeftpanel(true)
    this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => {
    this.userLanguage=this.commonservice.getUserlocaleName()
     this.getLaunchData()
     this.buildMailForm();
    this.getMailData();
  });
    this.cols = [
      { field: 'TITLE', header: 'Title',inputType: 'textDate',sortInput:'required' },
      { field: 'LAUNCHNAME', header: 'Launch Name'  ,inputType: 'textDate',sortInput:'required'},
      { field: 'FROM_NAME', header: 'From' ,inputType: 'textDate',sortInput:'required'},
      { field: 'TO_NAME', header: 'To' ,inputType: 'textDate',sortInput:'required'},
      { field: 'SUBJECTTEMPLATE', header: 'Subject Template',inputType: 'textDate',sortInput:'required'},
    ];
    this.mailSearch = [
      { field: 'DISPLAY_NAME', header: 'Name'},
      { field: 'TITLE', header: 'Title'},
      { field: 'DEPARTMENT', header: 'Department'},
      { field: 'EMAIL', header: 'E-Mail'},
      { field: 'MOBILE_NUMBER', header: 'Mobile Number'},
      { field: 'ACCOUNT_NAME', header: 'Account Name'}
    ];
    // this.getLaunchData();
    // this.buildMailForm();
    // this.getMailData();
    
  }
  /***
   * get the mail records
   * Author:Himanshu
   * created 01/02/2021
   * updated:
   */
  getMailData(){
    this.enableLoader=true;
    let param={
      "ProjectID":this.projectid,
      "UserName":this.commonservice.getUserID()
    }
   return  this.mailService.getAllMailRecipients(param).subscribe(data=>{
     this.mailListData=data 
    this.enableLoader=false;
   },
   responseError => {
    this.enableLoader = false; 
  }
   );   
  }
  /***
   * get the list of launch at project level
   * Author:Himanshu
   * created 02/02/2021
   * updated:
   */
  getLaunchData() {
    this.enableLoader=true;
    let param = {
      "ProjectId":this.projectid,
      "locale": this.userLanguage
    }
    this._launchService.getLaunchData(param).subscribe(
      responseData => {
        this.launchManageData = responseData.GetLaunchListResult; 
        this.enableLoader=false;
      },
      responseError => {
        this.enableLoader=false;
      }
    );
  }
 /*form */
  buildMailForm(){
    this.accesform = this.fb.group({
      TITLE: ['', [Validators.required,NameValidator.cannotContainSpace]],
      LAUNCH_NAME: ['',Validators.required],
      FROM: ['',[Validators.required]],
      TO:['',[Validators.required]],
      CC:[''],
      BCC:[''],
      SUBJECT:['']
    });
  }

  formValue() {
    let launchid = this.launchManageData.filter(x => x.Title == this.mailData['LAUNCHNAME'])
  this.accesform.patchValue({ 
  ID:this.mailData['ID'], 
  TITLE: this.mailData['TITLE'],
  LAUNCH_NAME:this.mailData['LAUNCHNAME'],
  FROM:this.mailData['FROM_NAME'],
  TO:this.mailData['TO_NAME'],
  CC:this.mailData['CC_NAME'],
  BCC:this.mailData['BCC_NAME'],
  SUBJECT:this.mailData['SUBJECTTEMPLATE'],
  LOCALE:this.mailData['LOCALE'],
  MODIFIEDBY:this.mailData['MODIFIEDBY'],
  LAUNCHID:(launchid!=undefined?launchid.LaunchId:"0"),
  CREATEDBY:this.mailData['CREATEDBY'],
  
});    
}

  get f() { return this.accesform.controls; }

  /***
   *model pop up on add mail recipients  
   * Author:Himanshu 
   * created 02/02/2021
   * updated:
   */
  addMailRcpnts(){
   this.submitted=false;
    this.toFlag=false;
    this.fromFlag=false;
     this.CCflag=false;
    this.BCCflag=false;
    this.message="";
    this.displayDialog=true;
    this.dialogHeader="Mail Recipient-Add";
    this.newMail=true;
    this.accesform.patchValue({
      TITLE:"",
      LAUNCH_NAME:"",
      FROM: "",
      TO:"",
      CC:"",
      BCC:"",
      SUBJECT:MAIL_TEMPLATE_DEFAULT_VALUE
    })
    //this.accesform.reset();
   // this.mailData={};
   //this.formValue();
  }
/* to edited the data*/
  editMail(ID){
    this.toFlag=false;
    this.fromFlag=false;
    this.CCflag=false;
    this.BCCflag=false;
    this.message="";
    this.accesform.reset();
    this.displayDialog=true;
    this.dialogHeader="Mail Recipient-Edit";
    this.newMail=false;
    let reqParam={
      "ID":ID,
      "UserName":this.commonservice.getUserID()
    }
    this.mailService.getmailRecipientsByID(reqParam).subscribe(
      data => { 
        this.mailData=data;
        this.displayDialog = true;
        this.formValue();
  },
  (error: any) => this.errorMessage = <any>error);
}

  /* to reset the form value */
  resetForm(){
  this.accesform.patchValue({
    TITLE:"",
    LAUNCH_NAME:"",
    FROM:"",
    TO:"",
    CC:"",
    BCC:"",
    SUBJECT:""
  });
}
/***
   *function gets called when clicking on save button  
   * Author:Himanshu
   * created 04/02/2021
   * updated:
   */
   async CheckValidationBeforeSumbit(){
    this.submitted=true;
    this.toFlag=false;
    this.fromFlag=false;
    this.CCflag=false;
    this.BCCflag=false;
    this.toEmailId=""
    this.fromMailId=""
    this.BCCmailId=""
    this.CCmailId=""
     
     await this.checkUser(MAIL_TYPE_FROM);
     
     await this.checkUser(MAIL_TYPE_TO);
     
     await this.checkUser(MAIL_TYPE_CC);
     
     await this.checkUser(MAIL_TYPE_BCC);
    
     if(this.accesform.valid){
    
      if(this.toFlag==false && this.fromFlag==false && this.CCflag==false && this.BCCflag==false){
        
      this.onSubmit()}
     }
     else
     return false;
  }
  
  /*to sumbit the data after user validation*/
   onSubmit(){
     let formdata=this.accesform.value;
     if(this.accesform.valid){
      let selectedLaunchid="0";
      if (formdata.LAUNCH_NAME) {
      let obj = this.launchManageData.filter(x => x.Title == formdata.LAUNCH_NAME)
      
      if(obj[0]!=undefined && obj[0]!=null){
        selectedLaunchid = obj[0].LaunchId
      }else{
        selectedLaunchid="0"
      }
         }

        if(this.newMail){
      this.reqParams.C1MODEL.TITLE=formdata.TITLE
      this.reqParams.C1MODEL.LAUNCHNAME=(formdata.LAUNCH_NAME!=undefined?formdata.LAUNCH_NAME:"")
      this.reqParams.C1MODEL.BCCMAIL=(this.BCCmailId!=undefined?this.BCCmailId:"")
      this.reqParams.C1MODEL.TOMAIL=this.toEmailId
      this.reqParams.C1MODEL.FROMMAIL=this.fromMailId
      this.reqParams.C1MODEL.SUBJECTTEMPLATE=(formdata.SUBJECT!=undefined?formdata.SUBJECT:"")
      this.reqParams.C1MODEL.LOCALE=this.userLanguage
      this.reqParams.C1MODEL.CCMAIL=(this.CCmailId!=undefined?this.CCmailId:"")
      this.reqParams.C1MODEL.CREATEDBY=this.commonservice.getUserID();
      this.reqParams.C1MODEL.LAUNCHID=selectedLaunchid != undefined ? selectedLaunchid : "0";
      this.reqParams.C1MODEL.BCC_NAME=(formdata.BCC!=undefined?formdata.BCC:"")
      this.reqParams.C1MODEL.CC_NAME=(formdata.CC!=undefined?formdata.CC:"")
      this.reqParams.C1MODEL.FROM_NAME=(formdata.FROM!=undefined?formdata.FROM:"")
      this.reqParams.C1MODEL.TO_NAME=(formdata.TO!=undefined?formdata.TO:"")
      this.mailService.addMailData(JSON.stringify(this.reqParams)).subscribe(
        (data: any) =>  {
          if(data.InsertMailRecipientsResult){
           this.getMailData();
            this.displayDialog = false;
            this.showToast('success', 'view.mail.createdMsg', '');
            this.submitted=false;
            }
           else {
            this.message=this.translate.instant('view.mail.FailedMsg');
           }
        },
        (error: any) => this.errorMessage = <any>error
      );   
      }else{
      this.reqParameter.C1MODEL.ID=this.mailData['ID']
      this.reqParameter.C1MODEL.TITLE=formdata.TITLE
      this.reqParameter.C1MODEL.LAUNCHNAME=(formdata.LAUNCH_NAME!=undefined?formdata.LAUNCH_NAME:"")
      this.reqParameter.C1MODEL.BCC_NAME=(formdata.BCC!=undefined?formdata.BCC:"")
      this.reqParameter.C1MODEL.TO_NAME=formdata.TO
      this.reqParameter.C1MODEL.FROM_NAME=formdata.FROM
      this.reqParameter.C1MODEL.SUBJECTTEMPLATE=(formdata.SUBJECT!=undefined?formdata.SUBJECT:"")
      this.reqParameter.C1MODEL.LOCALE=this.userLanguage
      this.reqParameter.C1MODEL.CC_NAME=(formdata.CC!=undefined?formdata.CC:"")
      this.reqParameter.C1MODEL.MODIFIEDBY=this.commonservice.getUserID();
      this.reqParameter.C1MODEL.LAUNCHID=selectedLaunchid != undefined ? selectedLaunchid : "0";
      this.reqParameter.C1MODEL.TOMAIL=this.toEmailId
      this.reqParameter.C1MODEL.FROMMAIL=this.fromMailId.toString()
      this.reqParameter.C1MODEL.BCCMAIL=(this.BCCmailId.toString()!=undefined?this.BCCmailId.toString():"")
      this.reqParameter.C1MODEL.CCMAIL=(this.CCmailId.toString()!=undefined?this.CCmailId.toString():"")
      this.mailService.updateMailData(JSON.stringify(this.reqParameter)).subscribe(
        (data: any) =>{
          if(data.UpdateMailRecipientsResult){
           this.getMailData();
            this.displayDialog = false;
            this.showToast('success', 'view.mail.updatedMsg', '');
            this.submitted=false;
            }
           else {
             this.message=this.translate.instant('view.mail.FailedMsg');
           }
        },
        (error: any) => this.errorMessage = <any>error
      ); 
      }
}    else
     return false;

  }
/*toaster to show successful and failure msg*/
  showToast(severity, summary, detail) {
    let res= this.translate.instant(summary)
    this.messageService.add({ key: 'tc', severity: severity, summary: res, detail: detail });
  }
/*pop up for email list*/
openDialogModel(type)
{  
  this.searchErorMsg="";
  this.userSearch=""
  this.emailList=null;
  this.flag=false
  this.type=type;
  if(this.type==MAIL_TYPE_FROM){
    this.addFlag=false;
  }
  else{
    this.addFlag=true;
  }
  this.displayEmailDialog=true;
}
/***
   * get the user list based on search text
   * Author:Himanshu
   * created 01/02/2021
   * updated:
   */
  
getemailID(){
  this.emailList=null
  this.searchErorMsg="";
    if(!this.userSearch){
      this.searchErorMsg=this.translate.instant('view.mail.searchErorMsg');
    }
    else if(this.userSearch.length < 4){
      this.searchErorMsg=this.translate.instant('view.mail.noResultfound');
    }
    else{
      this.searchPopupLoader=true;
    let reqparams={
    "Searchtext":this.userSearch,
    "UserLocale":this.userLanguage
  }
    this.mailService.getUserAndEmailIDBySearchText(reqparams).subscribe(
      responseData => {
        if(responseData.RESULT){
        this.emailList = responseData.lstUserInfoLDAP;
        this.searchPopupLoader=false;
        }
        else{
          this.searchErorMsg=this.translate.instant('view.mail.noResultfound');
          this.searchPopupLoader=false;
        }
      }, 
      responseError => {
        this.searchPopupLoader=false;
      }
    );
}
  }
  
  /*to check whether user is existing or not*/
  async checkUser(type){ 
    this.popupLoader=true;
    this.tempEmailList=[]
    this.setFormData=""
    this.noMatchFoundData=""
     if(type==MAIL_TYPE_FROM){ this.fromValidation=""}
     if(type==MAIL_TYPE_TO){this.toValdiation=""}
     if(type==MAIL_TYPE_BCC){this.BccValidation=""}
     if(type==MAIL_TYPE_CC){this.CcValidation=""}
    this.message=""
    let searchtxt=this.accesform.controls[type].value
    
    if(searchtxt==null || searchtxt==""){
      if(type==MAIL_TYPE_FROM){
        this.fromFlag=true;
        this.fromValidation=this.translate.instant('view.main.validation.required')
        
      }if(type==MAIL_TYPE_TO){
        this.toFlag=true;
        this.toValdiation=this.translate.instant('view.main.validation.required')
      }
    }
     else if(searchtxt.length<4){
      if(type==MAIL_TYPE_FROM){
        this.fromFlag=true;
        this.fromValidation=this.translate.instant('view.mail.validationMsg')
      }else if(type==MAIL_TYPE_TO){
        this.toFlag=true;
        this.toValdiation=this.translate.instant('view.mail.validationMsg')
      }
      else if(type==MAIL_TYPE_CC){
        this.CCflag=true;
        this.CcValidation=this.translate.instant('view.mail.validationMsg')
      }
      else if(type==MAIL_TYPE_BCC){
      this.BCCflag=true;
      this.BccValidation=this.translate.instant('view.mail.validationMsg')}
    }
    else{
      let lastChar=searchtxt.slice(-1);
      if(lastChar!=";"){
      searchtxt=searchtxt.concat(";")
    } 
      searchtxt=searchtxt.split(';')
      searchtxt.splice((searchtxt.length -1), 1)
      for(let data of searchtxt){
        data=data.trim()
      let reqparams={
        "Searchtext":data,
        "UserLocale":this.userLanguage
      }
      await this.mailService.getUserAndEmailIDBySearchText(reqparams).toPromise().then(
        responseData => {
          if(responseData.RESULT){
          this.tempEmailList= responseData.lstUserInfoLDAP;
          if(this.tempEmailList.length==1){
          let mailId= this.tempEmailList.find(e=>e.USER_GOAL_ID.toLowerCase()==data.toLowerCase() || e.DISPLAY_NAME.toLowerCase()==data.toLowerCase())
          if(mailId!=undefined && mailId!=null){
            
            this.setFormData=this.setFormData.concat(mailId.DISPLAY_NAME+";");
            this.accesform.controls[type].setValue(this.setFormData)
            if(type==MAIL_TYPE_FROM){
              if(mailId.EMAIL!=null && mailId.EMAIL!=undefined){
              this.fromMailId=this.fromMailId.concat(mailId.EMAIL+";")
            } 
             else{
              this.fromMailId=this.fromMailId.concat(mailId.DISPLAY_NAME+";")
             }            
              if(searchtxt.length!=1){
                this.fromFlag=true;
                this.fromValidation=this.translate.instant('view.mail.fromValidationMsg')
              }
            }
            if(type==MAIL_TYPE_TO){
              if(mailId.EMAIL!=null && mailId.EMAIL!=undefined){
                this.toEmailId=this.toEmailId.concat(mailId.EMAIL+";")
              } 
               else{
                this.toEmailId=this.toEmailId.concat(mailId.DISPLAY_NAME+";")
               }
            }
            if(type==MAIL_TYPE_CC){
              if(mailId.EMAIL!=null && mailId.EMAIL!=undefined){
                this.CCmailId=this.CCmailId.concat(mailId.EMAIL+";")
              } 
               else{
                this.CCmailId=this.CCmailId.concat(mailId.DISPLAY_NAME+";")
               }
               
            }
            if(type==MAIL_TYPE_BCC){
              if(mailId.EMAIL!=null && mailId.EMAIL!=undefined){
                this.BCCmailId=this.BCCmailId.concat(mailId.EMAIL+";")
              } 
               else{
                this.BCCmailId=this.BCCmailId.concat(mailId.DISPLAY_NAME+";")
               }
              
            }
            
          }else{
            this.setFormData=this.setFormData.concat(data+";")
           // this.noMatchFoundData=this.noMatchFoundData.concat(data+";")
            this.accesform.controls[type].setValue(this.setFormData)
              if(type==MAIL_TYPE_FROM){
                if(searchtxt.length!=1){
                  this.fromFlag=true;
                  this.fromValidation=this.translate.instant('view.mail.fromValidationMsg')
                }
                else{
                this.fromFlag=true;
                this.fromValidation=this.translate.instant('view.mail.validationMsg')}
              }else if(type==MAIL_TYPE_TO){
                this.toFlag=true;
                this.toValdiation=this.translate.instant('view.mail.validationMsg')
              }
              else if(type==MAIL_TYPE_CC){
                this.CCflag=true;
                this.CcValidation=this.translate.instant('view.mail.validationMsg')
              }
              else if(type==MAIL_TYPE_BCC){
              this.BCCflag=true;
              this.BccValidation=this.translate.instant('view.mail.validationMsg')}
          }
        }
            else{
              this.setFormData=this.setFormData.concat(data+";")
             // this.noMatchFoundData=this.noMatchFoundData.concat(data+";")
            this.accesform.controls[type].setValue(this.setFormData)
              if(type==MAIL_TYPE_FROM){
                if(searchtxt.length!=1){
                  this.fromFlag=true;
                  this.fromValidation=this.translate.instant('view.mail.fromValidationMsg')
                }
                else{
                this.fromFlag=true;
                this.fromValidation=this.translate.instant('view.mail.validationMsg')}
              }else if(type==MAIL_TYPE_TO){
                this.toFlag=true;
                this.toValdiation=this.translate.instant('view.mail.validationMsg')
              }
              else if(type==MAIL_TYPE_CC){
                this.CCflag=true;
                this.CcValidation=this.translate.instant('view.mail.validationMsg')
              }
              else if(type==MAIL_TYPE_BCC){
              this.BCCflag=true;
              this.BccValidation=this.translate.instant('view.mail.validationMsg')}
            }
           
          }
          else{
            this.setFormData=this.setFormData.concat(data+";")
           // this.noMatchFoundData=this.noMatchFoundData.concat(data+";")
            this.accesform.controls[type].setValue(this.setFormData)
            if(type==MAIL_TYPE_FROM){
              if(searchtxt.length!=1){
                this.fromFlag=true;
                this.fromValidation=this.translate.instant('view.mail.fromValidationMsg')
              }
              else{
              this.fromFlag=true;
              this.fromValidation=this.translate.instant('view.mail.validationMsg')}
            }else if(type==MAIL_TYPE_TO){
              this.toFlag=true;
              this.toValdiation=this.translate.instant('view.mail.validationMsg')
            }
            else if(type==MAIL_TYPE_CC){
              this.CCflag=true;
              this.CcValidation=this.translate.instant('view.mail.validationMsg')
            }
            else if(type==MAIL_TYPE_BCC){
            this.BCCflag=true;
            this.BccValidation=this.translate.instant('view.mail.validationMsg')}
            }
            
        },
        responseError => {
          this.popupLoader=false;
        }
         );
      } 
        
      }this.popupLoader=false;
    }
/*when double click user data*/
  rowSelected(emailList:any){
    if(this.type==MAIL_TYPE_FROM){
      this.flag=false;
      let value=this.accesform.controls['FROM'].value
      if(value!=null && value!=undefined){
      this.accesform.controls['FROM'].setValue(value+emailList.DISPLAY_NAME+";");}
      else{
        this.accesform.controls['FROM'].setValue(emailList.DISPLAY_NAME+";");
      }
      this.displayEmailDialog=false;
      this.addmailList="";
    }
    else{
    this.flag=true;
    this.addmailList=this.addmailList.concat(emailList.DISPLAY_NAME+";");
  }
    }
 /*on one click the user data*/
oneClickRow(emailList:any){
  if(this.type==MAIL_TYPE_FROM){
    this.flag=false;
    this.addmailList=emailList.DISPLAY_NAME+";";
  }
  else{
  this.flag=true;
  this.list=emailList;
  
}
}
/*to concat the email list */
add(emailList:any){
  this.addmailList=this.addmailList.concat(emailList.DISPLAY_NAME+";");
  
}
/*to add the user to the form */
  addListToForm(){
     
    if(this.type==MAIL_TYPE_TO){
      let value=this.accesform.controls['TO'].value
      if(value!=null && value!=undefined){
    this.accesform.controls['TO'].setValue(value+this.addmailList);
      }
      else{
      this.accesform.controls['TO'].setValue(this.addmailList);}
  }
    else if(this.type==MAIL_TYPE_FROM){
      let value=this.accesform.controls['FROM'].value
      if(value!=null && value!=undefined){
    this.accesform.controls['FROM'].setValue(value+this.addmailList);
      }
      else{
        this.accesform.controls['FROM'].setValue(this.addmailList);
      }
    }
    else if(this.type==MAIL_TYPE_CC){
      let value=this.accesform.controls['CC'].value
      if(value!=null && value!=undefined){
      this.accesform.controls['CC'].setValue(value+this.addmailList);
      }else{
        this.accesform.controls['CC'].setValue(this.addmailList);
      }
    }
    else if(this.type==MAIL_TYPE_BCC){
      let value=this.accesform.controls['BCC'].value
      if(value!=null && value!=undefined){
      this.accesform.controls['BCC'].setValue(value+this.addmailList);
      }else{
        this.accesform.controls['BCC'].setValue(this.addmailList);
      }
    }
    this.displayEmailDialog=false;
    this.addmailList="";
    this.flag=false;
   
  }

/*cancel button for add mail popup*/
  cancel(){
    this.resetForm()
    this.displayDialog=false;
    this.submitted=false;
  }
  /* Onclick Close email search Popup */
  cancelEmail()
  {
    this.displayEmailDialog = false;
    this.addmailList="";
    this.flag=false;
    
  }
/***
   * to unsubscribe from the header change event so that api dont get called when page is not loaded 
   * Author:Himanshu Rai
   * created 05/02/2021
   * updated:
   */
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
/* Delete Specific mail record */
deleteEmailRecord(ID) {
  let reqParam={
    "ID":ID,
    "UserName":this.commonservice.getUserID()
  }
  this.confirmationService.confirm({
    message: this.translate.instant(this.msg),
    header: this.translate.instant(this.headerMsg),
    icon: 'pi pi-exclamation-triangle',
    acceptLabel:this.translate.instant(this.acceptMsg),
    rejectLabel:this.translate.instant(this.rejectMsg),
      accept: () => {
        this.mailService.deleteMailRecipientByID(reqParam).subscribe(
          response =>{
            if(response.DeleteMailRecipientsResult){
              this.getMailData();
              this.showToast('success', 'view.mail.deleteConfirmMsg', '');
            }
            
          },
          (error: any) => this.errorMessage = <any>error
        );
      }
  });
}

}
