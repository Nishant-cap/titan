import { HttpClient } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule,TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { LaunchComponent } from './launch.component';
import { AutoCompleteModule, FieldsetModule } from 'primeng/primeng';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { By } from '@angular/platform-browser';
import { EnvService } from 'src/app/env-service/env.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


export const createTranslateLoader = (http: HttpClient) => {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
};

describe('LaunchComponent', () => {
  let component: LaunchComponent;
  let fixture: ComponentFixture<LaunchComponent>;
  let service: EnvService;
  let params:HttpClient;
  let apiurloaderservice = null;
  //done for translate pipe

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,ReactiveFormsModule,FieldsetModule,AutoCompleteModule,TranslateModule.forRoot({
        loader: {
            provide: TranslateLoader,
            useFactory: createTranslateLoader,
            deps: [HttpClient]
        }
    })],
      declarations: [ LaunchComponent ],
      providers:[EnvService,NgbModal]
    })
    .compileComponents();
  }));
 
  beforeEach(() => {
    fixture = TestBed.createComponent(LaunchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  

  it('should create', () => {
    expect(component).toBeTruthy();
  });
    it('should have item  of items' , () => {	
       	component.getLaunchData();	
       	// assertion	
       	expect(component.dataLoadStatus).toBeFalsy;	
       	});

      it('should have master data  of items' , () => {	
         	component.getMasterData();	
         	// assertion	
         	expect(component.dataLoadStatus).toBeFalsy;	
         	});

        
      it('header should have value view.launch.headeredit on edit pop up' , () => {	
         	component.getSingleData(1252);	
         	// assertion	
         	expect(component.headerText).toBe('view.launch.headeredit');	
         	});

});
