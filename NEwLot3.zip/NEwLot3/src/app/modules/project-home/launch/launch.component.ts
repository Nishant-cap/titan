import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ProjectHomeService } from '../../../service/launch.service';
import {ConfirmationService, MessageService } from 'primeng/api';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DialogModule, Dialog } from 'primeng/dialog';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { CommonService } from 'src/app/service/common.service';
import * as _ from 'lodash';
import { saveAs } from "file-saver";
import { FILE_TYPE_XLS, FILE_TYPE_XLSX, RECORD_TYPE_SAVE, RECORD_TYPE_UPDATE } from 'src/app/constant/auth-constant';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { rejects } from 'assert';
import { ActivatedRoute } from '@angular/router';
import { ProjectService } from 'src/app/service/project.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';


@Component({
  selector: 'app-launch',
  templateUrl: './launch.component.html',
  styleUrls: ['./launch.component.scss'],
  providers: [MessageService,ConfirmationService]
})
export class LaunchComponent implements OnInit { 
  @ViewChild('UploadFileInput') UploadFileInput: ElementRef;
  public launchManageData: any;
  launch: any
  cols: any[];
  selectedRow;
  errorRes = ''; isObjectiveFile: boolean = false
  isPanningFile: boolean = false
  unknownError = false;
  selectLaunchData: any;
  public editLaunchForm: FormGroup;
  displayDialog: boolean;
  dialogHeader;
  planningvalue:any;
  objectivevalue:any
  submitted: boolean = false;
  dataLoadStatus: boolean = false;
  popupLoader:boolean=false;
  newLaunch:Boolean=false;
  msg:string='view.launch.resultMsg'
  headerText: string = ""
  fileInputLabel: string;
  selectedFiles: FileList;
  selectedFilesObjective:FileList;
  deletemsg:string='view.project.deleteMsg';
  headerMsg:string='view.project.confirmDelete';
  acceptMsg:string='view.project.acceptMsg';
  rejectMsg:string='view.project.rejectMsg';
  decAltisFilteredList: any = []; decAltisList: any = [];
  projectreflist: any = []; projectrefFilterlist: any = [];
  plmlist: any = []; plmFilterlist: any = []; iseditModal: boolean = false
  manufaclist: any = []; manufacFilterlist: any = []; manutemp: any = []
  filename: string = 'view.pr.message.static'
  filenameObjective:string = 'view.pr.message.static'
  resultmessage: string = ""
  resulMsg = false;
  objectiveMsgFlag:boolean=false;
  planningMsgFlag:boolean=false;
  isUloadEnable: boolean = true
  Listvalue:any
  value:any;
  unsubscribe$: Subject<boolean> = new Subject();
  reqParams = {
    "objectivesPlanningUpload":
    {
      "FileName": "",
      "UserName": "",
      "FileData": "",
      "LaunchID": "",
      "ProjectID": "",
      "UserLocale":""
    }
  }
  projectId:any
  progressInfos = [];
  message = { "message": "", "filename": "" };
  Objectivemessage ={"message":"","filenameObjective":""}
  constructor(
    private messageService: MessageService,
    private fb: FormBuilder,private headerService:HeaderChangeService,
    private modalService: NgbModal,
    private translate: TranslateService, private commonservice: CommonService,
    private _launchService: ProjectHomeService,
    private confirmService:ConfirmationService,
    public route: ActivatedRoute,
    public projectservice: ProjectService

  ) {
    this.editLaunchForm = this.fb.group({
      id: [{ value: '', disabled: true }],
      NOM: ['', [Validators.required]],
      PROJET_VOMB_FT: ['', [Validators.required]],
      SITE_FT: ['', [Validators.required]],
      ID_PROJET: [''],
      USER_CREATION: [''],
      USER_MAJ: [''],
      INSTANCE_DECISION_FT: [''],
      INSTANCE_DECISION_ISSUE: [''],
      CODE_ORIGINE_FT: [''],
    });
  }
  /*functiona calls on init of page all the intial calls are done here*/
  ngOnInit() {
    const projectId = this.route.snapshot.paramMap.get('id');
    this.commonservice.setProjectId(projectId);
    this.projectId =this.commonservice.getProjectId()
    this.projectservice.getprojectDetailById(this.projectId).subscribe((data: any) => {      
      this.commonservice.setProjectName(data.URL_SITE)
      this.commonservice.setProjectLocale(data.LOCALE)
  })
    this.headerService.changeLeftpanel(true)
    this.headerService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => {
      //this.userLanguage=this.commonservice.getUserlocaleName()
       this.getLaunchData()
       this.getMasterData();
    });
    this.cols = [
      { field: 'Launch', header: 'Launch' },
      { field: 'ProjectId', header: 'ProjectId' }
    ];
    //this.getLaunchData();
    //this.getMasterData();

    
  }

  /* Get Launch Data */
  getLaunchData() {
    // disk issue - when open new tab
    
  // disk issue

    this.dataLoadStatus = true;
    let param = {
      ProjectId: this.projectId,
      locale: this.commonservice.getUserlocaleName()
    }
    this._launchService.getLaunchData(param).subscribe(
      responseData => {
        this.launchManageData = responseData.GetLaunchListResult;
        this.dataLoadStatus = false;
      },
      responseError => {
        if (responseError.status === 200 && responseError.statusText === 'OK' && responseError.name === 'HttpErrorResponse') {
          this.unknownError = true;
          this.dataLoadStatus = false;
        } else {
          this.errorRes = responseError.status + ' : ' + responseError.statusText;
          this.dataLoadStatus = false;
        }
      });
  }

  /* toaster to show message of success and failure */
  showToast(severity, summary, detail) {
    let res= this.translate.instant(summary)
    this.messageService.add({ key: 'tc', severity: severity, summary: res, detail: detail });
  }

  /* Get Selected Data */
  selectData(data) {
    this.selectLaunchData = data;
  }

  /* Get Single Launch Data */
  getSingleData(id) {
    this.resultmessage = ""
    this.resulMsg = false;
    let param = {
      launchId: id,
      locale: this.commonservice.getUserlocaleName()
    }
    this._launchService.getSingleData(param).subscribe(
      responseData => {
        this.displayDialog = true;
        this.launch = responseData.GetLaunchDetailsResult;
        let projecref = this.launch.PROJET_VOMB_FT != null ? [{ key: this.launch.PROJET_VOMB_FT, value: this.launch.PROJET_VOMB_FT }] : [{ key: "", value: "" }]
        let siteref = this.launch.SITE_FT != null ? [{ key: this.launch.SITE_FT, value: this.launch.SITE_FT }] : [{ key: "", value: "" }]
        let altisref = this.launch.INSTANCE_DECISION_FT != null ? [{ key: this.launch.INSTANCE_DECISION_FT, value: this.launch.INSTANCE_DECISION_FT }] : [{ key: "", value: "" }]
        let pmlref = this.launch.INSTANCE_DECISION_ISSUE != null ? [{ key: this.launch.INSTANCE_DECISION_ISSUE, value: this.launch.INSTANCE_DECISION_ISSUE }] : [{ key: "", value: "" }]

        if(this.launch.PLANNING_FILE!=undefined && this.launch.PLANNING_FILE!=null && this.launch.PLANNING_FILE!=""){
          this.isPanningFile=true;}
        else if(this.launch.OBJECTIVE_FILE!=undefined && this.launch.OBJECTIVE_FILE!=null && this.launch.OBJECTIVE_FILE!=""){
            this.isObjectiveFile=true;}
        
        this.editLaunchForm.patchValue({
          id: this.launch.ID,
          NOM: this.launch.NOM,
          PLANNING_FILE: this.launch.PLANNING_FILE,
          OBJECTIVE_FILE: this.launch.OBJECTIVE_FILE,
          PROJET_VOMB_FT: projecref[0],
          SITE_FT: siteref[0],
          USER_CREATION: this.launch.USER_CREATION,
          USER_MAJ: this.launch.USER_MAJ,
          INSTANCE_DECISION_FT: altisref[0],
          INSTANCE_DECISION_ISSUE: pmlref[0]
        });
        if (this.launch.PLANNING_FILE)
          this.isPanningFile = true
        if (this.launch.OBJECTIVE_FILE)
          this.isObjectiveFile = true

        if (this.launch.PROJET_VOMB_FT != null) {
          this.setmanufecturesite(this.launch.PROJET_VOMB_FT)
        }
      },
      responseError => {
        if (responseError.status === 200 && responseError.statusText === 'OK' && responseError.name === 'HttpErrorResponse') {
          this.unknownError = true;
        } else {
          this.errorRes = responseError.status + ' : ' + responseError.statusText;
        }
      }
    );
  }

  get f() { return this.editLaunchForm.controls; }

  /* Edit Launch Data */
    editLaunchData(lauchid) {
    this.headerText = 'view.launch.headeredit'
      this.isPanningFile=false
      this.isObjectiveFile=false
    this.planningvalue=undefined
    this.objectivevalue=undefined;
    this.selectedFiles=null;
    this.selectedFilesObjective=null;
    this.submitted = false;
    this.resultmessage = "";
    this.resulMsg = false;
    this.objectiveMsgFlag=false;
    this.planningMsgFlag=false;
    this.message.message = ""; this.message.filename = ""
    this.editLaunchForm.reset();
    this.iseditModal = true
    this.getSingleData(lauchid);
  }
  /*get master data*/
  getMasterData() {
    let params = { "locale": this.commonservice.getUserlocaleName() }
    this._launchService.getMasterDataListforLaunch(params).subscribe(
      data => {
        data.instancesAltis.forEach(element => {
          let currentobj = { "key": "", "value": "" }
          currentobj.key = element;
          currentobj.value = element;
          this.decAltisList.push(currentobj);
          this.decAltisFilteredList.push(currentobj);
        });
        data.instancesPLM.forEach(element => {
          let currentobj = { "key": "", "value": "" }
          currentobj.key = element;
          currentobj.value = element;
          this.plmlist.push(currentobj);
          this.plmFilterlist.push(currentobj);
        });
        data.projectsAltis.forEach(element => {
          let currentobj = { "key": "", "value": "" }
          currentobj.key = element;
          currentobj.value = element;
          this.projectreflist.push(currentobj);
          this.projectrefFilterlist.push(currentobj);
        });
        this.manufaclist = data.projectSitesMapping
      },
      responseError => {
        if (responseError.status === 200 && responseError.statusText === 'OK' && responseError.name === 'HttpErrorResponse') {
          this.unknownError = true;
        } else {
          this.errorRes = responseError.status + ' : ' + responseError.statusText;
        }
      }
    );
  }

  /* Create Launch Data */
  createLaunchData() {
   this.planningvalue=undefined
    this.objectivevalue=undefined;
    this.displayDialog = true;
    this.selectedFiles=null;
    this.selectedFilesObjective=null;
    this.Listvalue="";
    this.isPanningFile=false
    this.isObjectiveFile=false;
    this.iseditModal = false
    this.submitted = false;
    this.Objectivemessage.message=""; this.Objectivemessage.filenameObjective="";
    this.message.message = ""; this.message.filename = ""
    this.resultmessage = "";
    this.resulMsg = false;
    this.objectiveMsgFlag=false;
    this.planningMsgFlag=false;
    this.headerText = 'view.launch.headernew'
    this.editLaunchForm.reset();
    this.editLaunchForm.controls['INSTANCE_DECISION_FT'].setValue({key:"",value:""})
    this.editLaunchForm.controls['INSTANCE_DECISION_ISSUE'].setValue({key:"",value:""})
  }

  /**change manufecture */
  changeManufecture(obj) {
    let projectstring = ""
    projectstring = this.editLaunchForm.get("PROJET_VOMB_FT").value;
    if (projectstring != "" && projectstring.length > 0) {
      this.filterProjectSite(projectstring);
    }
  }
  /*change event for altis decision group*/
  altisDecisionEvent($event){
    this.editLaunchForm.controls['INSTANCE_DECISION_FT'].setValue({key:"",value:""})
    
  }
  /*change event for plm decision group*/
  plmDecisionEvent($event){
    this.editLaunchForm.controls['INSTANCE_DECISION_ISSUE'].setValue({key:"",value:""})
  }

  /* Submit */
  submitForm() {
    this.submitted = true;
    
    let formdata = this.editLaunchForm.value
    if (!this.editLaunchForm.valid)
      return false;
      else if ((_.isEmpty(formdata.INSTANCE_DECISION_FT.key) && _.isEmpty(formdata.INSTANCE_DECISION_ISSUE.key))) {
        this.resulMsg=true;
        this.resultmessage=this.translate.instant(this.msg);
      }
    else if ((!_.isEmpty(formdata.INSTANCE_DECISION_FT) || !_.isEmpty(formdata.INSTANCE_DECISION_ISSUE))) {
      this.popupLoader = true
      let reqparams = {
        "oSaveLaunchDetails": {
          "ID": formdata.ID != undefined ? formdata.ID : 0,
          "NOM": formdata.NOM,
          "ID_PROJET": this.projectId,
          "USER_CREATION": this.commonservice.getUserID(),
          "USER_MAJ": this.commonservice.getUserID(),
          "PROJET_VOMB_FT": formdata.PROJET_VOMB_FT != null ? formdata.PROJET_VOMB_FT.value : "",
          "SITE_FT": formdata.SITE_FT != null ? formdata.SITE_FT.value : "",
          "INSTANCE_DECISION_FT": formdata.INSTANCE_DECISION_FT != null ? formdata.INSTANCE_DECISION_FT.value : "",
          "INSTANCE_DECISION_ISSUE": formdata.INSTANCE_DECISION_ISSUE != null ? formdata.INSTANCE_DECISION_ISSUE.value : "",
          "CODE_ORIGINE_FT": "",
          
        },
        "type": "",
        "userLocale":this.commonservice.getUserlocaleName()
       
      }
      if (!this.iseditModal)
        reqparams.type = RECORD_TYPE_UPDATE
      else {
        reqparams.type = RECORD_TYPE_SAVE
        reqparams.oSaveLaunchDetails.ID = this.launch.ID
      }
      this._launchService.addLaunch(reqparams).subscribe(data => {
        if (data.SaveLaunchResult.result) {
        
          if(!_.isNil(this.selectedFiles) || !_.isNil(this.selectedFilesObjective)){
          this.uploadFiles(data.SaveLaunchResult.ID)
          this.uploadObjectiveFiles(data.SaveLaunchResult.ID)
          this.getSingleData(data.SaveLaunchResult.ID)
          this.getLaunchData();
          }
          else
          this.getLaunchData();
          this.resulMsg = true;          
          this.resultmessage = data.SaveLaunchResult.Message;
          this.popupLoader=false;
        }
        else {
          this.resulMsg = true;
          this.resultmessage = data.SaveLaunchResult.Message
          this.popupLoader = false  
        }
      }, responseError => {
        this.resulMsg = true;
        this.resultmessage = JSON.stringify(<any>responseError.message),
        this.popupLoader = false
      })  
    }
    else {
      return false
    }}

  /**filter the drop down */
  filterProject(event) {
    this.Listvalue=""
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.projectreflist.length; i++) {
      let pc = this.projectreflist[i];
      if (pc.value.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(pc);
      }
    }
    this.projectrefFilterlist = filtered;  
  }

  /* set manufacturer list*/
  setmanufecturesite(obj) {
    let filtered: any[] = [];
    if (obj != null && obj != undefined && obj.length > 0)
      for (let i = 0; i < this.manufaclist.length; i++) {
        let pc = this.manufaclist[i];
        
        if (pc.Key.toLowerCase()==(obj.toLowerCase())) {
         
          pc.Value.forEach(element => {
            let currentobj = { "key": "", "value": "" }
            currentobj.key = element;
            currentobj.value = element;
            filtered.push(currentobj);
          });
        }
      }
      
    this.manufacFilterlist = filtered;
    this.manutemp = filtered
  }
/*to get the filtered  list for manufacturing site*/
  filterProjectSite(event) {
    let filtered: any[] = [];
    let query = event.query;
    if (event.query != undefined) {
      for (let i = 0; i < this.manutemp.length; i++) {
        let pc = this.manutemp[i];
        if (pc.value.toLowerCase().includes(query.toLowerCase())) {
          filtered.push(pc);
        }
      }
      this.manufacFilterlist = filtered;
    }
    else {
      let obj = this.editLaunchForm.get("PROJET_VOMB_FT").value
      this.setmanufecturesite(obj.key)
      this.manufacFilterlist = this.manufacFilterlist
    }
  }

  /*set Altis decision making froup*/
  filterAltis(event) {
    this.resultmessage=""
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.decAltisList.length; i++) {
      let pc = this.decAltisList[i];
      if (pc.value.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(pc);
      }
    }
    this.decAltisFilteredList = filtered;
  }
  
  /*set PLM decision making froup*/
  filterPLm(event) {
    this.resultmessage=""
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.plmlist.length; i++) {
      let pc = this.plmlist[i];
      if (pc.value.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(pc);
      }
    }
    this.plmFilterlist = filtered;
  }

  /*select the files for planning upload*/
  selectFiles(event) {
    this.resultmessage=""
    this.message.message=""
    this.resulMsg = false;
    this.objectiveMsgFlag=false;
    this.planningMsgFlag=false;
    this.selectedFiles = event.target.files;
    let af = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel']
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.filename = event.target.files[0].name
      if (!_.includes(af, file.type)) {
        this.message.message = 'view.pr.message.validation';
        this.isUloadEnable = true
        this.planningMsgFlag = true;
      }
      else {
        this.message.message = "";
        this.message.filename = "";
        this.isUloadEnable = false
        this.planningMsgFlag = false;
      }
    }
  }

  /*select the files for objective upload*/
  selectObjective(event){
    this.resultmessage=""
    this.Objectivemessage.message=""
    this.resulMsg = false;
    this.objectiveMsgFlag=false;
    this.planningMsgFlag=false;
    this.selectedFilesObjective = event.target.files;
    console.log(this.selectedFilesObjective)
    let af = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel']
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.filenameObjective = event.target.files[0].name
      if (!_.includes(af, file.type)) {
        this.Objectivemessage.message = 'view.pr.message.validation';
        this.objectiveMsgFlag = true;
        this.isUloadEnable = true
      }
      else {
        this.Objectivemessage.message = "";
        this.Objectivemessage.filenameObjective = "";
        this.isUloadEnable = false
        this.objectiveMsgFlag = false;
      }
    }
  }
  /* call to upload for planning*/
  uploadFiles(launchid) {
    this.message.message = ''; this.message.filename = ""
    this.resulMsg = false;
    this.planningMsgFlag=false;
    
    if(!_.isNil(this.selectedFiles)){
    for (let i = 0; i < this.selectedFiles.length; i++) {
      this.upload(launchid, this.selectedFiles[i]);
    }
    }}
/*call to upload for objective*/
  uploadObjectiveFiles(launchid){
    this.Objectivemessage.message = ''; this.Objectivemessage.filenameObjective = ""
    this.resulMsg = false;
    this.objectiveMsgFlag=false;
    if(!_.isNil(this.selectedFilesObjective)){
    for (let i = 0; i < this.selectedFilesObjective.length; i++) {
      this.uploadObjectives(launchid, this.selectedFilesObjective[i]);
    }
    }
  }

  /*File upload call to api for planning*/
  upload(launchid, file) {
    this.popupLoader = true
    let encryptData;
    let filedata: File = file;
    let fileReader: FileReader = new FileReader();
    fileReader.onloadend = (e) => {
      encryptData = fileReader.result;
      let jsonData = JSON.stringify(fileReader.result).replace("data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,", "").replace("data:application/vnd.ms-excel;base64,", "")
      this.reqParams.objectivesPlanningUpload.FileData = JSON.parse(jsonData)
      this.reqParams.objectivesPlanningUpload.FileName = file.name ? file.name : ""
      this.reqParams.objectivesPlanningUpload.LaunchID = launchid
      this.reqParams.objectivesPlanningUpload.UserLocale=this.commonservice.getUserlocaleName()
      this.reqParams.objectivesPlanningUpload.ProjectID = this.projectId
      this.reqParams.objectivesPlanningUpload.UserName = this.commonservice.getUserID()
      this._launchService.uploadFile(this.reqParams).subscribe(
        response => {
          if (response.UploadPlanningResult.ServiceStatus) {
            
            this.filename = 'view.pr.message.static'
            this.isUloadEnable = true
            this.planningMsgFlag=true;
            this.message.message = response.UploadPlanningResult.StatusLog
            this.planningvalue=undefined;
            this.isPanningFile=true;
            this.popupLoader = false;
          }
          else {
            this.popupLoader = false
            this.message.message = response.UploadPlanningResult.StatusLog
            this.message.filename = file.name;
            this.isUloadEnable = false
            this.planningMsgFlag = true; 
          }
        },
        err => {
          this.popupLoader = false
          this.message.message = "view.projecthome.message.uploaderror"
          this.message.filename = file.name;
          this.planningMsgFlag = true;
        });
    }
    fileReader.readAsDataURL(filedata);
  }

  /* call on export button for planning */
  export() {
    this.popupLoader = true
    let req =
    {
      "objectivesPlanningExport":
      {
        "UserName": this.commonservice.getUserID(),
        "UserLocale":this.commonservice.getUserlocaleName(),
        "LaunchID":this.launch.ID
      }
    }
    this._launchService.export(req).subscribe(
      response => {
        if (response.ExportPlanningByLancementResult.ServiceStatus) {
          if(response.ExportPlanningByLancementResult.FileData!=null && response.ExportPlanningByLancementResult.FileName!=null) 
            this.convertToXl(response.ExportPlanningByLancementResult.FileData,response.ExportPlanningByLancementResult.FileName)
            this.popupLoader = false;
            this.filename = 'view.pr.message.static'
            //this.modalService.dismissAll()
            //this.displayDialog = false;
        }
        else {
          this.popupLoader = false
          this.planningMsgFlag = true; 
          this.message.message = response.ExportPlanningByLancementResult.StatusLog
          this.message.filename = ""
          
        }
      },
      err => {
        this.popupLoader = false
        this.message.message = "view.pr.message.exporterror"
        this.message.filename = ""
        this.planningMsgFlag = true;
      });
  }
  /*check file extension */
  checkFileExtension(filename) {
    if (filename != null) {
      let extn = filename.split(".").pop();
      if (extn == FILE_TYPE_XLSX) {
        return true
      }
      else if (extn == FILE_TYPE_XLS) {
        return false
      }
    }
  }

  /* convert base64 string to file  */
  convertToXl(dataURI,filename) {
    let isxlxs=false
     isxlxs=this.checkFileExtension(filename)
    let downloadFiletype= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      int8Array[i] = byteString.charCodeAt(i);
    }
    if(isxlxs)
    downloadFiletype= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      else
      downloadFiletype='application/vnd.ms-excel'
    const blob = new Blob([int8Array], { type: downloadFiletype});    
    saveAs(blob, filename);
 }

/*upload call for api for objectives*/
uploadObjectives(launchid, file){
    let reqParams = {
      "objectivesPlanningUpload":
      {
        "FileName": "",
        "UserName": "",
        "FileData": "",
        "LaunchID":"",
        "ProjectID":"",
        "UserLocale":"",
      }
    }
    this.popupLoader=true
    let encryptData;
    let filedata: File = file;
    let fileReader: FileReader = new FileReader();
    fileReader.onloadend = (e) => {
    encryptData = fileReader.result;
    let jsonData = JSON.stringify(fileReader.result).replace("data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,", "").replace("data:application/vnd.ms-excel;base64,","")
    reqParams.objectivesPlanningUpload.FileData = JSON.parse(jsonData)
    reqParams.objectivesPlanningUpload.FileName = file.name ? file.name : ""
    reqParams.objectivesPlanningUpload.LaunchID = launchid
    reqParams.objectivesPlanningUpload.ProjectID =this.projectId
    reqParams.objectivesPlanningUpload.UserName = this.commonservice.getUserID()
    reqParams.objectivesPlanningUpload.UserLocale=this.commonservice.getUserlocaleName()
         this._launchService.uploadFileObjectives(reqParams).subscribe(
         response => {
          if (response.UploadObjectiveResult.ServiceStatus) {
           
            this.objectiveMsgFlag=true;
            this.Objectivemessage.message = response.UploadObjectiveResult.StatusLog
            this.filenameObjective = 'view.pr.message.static'
            this.objectivevalue=undefined;
            this.isUloadEnable = true
            this.isObjectiveFile=true;
            this.popupLoader = false;
            }
          else{
            this.popupLoader=false
            this.Objectivemessage.message = response.UploadObjectiveResult.StatusLog
            this.Objectivemessage.filenameObjective=file.name;
            this.isUloadEnable=false;
            this.objectiveMsgFlag = true;
          }
        },
        err => {
          this.popupLoader=false
          this.Objectivemessage.message = "view.projecthome.message.uploaderror" 
            this.Objectivemessage.filenameObjective=file.name;
            this.objectiveMsgFlag = true;
        });
    }
    fileReader.readAsDataURL(filedata);
  }

  /* call on export button for objective */
  exportObjectives(){
    this.popupLoader=true
    let req =
    {
      "objectivesPlanningExport":
     {
        "UserName":this.commonservice.getUserID(),
        "UserLocale":this.commonservice.getUserlocaleName(),
        "LaunchID":this.launch.ID
     }
    }
    this._launchService.exportObjective(req).subscribe(
      response => {
        if (response.ExportObjectiveByLancementResult.ServiceStatus) {
          
          if(response.ExportObjectiveByLancementResult.FileData!=null && response.ExportObjectiveByLancementResult.FileName!=null){
          this.convertToXl(response.ExportObjectiveByLancementResult.FileData,response.ExportObjectiveByLancementResult.FileName)
            this.popupLoader=false;
            this.filenameObjective = 'view.pr.message.static'
            //this.modalService.dismissAll()
            //this.displayDialog = false;
        }}
        else{
          this.popupLoader=false
          this.Objectivemessage.message=response.ExportObjectiveByLancementResult.StatusLog
          this.Objectivemessage.filenameObjective=""
          this.objectiveMsgFlag= true;
        }
      },
      err => {
        this.popupLoader=false
        this.Objectivemessage.message="view.pr.message.exporterror"
        this.Objectivemessage.filenameObjective=""
        this.objectiveMsgFlag = true;
      });
  }

/* delete for planning uploaded file*/
  deletePlanningFile(){
    this.popupLoader=true
    let reqParams={
      "launchID":this.launch.ID,
      "projectID":this.projectId,
      "userLocale":this.commonservice.getUserlocaleName()
    }
    this.confirmService.confirm({
      message: this.translate.instant(this.deletemsg),
      header: this.translate.instant(this.headerMsg),
      icon: 'pi pi-exclamation-triangle',
      acceptLabel:this.translate.instant(this.acceptMsg),
      rejectLabel:this.translate.instant(this.rejectMsg),
      accept: () =>{
       this._launchService.deletePlanningByLaunchID(reqParams).subscribe(
       response=>{
      if(response.DeletePlanningByLaunchIDResult.result){
        this.planningMsgFlag=true;
        this.message.message=response.DeletePlanningByLaunchIDResult.Message;
        this.isPanningFile=false;
        this.popupLoader=false;
      }
     else
     this.planningMsgFlag=true;
     this.message.message=response.DeletePlanningByLaunchIDResult.Message;
     this.popupLoader=false
    }
    );
  },
  reject: () => {
    this.popupLoader=false;
}
});
  }

  /* delete for objective uploaded file*/
  deleteObjectiveFile(){
    this.popupLoader=true;
    let reqParams={
      "launchID":this.launch.ID,
      "projectID":this.projectId,
      "userLocale":this.commonservice.getUserlocaleName()
    }
    this.confirmService.confirm({
      message: this.translate.instant(this.deletemsg),
      header: this.translate.instant(this.headerMsg),
      icon: 'pi pi-exclamation-triangle',
      acceptLabel:this.translate.instant(this.acceptMsg),
      rejectLabel:this.translate.instant(this.rejectMsg),
      accept: () =>{
        this._launchService.deleteObjectiveByLaunchID(reqParams).subscribe(
    response=>{
      if(response.DeleteObjectiveByLaunchIDResult.result){
        this.objectiveMsgFlag=true;
        this.Objectivemessage.message=response.DeleteObjectiveByLaunchIDResult.Message;
        this.isObjectiveFile=false;
        this.popupLoader=false;
      }
     else
     this.objectiveMsgFlag=true;
     this.Objectivemessage.message=response.DeleteObjectiveByLaunchIDResult.Message;
     this.popupLoader=false;
    }
    ); 
  },
  reject: () => {
    this.popupLoader=false;
}
});
  }
cancel(){
  //this.modalService.dismissAll();
  this.displayDialog = false;
  this.message.message=""
  this.Objectivemessage.message=""
  this.message.filename=""
  this.Objectivemessage.filenameObjective=""
  this.filenameObjective='view.pr.message.static'
  this.filename='view.pr.message.static'
  this.resultmessage=""
  this.isPanningFile=false;
  this.isObjectiveFile=false;
  this.resulMsg = false;
  this.objectiveMsgFlag=false; 
  this.planningMsgFlag=false;
}

ngOnDestroy() {
  this.unsubscribe$.next(true);
  this.unsubscribe$.complete();
}
}


