import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LaunchComponent } from './launch/launch.component';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { MeasureListComponent } from './measure-list/measure-list.component';
import { ProjcetHomeComponent } from './projcet-home/projcet-home.component';
import { CodificationSeaComponent } from './codification-sea/codification-sea.component';
import { CodificationETSComponent } from './codification-ets/codification-ets.component';
import { UploadExportComponent } from './upload-export/upload-export.component';
import { MailRecipientsComponent } from './mail-recipients/mail-recipients.component';
import { TechnicaleventsListComponent } from '../technicalevents/technicalevents-list/technicalevents-list.component';
import { Role } from 'src/app/shared/model/role';
import { LeaveGuard } from './beforeunload/leave.guard';
import { VehicleDetailsComponent } from './vehicle-details/vehicle-details.component';

const routes: Routes = [
  {path: '',canActivate:[AuthGuard],data: { breadcrumb: null },
  component: ProjcetHomeComponent 
}
,{path:'launch',data: { breadcrumb: 'Launch',traskey:'Launch',isProjectPage:true,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ]},canActivate:[AuthGuard],component:LaunchComponent},
{ path: 'measure',loadChildren: () => import('./.././project-home/measure-list/measure-list/measure-list.module').then(m => m.MeasureListModule), data: { breadcrumb: 'Measure choice',traskey:'Measure choice',isProjectPage:true,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ]} },
{path:'feattech',data: { breadcrumb: "Project's technical events list",traskey:"Project's technical events list",isProjectPage:true,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ]},canActivate:[AuthGuard],canDeactivate:[LeaveGuard],component:TechnicaleventsListComponent},
{path:'upload', data:{ breadcrumb: 'Upload and Export',traskey:'Upload and Export',isProjectPage:true,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ]},canActivate:[AuthGuard],component:UploadExportComponent},
{path:'vehicles',data:{ breadcrumb: 'Vehicle Management',traskey:'Vehicle Management',isProjectPage:true,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ]},canActivate:[AuthGuard],component:VehicleDetailsComponent},
{path:'codification-ets',canActivate:[AuthGuard],component:CodificationETSComponent},
{path:'mailrecipients',data:{breadcrumb:'Mail Recipients',traskey:'Mail Recipients',isProjectPage:true,roles: [ Role.GlobalAdmin,Role.ExpertPilot,Role.Pilot ]},component:MailRecipientsComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectHomeRoutingModule { }
