import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TechnicaleventsListComponent } from './technicalevents-list/technicalevents-list.component';
import * as _ from 'node_modules/lodash';
import { TranslateService } from '@ngx-translate/core';
import { LeaveGuard } from '../project-home/beforeunload/leave.guard';


const routes: Routes = [
  {
      path: '',
      component: TechnicaleventsListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TechnicaleventsRoutingModule { }
