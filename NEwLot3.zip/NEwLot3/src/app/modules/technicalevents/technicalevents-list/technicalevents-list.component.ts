import { Component, OnInit ,AfterViewInit, ElementRef, ViewChild} from '@angular/core';
import { TechnicaleventsService } from 'src/app/service/technicalevents.service';
import * as _ from 'node_modules/lodash';
import { TranslateService } from '@ngx-translate/core';
import {CommonService} from 'src/app/service/common.service';
import { config } from 'src/app/shared/config/config';
import LocalStorage from '../../../util/local-storage';
import { FormGroup, FormBuilder,Validators,FormControl } from '@angular/forms';
import { CodificationSeaService } from 'src/app/service/codification-sea.service';
import { HeaderChangeService } from 'src/app/service/header-change.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { ProjectService } from 'src/app/service/project.service';
@Component({
  selector: 'app-technicalevents-list',
  templateUrl: './technicalevents-list.component.html',
  styleUrls: ['./technicalevents-list.component.scss']
})


export class TechnicaleventsListComponent implements OnInit {
  // @ViewChild('myDiv') myDiv: ElementRef;
  lauchId=""
  infoModalBody: string = ""; activeIndex: number = 0; InfoModal:boolean=false
  techeventsList={
    "records": [],
    "pagination": null
   }
  selectedPiece: any;
  filteredpiecesList: any[];
  piecesList: any[]=[];
  pageIndex:number=1
  altisLink:string="";
  PLMLink:string ="";
  searchFilter:string="";
  statutsAltis:any;
  selectedAltisStatus: any[];
  selectedLancment:any[];
  selectedDecison:any[]
  errorMessage:string;
  FTSize = 10;
  techFacts = [];
  pageNumber = 1;
  techList:any=[];
  tagList: any[] = [];
  tagFilteredList: any[] = [];
  techFactsForm:FormGroup;
  techFactsDetail:any=[];  techFactsDetailCopy:any=[]
  projectParameters:any;
  sortObj = {
    currentColumn: 'metier',
    previousColumn: 'metier',
    order: 'ASC'
  };
  techdata:any;
  instsDecis:any;
  details= [];
  lacements:any;
  unsubscribe$: Subject<boolean> = new Subject();
  dataUserLang = "";
  searchProductPattern:string=""; 
  scrollDistance = 1;
  scrollUpDistance = 2;
  enableLoader=false
  projectid:any
  selectedtextMetier=""; selectedIssue=""; selectedlancement:any[]=[];selectedinstanceDec=[];selectedAltis=[];
  filter = { "currentText": "", "textMetier": "", "text": "", "metierText": "", "lancement": [], "instanceDec": [], "stade": [], "statutAltis": [] };
  constructor(
    private techservice :TechnicaleventsService,private headerChangeService:HeaderChangeService,
    private translate:TranslateService,
    private commonservice :CommonService,
    private fb : FormBuilder,
    private codSeaservice: CodificationSeaService,
    private route:ActivatedRoute,
    private projectservice:ProjectService
  ) {
  }

  ngOnInit() {
    
    // disk issue - when open new tab
    const projectId = this.route.snapshot.paramMap.get('id');
    this.commonservice.setProjectId(projectId);
    this.projectid= this.commonservice.getProjectId()
    this.projectservice.getprojectDetailById(this.projectid).subscribe((data: any) => {      
      this.commonservice.setProjectName(data.URL_SITE)
      this.commonservice.setProjectLocale(data.LOCALE)
    })
  // disk issue
    this.headerChangeService.getlanguageProfileObs().pipe(takeUntil(this.unsubscribe$)).subscribe(language => 
      {let selectedlanguage = language
      if(selectedlanguage!=null && selectedlanguage!="" && selectedlanguage!=undefined)
      this.techeventsList.records=[];this.techeventsList.pagination="";
      this.setIntialCalls();
      this.dataUserLang=this.commonservice.getUserlocaleName();
      
    });
    this.setIntialCalls();
    this.dataUserLang=this.commonservice.getUserlocaleName();
    this.headerChangeService.changeLeftpanel(true)
    this.commonservice.setChangedCod(true)
   
  }
/**
 * api calls 
 */
  setIntialCalls(){
    this.getTechnicalEvents();
    this.getProjectParameters();
    this.getAltisFilter();
    this.getDecisionMakingFilter();
    this.getLancmentFilter();
    this.getTags();
  }
/**
 * get the intial records
 */
getTechnicalEvents(){
  this.enableLoader = true
    let reqParams={
    locale :this.commonservice.getUserlocaleName(),
    pageSize:config.pageSize,
    pageNumber: this.pageIndex,
    projectId : this.projectid
    }

this.techservice.getRecords(reqParams).subscribe(  
      (data: any) => {
        this.enableLoader=false
    let techList = data.data;
      let resresult=[];
      // NE28061-62 fixed issue
      techList.forEach(element=>{
        let ft={
        "id": element.ID,
        "idFTAltis": element.IDENTIFIANT_FT_ALTIS!="0" ? element.IDENTIFIANT_FT_ALTIS:element.IDENTIFIANT_ISSUE.toString(),
        "idPLMIssue": element.IDENTIFIANT_ISSUE!=null?element.IDENTIFIANT_ISSUE:"",
        "idIssue": element.ID_ISSUE!=null?element.ID_ISSUE:"",
        "isdetailtableselected":false,
        "defectisInputModified":false,
        "title": element.LIBELLE_FT_TITAN!=null?element.LIBELLE_FT_TITAN:"",
        "launchName": element.NOM_LANCEMENT!=null?element.NOM_LANCEMENT:"",
        "launchId": element.ID_LANCEMENT_TITAN!=null ?element.ID_LANCEMENT_TITAN:"",
        "metier": element.METIER_POUR_ACTION !=null ? element.METIER_POUR_ACTION:"",
        "instDecision": element.INSTANCE_DECISION_FT,
        "stateProgress": element.LIBELLE_ETAT_AVANCEMENT_FT,
        "dessignation": element.DESIGNATION_PIECE !=null?element.DESIGNATION_PIECE:"",
        "tags": element.TAGS,
        "filterableText": (!element.IDENTIFIANT_FT_ALTIS ? "" : element.IDENTIFIANT_FT_ALTIS) +
            (!element.IDENTIFIANT_ISSUE ? "" : element.IDENTIFIANT_ISSUE) +
            (!element.LIBELLE_FT_TITAN ? "" : element.LIBELLE_FT_TITAN) +
            (!element.METIER_POUR_ACTION ? "" : element.METIER_POUR_ACTION) +
            (!element.LIBELLE_ETAT_AVANCEMENT_FT ? "" : element.LIBELLE_ETAT_AVANCEMENT_FT) +
            (!element.DESIGNATION_PIECE ? "" : element.DESIGNATION_PIECE) +
            element.TAGS.toString()
      }
      resresult.push(ft)
      })
      this.techeventsList.pagination = data.pagination;
      // NE28061-62 fixed issue
      this.techeventsList.records = resresult; 
      
      
      this.enableLoader=false
     
    },
    err=> {
      this.enableLoader=false
      
  }
    
  );
}

/**
 * get project params
 */
getProjectParameters(){
  this.commonservice.getParameters().subscribe(  
    (data: any) => {
    this.projectParameters =data;
    LocalStorage.addItem("PROJECT_PARAMETRS", data); 
 
  },
  (error: any) => this.errorMessage = <any>error
);
 }
 /**
  * api call to get the altis state filter
  */
getAltisFilter()
{
  let req={locale:this.commonservice.getUserlocaleName(),projectid: this.projectid}
  this.techservice.geAltisFilter(req).subscribe(  
    (data: any) => {
    this.statutsAltis =data.GetStatutsAltisResult;
  },
  (error: any) => this.errorMessage = <any>error);

}
/**
 * api call to get launch filter
 */
getLancmentFilter()
{
  let req={locale:this.commonservice.getUserlocaleName(),projectid: this.projectid}
  this.techservice.getLanchFilter(req).subscribe(  
    (data: any) => {
    this.lacements =data.GetLancementsResult;
  
  },
  (error: any) => this.errorMessage = <any>error);

}
/***
 * api call to get decision making filter
 */
getDecisionMakingFilter()
{
  let req={locale:this.commonservice.getUserlocaleName(),projectid: this.projectid}
  this.techservice.geDecisionMakingFilter(req).subscribe(  
    (data: any) => {
    this.instsDecis =data;
  
  },
  (error: any) => this.errorMessage = <any>error);

}
/**
 * called on every change in detail section to set the modified class true
 * @param id 
 */
changeDetailInput(id) {
 
   let changed=false
   let filteredData = _.filter(
     this.techeventsList.records, function (item) {
       if (item.id == id) {
         item.defectisInputModified = true
        changed=true
       }
     });
    
     this.commonservice.setChangedCod(false)
   
 }
 /***
  * called on discart button
  */
 discardChanges(id){
  
  this.commonservice.setChangedCod(true)
  
    let filteredData = _.filter(
      this.techeventsList.records, function (item) {
        if (item.id == id) {
          item.defectisInputModified = false
        }
      });
      console.log("before",this.techFactsDetail[id])
     let pieceInfo=this.techFactsDetail[id].pieceInfo
      this.techFactsDetail[id]= JSON.parse(this.techFactsDetailCopy[id])
      this.techFactsDetail[id].pieceInfo=pieceInfo
      this.techFactsDetail[id].tradeForActionID="-1"
      
      
        console.log("discard changes",this.techFactsDetail[id])
 
}
/**
 * called to do do sorting
 * @param prop 
 * @param evt 
 */
sortFTs (prop, evt) {
  this.FTSize = 10;
  let asc=false;
  this.sortObj.currentColumn = prop;
  this.sortObj.order = this.sortObj.order == "DESC" ? 'ASC' : 'DESC';
    if (this.sortObj.currentColumn != this.sortObj.previousColumn) {
      this.sortObj.previousColumn=this.sortObj.currentColumn 
    } 
    if(this.sortObj.order == 'ASC')
    {asc=true}
    else
    {asc=false};
  
  this.techeventsList.records = this.techeventsList.records.sort(function(a, b) {
      if (asc) return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
      else return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
  });
  return false;
}
 

getValues(event)
  {
    if(event.isUserInput && event.source._selected)
    {
       
       this.selectedlancement.push(event.source.value);
    }
    else{
      this.selectedlancement = _.remove(this.selectedlancement, function(n) {
        return n != event.source.value;
      });
 
    }
  }
  /**
   * called on clear filter button
   */
clearFilters()
{
  this.selectedtextMetier=""
this.selectedIssue=""
this.selectedLancment=[]
this.selectedlancement=[]
this.selectedinstanceDec=[]
this.selectedDecison=[]
this.selectedAltis=[]
}

/**
 * function is called when user click on detail button of any row
 * @param itemId 
 * @param open 
 */
toggleDefectDetails(itemId, open) {
 
  this.enableLoader=true
 
   this.refreshFT(itemId,false,true)
  

}

   /**
    * on scroll event of lazy loader
    */
   onScroll() {
    
    if (!this.enableLoader ) {
      if(this.techeventsList.pagination.nextPage>0){
      this.pageIndex += 1;
      this.getTechnicalEvents();}
    }
  }
  /**
   * api call to get tag list
   */
  getTags() {
   
    let reqparams = {
      projectId: this.projectid,
      loacle: this.commonservice.getUserlocaleName()
    }
    this.codSeaservice.getTags(reqparams).subscribe(
      (data: any) => {
        this.tagList=[]
        data.GetAllTNTQTB3EntitysResult.forEach(element => {
          let currenttag = { "key": "", "value": "" }
          currenttag.key = element.ID_TAG;
          currenttag.value = element.TAG;
          this.tagList.push(currenttag);
          this.tagFilteredList.push(currenttag);
        });

      },
      (error: any) => this.errorMessage = <any>error
    );
  }
  filterTags(event, id) {
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.tagList.length; i++) {
      let pc = this.tagList[i];
      if (pc.value.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(pc);
      }
    }

    this.tagFilteredList = filtered;
  }
  /**
   * called when user click on altis number
   * @param idAltis 
   */
  // issue fixed NE28061-51 
 getAltisLink(idAltis) {
  if (idAltis != undefined && idAltis != "") {
      if (!!this.projectParameters) {
        let obj=  this.projectParameters.filter(x=>x.Key=="altis_link")
        if(obj){
       
          this.altisLink = obj[0].Value;
          this.altisLink = this.altisLink.replace("[QTA0_IDENTIFIANT_FT]", idAltis);
          window.open(
            this.altisLink ,
            '_blank' 
          );
        }
      
       }
  }
  }
  /**
   * called when user click on plm number
   * @param idPLMIssue
   */
  // issue fixed NE28061-51 
 getPLMLink (idPLMIssue) {
    let PLMLink = "";
    if (idPLMIssue != undefined && idPLMIssue != "") {
        if (!!this.projectParameters) {
          let obj=  this.projectParameters.filter(x=>x.Key=="PLM_link")
          if(obj){
            
            this.PLMLink = obj[0].Value;
            PLMLink = this.PLMLink.replace("[QTA0_ID_ISSUE]", idPLMIssue);
            window.open(
              PLMLink,
              '_blank' )
           
            }
    }
}
}
/**
 * method is called to refersh the detail data ft
 * @param id 
 * @param force 
 * @param showdetail 
 */
  refreshFT(id,force,showdetailnbr) {
    
    this.enableLoader=true
    let index = 0;
    let ft = null;
    let isDetailloaded=false;
    this.techeventsList.records.forEach((element, counter) => {
      if (element.id == id) {
        element.isdetailtableselected = !element.isdetailtableselected;
        index = counter;
        ft = element;
       // if (!element.isdetailtableselected)
          return false;
     
      }
    });
   
    let dataProjectLang= _.find(this.projectParameters, function(o) { return o.Key == 'LCID'; })
    
        if (dataProjectLang) {
          let reqparams={
            "UserLocale":this.commonservice.getUserlocaleName(),
            "id":id,
            "ProjectId": this.projectid

          }
          this.techservice.getTechFactInfo(reqparams).subscribe(  
            (data: any) => {
            //
            
              let item = data.GetFTInfoResult;
       let tagsArray = [];
       let tagItem = [];
       if (!!item.TAGS) {
         item.TAGS.forEach(element => {
           let obj = _.filter(this.tagList, function (obj, index) {
             if (obj.value.toLowerCase().trim() == element.toLowerCase().trim()) {
               tagsArray.push(obj);
             }
           });
         });
       }
       let solutionsArray = [];
       if (!!item.Solutions) {
         item.Solutions.forEach(val => {
          let solutionItem = {};
          let number = val.IDENTIFIANT_SOLUTION ? val.IDENTIFIANT_SOLUTION : val.ECRNAME;
          solutionItem["number"] = number;
          solutionItem["solutionType"] = val.LIBELLE_TYPE_SOLUTION ? val.LIBELLE_TYPE_SOLUTION : val.TYPE_SOLUTION;
          solutionItem["name"] = val.LIBELLE;
          solutionItem["status"] = val.LIBELLE_ETAT ? val.LIBELLE_ETAT : val.ETAT;
          solutionItem["datePrevi"] = (!val.DATE_PREVI_APPLIQUE_SOL ? "" : new Date(parseInt(val.DATE_PREVI_APPLIQUE_SOL.substr(6))));
          solutionItem["dateReele"] = (!val.DATE_REELLE_APPLIQUE_SOL ? "" : new Date(parseInt(val.DATE_REELLE_APPLIQUE_SOL.substr(6))));
          solutionItem["efficiencyDG"] = val.LIBELLE_EFFICACITE_DG ? val.LIBELLE_EFFICACITE_DG : val.CODE_EFFICACITE_DG;
          solutionItem["efficiencyPoint"] = val.LIBELLE_EFFICACITE_PT ? val.LIBELLE_EFFICACITE_PT : val.CODE_EFFICACITE_PT;
          solutionItem["pelletizing"] = val.PASTILLAGE;
          solutionsArray.push(solutionItem);
         });
          
       }

       let relatedFTsArray = [];
       if (!!item.FTs) {
         item.FTs.forEach(element => {
          let currentFT = {
            "id": element.IDENTIFIANT_FT_ALTIS,
            "title": element.LIBELLE,
            "description": element.DESCR_DETAIL_FT,
            "defectsNumber": element.NB_DEFAUTS,
            "tradeForAction": element.METIER_POUR_ACTION,
            "stateProgressCode": element.CODE_ETAT_AVANCEMENT_FT,
            "stateProgress": element.ETAT_AVANCEMENT_FT,
            "local": element.LOCALE,
            "detectedLocationCode": element.CODE_LOCALISATION_DETECTE,
            "idProject": element.ID_PROJET,
            "severity": element.GRAV_EFFET_CLIENT
          };
          relatedFTsArray.push(currentFT);
         });
        }
        let ftdata=this.parseFT(item, tagsArray, solutionsArray, relatedFTsArray);
        if (force) {
          for (let attrname in ftdata.basic) {
              this.techeventsList.records[showdetailnbr][attrname] = ftdata.basic[attrname];
          }
        }
        this.techFactsDetail[id]=ftdata.detail;
        this.techFactsDetailCopy[id]=_.cloneDeep(JSON.stringify(ftdata.detail));
          this.lauchId=ft.launchId
        

        if (this.piecesList.length==0) {
          if (this.dataUserLang) {
            let eq = { ftId: "", langId: "" }
            eq.ftId = this.lauchId;
            eq.langId = this.dataUserLang;
            this.getPieces(eq)
            this.enableLoader = false;
            this.configurePiecesInput(ft.id)
          }
        } else {
          this.configurePiecesInput(ft.id)
          this.enableLoader = false
        }
        this.enableLoader=false
       
        
          },
          err=> {
            this.enableLoader=false
            this.showModalInfo("ERROR: " + JSON.stringify(err),"","");
        });
         
        }

}
/**
 * api call to get pieces list
 * @param id 
 */
  getPieces(id){

    let requestParam = {
      langId: this.commonservice.getUserlocaleName(),
      ftId:  this.projectid,
    }

    this.codSeaservice.getpiecesFilter(requestParam).subscribe(
      (data: any) => {
        data.GetPiecesResult.forEach(element => {
          let currentPiece = { "key": "", "value": "" }
          currentPiece.key = element.Key;
          currentPiece.value = element.Value;
          this.piecesList.push(currentPiece);
        });
        this.filteredpiecesList = this.piecesList;
      },
      (error: any) => this.errorMessage = JSON.stringify(error)
    );
  }

 /**
  * called when user change the piece ssearch
  * @param defectObject 
  * @param forceAssociatedData 
  */
    changePiece(defectObject, forceAssociatedData) {
    if (defectObject.workpieceChoiceData != null && defectObject.workpieceChoiceData != undefined) {
      if (defectObject.workpieceChoiceData.key != "" && defectObject.workpieceChoiceData.key != null) {
        defectObject.workpieceChoiceID = defectObject.workpieceChoiceData.key
        let reqparms = {
          locale: this.dataUserLang,
          launchid: this.lauchId,
          choiceId: defectObject.workpieceChoiceData.key
        }
        this.codSeaservice.getPieceAssociatedInfo(reqparms).subscribe(
          (data: any) => {
            let result = data;
            let pieceInfo = [];
            result.forEach(element => {

              let currentPiece = {
                "ID": element.ID,
                "CODE_DECOUPAGE_PSA": element.CODE_DECOUPAGE_PSA,
                "COFOR": element.COFOR,
                "lot": element.METIER_POUR_ACTION_NIV_3,
                "businessDriverName": element.PILOTE,
                "businessDriverDisplayName": element.PILOTE_DISPLAY,
                "tradeForAction": element.METIER_POUR_ACTION_NIV_1 + " - " + element.METIER_POUR_ACTION_NIV_2,
                "altistePlm": element.ALTISTE_PLM

              };

              let AlreadyExists = _.filter(pieceInfo, function (element, index) {
                return element.CODE_DECOUPAGE_PSA == currentPiece.CODE_DECOUPAGE_PSA &&
                  element.COFOR == currentPiece.COFOR &&
                  element.lot == currentPiece.lot &&
                  element.businessDriverName == currentPiece.businessDriverName &&
                  element.businessDriverDisplayName == currentPiece.businessDriverDisplayName &&
                  element.tradeForAction == currentPiece.tradeForAction;
              });
              //We only can add pieceInfo if it doesn´t exist [SPT-2473]
              if (AlreadyExists == null || AlreadyExists.length == 0)
                pieceInfo.push(currentPiece);
            });

            defectObject.pieceInfo = pieceInfo;
            if(!_.isNil(this.techFactsDetailCopy[defectObject.id])){
              JSON.parse(this.techFactsDetailCopy[defectObject.id]).pieceInfo=JSON.stringify(pieceInfo);
            }
            let existsStoredPiece = _.filter(defectObject.pieceInfo, function (p) {
              return p.tradeForAction + p.lot == defectObject.tradeForAction + defectObject.lot;
            })
            if (!!defectObject.workpieceChoiceID && existsStoredPiece.length == 0) {
              let storedPiece = {
                "ID": -1,
                "COFOR": defectObject.COFOR,
                "lot": defectObject.lot,
                "businessDriverName": defectObject.businessDriverName,
                "businessDriverDisplayName": defectObject.businessDriverDisplayName,
                "tradeForAction": defectObject.tradeForAction,
              };
              pieceInfo.push(storedPiece);
            }

            if (defectObject.pieceInfo.length > 0) {
              if (!!forceAssociatedData) {
                let defaultPieceInfo = _.filter(pieceInfo, function (p) {
                  return defectObject.workpieceChoiceID == p.ID;
                });
                if (defaultPieceInfo.length > 0) {
                  defectObject.tradeForAction = defaultPieceInfo[0].tradeForAction;
                  defectObject.tradeForActionID = defaultPieceInfo[0].ID;
                  defectObject.lot = defaultPieceInfo[0].lot;
                  if(!_.isNil(this.techFactsDetailCopy[defectObject.id])){
                    JSON.parse(this.techFactsDetailCopy[defectObject.id]).tradeForAction=JSON.stringify(defaultPieceInfo[0].tradeForAction);
                    JSON.parse(this.techFactsDetailCopy[defectObject.id]).tradeForActionID=JSON.stringify(defaultPieceInfo[0].ID);
                   // this.techFactsDetailCopy[id]=_.cloneDeep(JSON.stringify(ftdata.detail));
                    
                  }
                 
                }
              } else {
                if (existsStoredPiece.length == 0) {
                  defectObject.tradeForActionID = -1;
                  if(!_.isNil(this.techFactsDetailCopy[defectObject.id]))
                  JSON.parse(this.techFactsDetailCopy[defectObject.id]).tradeForActionID=-1;
                } else {
                  defectObject.tradeForActionID = existsStoredPiece[0].ID;
                  if(!_.isNil(this.techFactsDetailCopy[defectObject.id]))
                  JSON.parse(this.techFactsDetailCopy[defectObject.id]).tradeForActionID=JSON.stringify(existsStoredPiece[0].ID);
                }
              }
             
            }
         
          });
      }
    }
  }
  /**
   * internal method called to set workpiece choice
   * @param id 
   */
  configurePiecesInput( id) {
    let pieceNameByIDArray = []
    let workvalue = this.techFactsDetail[id].workpieceChoiceID
    if (workvalue != "" && workvalue != null) {
      pieceNameByIDArray = _.filter(this.piecesList, function (item) {
        return item.key == workvalue;
      });
    }
    if (pieceNameByIDArray.length > 0) {
      this.techFactsDetail[id].workpieceChoice = pieceNameByIDArray[0].value;
      this.techFactsDetail[id].workpieceChoiceData = { key: pieceNameByIDArray[0].key, value: pieceNameByIDArray[0].value }
      if(!_.isNil(this.techFactsDetailCopy[id])){
        JSON.parse(this.techFactsDetailCopy[id]).workpieceChoice=JSON.stringify(pieceNameByIDArray[0].value);
        JSON.parse(this.techFactsDetailCopy[id]).workpieceChoiceData=JSON.stringify({ key: pieceNameByIDArray[0].key, value: pieceNameByIDArray[0].value });
     
        
      }
    }

   
  this.changePiece(this.techFactsDetail[id], false);
    
    

  }
  /**
 * Onchange of auto complete pieces field
   * Author:Shweta
   * Created date:23 march 2021
   * @param event 
   * @param id 
   */
  filterPieces(event, id) {

    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.piecesList.length; i++) {
      let pc = this.piecesList[i];

      if (pc.value.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(pc);
      }
    }

    this.filteredpiecesList = filtered;
  }

 
/**
   * Onchange event on dropdown
   * Author:Shweta
   * Created date:23 march 2021
   * @param defectObject coded
   */
 
  changeMetier(defectObject, coded) {
    let associatedMetierInfo = _.filter(defectObject.pieceInfo, function (p) {
      return p.ID == defectObject.tradeForActionID;
    })
    if (associatedMetierInfo.length > 0) {
      defectObject.lot = associatedMetierInfo[0].lot;
      if (!coded) {
        defectObject.businessDriverName = associatedMetierInfo[0].businessDriverName;
        defectObject.businessDriverDisplayName = associatedMetierInfo[0].businessDriverDisplayName;
        if(!_.isNil(this.techFactsDetailCopy[defectObject.id])){
          JSON.parse(this.techFactsDetailCopy[defectObject.id]).businessDriverName=JSON.stringify(associatedMetierInfo[0].businessDriverName);
          JSON.parse(this.techFactsDetailCopy[defectObject.id]).businessDriverDisplayName=JSON.stringify(associatedMetierInfo[0].businessDriverDisplayName);
      }
    }
      defectObject.tradeForAction = associatedMetierInfo[0].tradeForAction;
      if(!_.isNil(this.techFactsDetailCopy[defectObject.id])){
        JSON.parse(this.techFactsDetailCopy[defectObject.id]).businessDriverName=JSON.stringify(associatedMetierInfo[0].businessDriverName);
    }}
  }

/**
   * function parse the data of ft detail
   * Author:Shweta
   * Created date:23 march 2021
   * @param FTObject 
   */

  parseFT (item, tagsArray, solutionsArray, relatedFTsArray) {
    let  nBrutLink = "";
    //NEO
    //SPA 
    //FIC 
    let ORIGINE_DEFAUT = item.ORIGINE_DEFAUT != null ? item.ORIGINE_DEFAUT.trim() : "";
    let projectParameters= LocalStorage.getItem("PROJECT_PARAMETRS");
    if (ORIGINE_DEFAUT === "SPA") {
      let sparteproject= _.find(projectParameters, function(o) { return o.Key == 'sparte_link'; })
     
        if (sparteproject != null && sparteproject != undefined) {
            nBrutLink = sparteproject.Value;
            nBrutLink = nBrutLink.replace("[NUMERO_DEFAUT_BRUT]", item.NUMERO_DEFAUT_BRUT);
        }


    }
    if (item.ORIGINE_DEFAUT === "NEO") {
      let neoproject= _.find(projectParameters, function(o) { return o.Key == 'neo_link'; })
        if (neoproject != undefined && neoproject != null) {
            nBrutLink = neoproject.Value;
            nBrutLink = nBrutLink.replace("[LIB_SIT]", item.LIB_SIT);
            nBrutLink = nBrutLink.replace("[NOF]", item.NOF);
            nBrutLink = nBrutLink.replace("[BDG]", item.BDG);
            nBrutLink = nBrutLink.replace("[VIS]", item.VIS);
        }
    }

    let altisLink = "";

    if (item.QTA0_IDENTIFIANT_FT_ALTIS != undefined && item.QTA0_IDENTIFIANT_FT_ALTIS != "") {
      let altisproject= _.find(projectParameters, function(o) { return o.Key == 'altis_link'; })
        if (altisproject != null && altisproject != undefined) {
            altisLink = altisproject.Value;
            altisLink = altisLink.replace("[QTA0_IDENTIFIANT_FT]", item.QTA0_IDENTIFIANT_FT_ALTIS);
        }
    }

    let PLMLink = "";
    if (item.QTA0_ID_ISSUE != undefined && item.QTA0_ID_ISSUE != "") {
      let plmLink= _.find(projectParameters, function(o) { return o.Key == 'PLM_link'; })
        if (plmLink != null && plmLink != undefined) {
            PLMLink = plmLink.Value;
            PLMLink = PLMLink.replace("[QTA0_ID_ISSUE]", item.QTA0_ID_ISSUE);
        }
    }
    let LinklistFT = "";
    let linkedListft= _.find(projectParameters, function(o) { return o.Key == 'LinklistFT'; })
    if (item.QTA0_IDENTIFIANT_FT_ALTIS != undefined && item.QTA0_IDENTIFIANT_FT_ALTIS != "") {
        if (linkedListft != null && linkedListft != undefined) {
            LinklistFT = linkedListft.Value;
            LinklistFT = LinklistFT.replace("[QTA0_IDENTIFIANT_FT]", item.QTA0_IDENTIFIANT_FT_ALTIS);
          // LinklistFT = LinklistFT.replace("[PROJET]", _spPageContextInfo.webServerRelativeUrl.replace(_spPageContextInfo.siteServerRelativeUrl, '').replace('/', ''));
        }
    }
    if (item.QTA0_IDENTIFIANT_ISSUE != undefined && item.QTA0_IDENTIFIANT_ISSUE != "") {
        if (linkedListft != null && linkedListft != undefined) {
            LinklistFT = linkedListft.Value;
            LinklistFT = LinklistFT.replace("[QTA0_IDENTIFIANT_FT]", item.QTA0_IDENTIFIANT_ISSUE);
            //LinklistFT = LinklistFT.replace("[PROJET]", _spPageContextInfo.webServerRelativeUrl.replace(_spPageContextInfo.siteServerRelativeUrl, '').replace('/', ''));
        }
    }
    
    let ft = {
    "detail":{
      "workpieceChoiceData": { key: item.QTB9_ID_DECOUPAGE_PSA != null ? item.QTB9_ID_DECOUPAGE_PSA : "", value: item.QTR4_LIB_DECOUPAGE_PSA != null ? item.QTR4_LIB_DECOUPAGE_PSA : "" },
      "defectisInputModified":false,
        "workpieceChoice": item.QTR4_LIB_DECOUPAGE_PSA!=null ?item.QTR4_LIB_DECOUPAGE_PSA:"",
        "workpieceChoiceCode": item.QTR4_CODE_DECOUPAGE_PSA!=null?item.QTR4_CODE_DECOUPAGE_PSA:"",
        "workpieceChoiceID": item.QTB9_ID_DECOUPAGE_PSA!=null?item.QTB9_ID_DECOUPAGE_PSA:"",
        "additionalDesignation": item.QTR4_DESIGNATION_SUPPL!=null?item.QTR4_DESIGNATION_SUPPL:"",
        "workpieceChoiceAndAditional": (!item.QTR4_LIB_DECOUPAGE_PSA ? "" : item.QTR4_LIB_DECOUPAGE_PSA + "-") + (!item.QTR4_DESIGNATION_SUPPL ? "" : item.QTR4_DESIGNATION_SUPPL),
        "tradeForAction": !item.QTB9_METIER_POUR_ACTION!=null ?  item.QTB9_METIER_POUR_ACTION:"" ,
        "lot": !item.QTB9_LOT !=null? item.QTB9_LOT: "" ,
        "titanWord": item.QTB9_LIBELLE!=null?item.QTB9_LIBELLE :"",
        "FTText": item.QTA0_LIBELLE_FT!=""?item.QTA0_LIBELLE_FT:"",
        "FTDescription": item.QTA0_DESCR_DETAIL_FT?item.QTA0_DESCR_DETAIL_FT:"",
        "COFOR": item.QTR4_COFOR?item.QTR4_COFOR:"",
        "ALTISTE_PLM": item.QTR4_ALTISTE_PLM!=null?item.QTR4_ALTISTE_PLM:"",
        "businessDriverName": item.QTA0_PILOTE_FT,
        "businessDriverDisplayName": (!item.QTA0_PILOTE_FT_DISPLAYNAME ? "" : item.QTA0_PILOTE_FT_DISPLAYNAME),
        "tags": tagsArray,
        "FTOrigin": item.QTA0_CODE_ORIGINE_FT,
        "FTOriginLib": item.QTA0_LIB_ORIGINE_FT,
        "id": item.QTB9_ID,
        "solutions": solutionsArray,
        "linklistFT": LinklistFT,
        "FTs": relatedFTsArray,
        "PLMLink": PLMLink
    },
    "basic":{
      "title": item.QTB9_LIBELLE,
      "metier": !item.QTB9_METIER_POUR_ACTION ? "" : item.QTB9_METIER_POUR_ACTION,
      "tags": tagsArray.map(function(obj) { return obj.value; })
    }
    };
    
    
    return ft;
  }
  /**
   * function is called on save button click event
   * Author:Shweta
   * Created date:23 march 2021
   * @param FTObject 
   */
  saveFT (FTObject,index) {
    // debugger
    let tradeObj=[]
    if(FTObject.pieceInfo.length>0){
     tradeObj=FTObject.pieceInfo.filter(x=>x.ID==FTObject.tradeForActionID)
    }
    
    let data = {
    idFTTitan : JSON.stringify(FTObject.id),
    ID_DECOUPAGE_PSA : !_.isNil(FTObject.workpieceChoiceID)?FTObject.workpieceChoiceID:null,
    lot : !FTObject.lot ? "" : FTObject.lot,
    titanWord :!FTObject.titanWord ? "" : FTObject.titanWord,
    tradeForAction : tradeObj.length>0 ? tradeObj[0].tradeForAction :"" ,
    businessDriverName :!FTObject.businessDriverName ? "" : FTObject.businessDriverName,
    FTOrigin : !FTObject.FTOrigin ? "" : FTObject.FTOrigin,
    tags: _.map(FTObject.tags, function (n) { return n.value; }),
    LoginName: this.commonservice.getUserID(),
    CurrentProjectID:  this.projectid
    }
    
    this.techservice.updateFT(data).subscribe((data: any) => {
      let response = data
      this.tagList=[];
      this.getTags();
      this.refreshFT(FTObject.id, true,index);
     this.showModalInfo("Changes Saved","","");
     this.resetChangeState(FTObject.id);
     this.enableLoader = false
    },
      err => {
        this.enableLoader = false
        this.showModalInfo("ERROR: " + "An error occured saving FT: " + JSON.stringify(err),"","");
      });
  
  }
  resetChangeState(id)
  {
    this.commonservice.setChangedCod(true)
  
    let filteredData = _.filter(
      this.techeventsList.records, function (item) {
        if (item.id == id) {
          item.defectisInputModified = false
        }
      });
  }
  showModalInfo(msgText, localize, prefix) {
    if (!prefix) {
      prefix = "";
    }
    if (!localize) {
      this.infoModalBody = prefix + msgText

    } else {
      this.infoModalBody = prefix + this.translate.instant(msgText)
    }
    this.InfoModal=true
   
  }
  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
