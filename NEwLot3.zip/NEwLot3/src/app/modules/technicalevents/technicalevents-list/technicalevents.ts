export interface TechnicalEvent{
   "DESIGNATION_PIECE"?:string;
   "ID":string;
   "IDENTIFIANT_FT_ALTIS"?: string;
"IDENTIFIANT_ISSUE"?: string;
"ID_ISSUE"?: string;
			"ID_LANCEMENT_TITAN"?: Number;
			"INSTANCE_DECISION_FT"?: string;
			"LIBELLE_ETAT_AVANCEMENT_FT"?: string;
			"LIBELLE_FT_TITAN"?: string;
			"METIER_POUR_ACTION"?: string;
			"NOM_LANCEMENT"?: string;
			"TAGS":Array<string>
  
} 