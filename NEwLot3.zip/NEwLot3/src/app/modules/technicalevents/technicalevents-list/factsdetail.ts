export interface FactDetails {
ALTISTE_PLM: string;
COFOR: string;
FTDescription: string;
FTOrigin:string;
FTOriginLib: string;
FTText: string;
FTs: [];
PLMLink: string;
additionalDesignation: string;
businessDriverDisplayName:string;
businessDriverName:string;
id:Number;
linklistFT:string;
lot:string;
solutions:[];
tags:string;
titanWord:string;
tradeForAction:string;
workpieceChoice:string;
workpieceChoiceAndAditional:string;
workpieceChoiceCode:string;
workpieceChoiceID:Number
}

