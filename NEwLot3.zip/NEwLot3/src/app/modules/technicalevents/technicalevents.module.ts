import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TechnicaleventsRoutingModule } from './technicalevents-routing.module';
import {DialogModule} from 'primeng/dialog';
import { TechnicaleventsListComponent } from './technicalevents-list/technicalevents-list.component';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import {MatButtonModule} from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
import {MatListModule} from '@angular/material/list';
import {SearchPipe} from '../../shared/pipes/search.pipe'
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {ChipsModule} from 'primeng/chips';
import { TranslateModule } from '@ngx-translate/core';
@NgModule({
  
  imports: [
    CommonModule,MatListModule,InfiniteScrollModule,AutoCompleteModule,ChipsModule,
    FormsModule,ReactiveFormsModule, MatSelectModule, MatButtonModule,
    TechnicaleventsRoutingModule,TranslateModule,DialogModule
  ],
  declarations: [TechnicaleventsListComponent,SearchPipe],
 
 
})
export class TechnicaleventsModule { }
