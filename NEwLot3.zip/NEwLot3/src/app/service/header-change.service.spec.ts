import { TestBed } from '@angular/core/testing';

import { HeaderChangeService } from './header-change.service';

describe('HeaderChangeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HeaderChangeService = TestBed.get(HeaderChangeService);
    expect(service).toBeTruthy();
  });
});
