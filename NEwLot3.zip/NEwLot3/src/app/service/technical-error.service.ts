import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class TechnicalErrorService {

  private readonly errorFlag: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
  
  constructor(private _authService: AuthenticationService) {
    this.errorFlag = new BehaviorSubject<boolean>(false);
   }

   getValidatedValue(): Observable<any> {
    return this.errorFlag.asObservable();
  }
  
  setFlagValue(newValue):void {
   
    this.errorFlag.next(newValue);
  }

 
}
