import { TestBed } from '@angular/core/testing';

import { MeasurelistService } from './measurelist.service';

describe('MeasurelistService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MeasurelistService = TestBed.get(MeasurelistService);
    expect(service).toBeTruthy();
  });
});
