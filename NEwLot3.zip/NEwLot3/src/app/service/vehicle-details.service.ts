import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { TechnicalErrorService } from './technical-error.service';
import { URLService } from './url.service';

@Injectable({
  providedIn: 'root'
})
export class VehicleDetailsService {

  constructor(private httpClient: HttpClient,private http: HttpClient,
    private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      this.technicalErrorService.setFlagValue(true)
      console.error('Server Side Error :', errorResponse);
    }
    return throwError(errorResponse);
  }
 
  getVehicleList(params):Observable <any>{
    // return this.http.get("../assets/jsonFiles/vehicleDetails.json");
    return this.httpClient.get<any[]>(this.urlService. getvehicleListByProjectId()+"/"+ params.projectId + '/'+params.pageSize +"/" 
    +params.pageNumber+"/" + params.userID ).pipe(
      map((data:any) => data.GetPagedVehicleListByProjectIDResult),
      catchError(
        (error: any) => {
          this.handleError(error);
            throw error})
  ); 
  }
/*search vehicle list */
  searchVehicleList(req):Observable <any>{
    return this.httpClient.post<any>(this.urlService.searchVehicleList(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
      map((data:any) => data.SearchPagedVehicleListByProjectIDResult),
      
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
      )}

  /*delete vehicle*/
  deleteVehicleList(req):Observable <any>{
    return this.httpClient.post<any>(this.urlService.deleteVehicle(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
      map((data:any) => data),
      
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
      );
  }

  /*get vehicle details by id*/
  getVehcileDetailsByID(params):Observable <any>{
    return this.httpClient.get<any[]>(this.urlService.getVehicleDetailsById()+"/"+ params.VehicleID + '/'+params.UserName
 ).pipe(
      map((data:any) => data),
      catchError(
        (error: any) => {
          this.handleError(error);
            throw error})
  );
  }

  /*update vehicle*/
  updateVehicleDetails(req):Observable <any>{
    return this.httpClient.post<any>(this.urlService.UpdateVehicleDetails(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
      map((data:any) => data.UpdateVehicleFromUIResult),
      
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
      );
  }

   /*add vehicle*/
   addVehicleDetails(req):Observable <any>{
    return this.httpClient.post<any>(this.urlService.addVehicleDetails(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
      map((data:any) => data.AddVehicleFromUIResult),
      
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
      );
  }
}

