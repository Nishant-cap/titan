import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from "./url.service";
import * as _ from 'node_modules/lodash';
import { TechnicalErrorService } from './technical-error.service';
import { parseClassNames } from '@fullcalendar/core';

@Injectable({
  providedIn: 'root'
})
export class CodificationSeaService {

  constructor(private httpClient:HttpClient, private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }
/**
 * Author:Shweta
 * To get records on page load
 * @param params 
 */
  getRecords(params):Observable <any>{
    
    return this.httpClient.get<any>(this.urlService.getMeasuresURL()+"/"+params.defectid+"/"+params.locale+"/"+params.id).pipe(
      map((data:any) => data.GetMeasureAllResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
/**
 * 
 * @param params 
 */
  getMeasureSynthesis(params):Observable <any>{
    
    return this.httpClient.get<any>(this.urlService.getMeasureSynthesisURL()+"/"+params.locale+"/"+params.id).pipe(
      map((data:any) => data.GetMeasureSynthesisResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  getTechFactInfo(params):Observable <any[]>{
   
    return this.httpClient.get<any>(this.urlService.getdefectinfoURL()+"/"+params.defectid+"/"+params.locale+"/"+params.projectId).pipe(
      map((data:any) => data),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    )}

    getTags(reqparams):Observable <any>{
      
      return this.httpClient.get<any>(this.urlService.getAllTNTQTB3URL()+"/"+reqparams.loacle+"/"+reqparams.projectId).pipe(
         map((data:any) => data),
         catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    )}
   
    getDefaultPiece(reqparams):Observable <any>{
     
      let  codLoc= reqparams.codLoc;
       //SPT-2391
                //The codes in codes_loc_sparte field will not have the "S" before the number
                //We must change the logic in the retrieval of the defect proposed data when codifiing them
            if(reqparams.codLoc.toLowerCase().startsWith("s"))
                codLoc = reqparams.codLoc.replace(/^s/gi, "")
                    //The codes in codes_loc_neo field will not have the "N" before the number
             else if(reqparams.codLoc.toLowerCase().startsWith("n"))
              codLoc = reqparams.codLoc.replace(/^n/gi, "")
         return this.httpClient.get<any>(this.urlService.getDefaultPieceChoiceURL()+"/"+reqparams.launchid+"/"+codLoc +"/"+reqparams.locale).pipe(
         map((data:any) => data),
         catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    )}
    
    getAltisOrigins(locale):Observable <any>{
     
      return this.httpClient.get<any>(this.urlService.getAltisURL()+"/"+locale).pipe(
        map(response => {
          let resp=response.GetOriginsAltisResult
          let currentOrigin = {}; let origins = [];
          resp.forEach(element => {
            if (element.REFERENTIEL === "ORIGINE_ALTIS") {
              //When ORIGINE_ALTIS we must use I18N_CODE_VALEUR
               currentOrigin = {
                  "i18n_code": element.I18N_CODE_VALEUR,
                  "title": element.LIBELLE,
                  "locale": element.LOCALE,
                  "altistePlm": "A"
              };
          }
          if (element.REFERENTIEL === "ORIGINE_TITAN") {
              //When origine_titan we cannot use I18N_CODE_VALEUR, we must use CODE_VALEUR_PLM
               currentOrigin = {
                  "i18n_code": element.CODE_VALEUR_PLM,
                  "title": element.LIBELLE,
                  "locale": element.LOCALE,
                  "codeValeurPLM": element.CODE_VALEUR_PLM,
                  "codeValeurAltis": element.CODE_VALEUR_ALTIS,
                  "altistePlm": "P"
              };
          }
       
          origins.push(currentOrigin);
        });
         return origins
        }),
        catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    )}
    getpiecesFilter(parameters):Observable <any>{
     
           return this.httpClient.get<any>(this.urlService.piecesFilterURL()+"/"+parameters.ftId+"/"+parameters.langId).pipe(
         map((data:any) => data),
         catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    ); }
    getPieceAssociatedInfo(params):Observable <any>{
     
      return this.httpClient.get<any>(this.urlService.getEnginerringTeamURL()+"/"+params.locale+"/"+params.launchid+"/"+params.choiceId ).pipe(
        map(response => {
          let resp=response.GetTNTQTR4ByIDResult
          let pieceInfo = [];
          response.GetTNTQTR4ByIDResult.forEach(element => {
            let currentPiece = {
                "ID": element.ID,
                "CODES_LOC_SPARTE": !element.CODES_LOC_SPARTE ? "" : element.CODES_LOC_SPARTE.toString(),
                "CODES_SQUARE": !element.CODES_SQUARE ? "" : element.CODES_SQUARE.toString(),
                "CODE_DECOUPAGE_PSA": !element.CODE_DECOUPAGE_PSA ? "" : element.CODE_DECOUPAGE_PSA.toString(),
                "COFOR": !element.COFOR ? "" : element.COFOR.toString(),
                "DATE_CREATION": !element.DATE_CREATION ? null : new Date(parseInt(element.DATE_CREATION.substr(6))),
                "DATE_MAJ": !element.DATE_MAJ ? null : new Date(parseInt(element.DATE_MAJ.substr(6))),
                "DESIGNATION_SUPPLEMENTAIRE": !element.DESIGNATION_SUPPLEMENTAIRE ? "" : element.DESIGNATION_SUPPLEMENTAIRE.toString(),
                "ID_LANCEMENT": !element.ID_LANCEMENT ? "" : element.ID_LANCEMENT.toString(),
                "ID_PROJET": !element.ID_PROJET ? "" : element.ID_PROJET.toString(),
                "METIER_POUR_ACTION_NIV_1": !element.METIER_POUR_ACTION_NIV_1 ? "" : element.METIER_POUR_ACTION_NIV_1.toString(),
                "METIER_POUR_ACTION_NIV_2": !element.METIER_POUR_ACTION_NIV_2 ? "" : element.METIER_POUR_ACTION_NIV_2.toString(),
                "METIER_POUR_ACTION_NIV_3": !element.METIER_POUR_ACTION_NIV_3 ? "" : element.METIER_POUR_ACTION_NIV_3.toString(),
                "PILOTE": !element.PILOTE ? "" : element.PILOTE.toString(),
                "ALTISTE_PLM": !element.ALTISTE_PLM ? "" : element.ALTISTE_PLM.toString(),
                "PILOTE_DISPLAY": !element.PILOTE_DISPLAY ? "" : element.PILOTE_DISPLAY.toString(),
                "USER_CREATION": !element.USER_CREATION ? "" : element.USER_CREATION.toString(),
                "USER_MAJ": !element.USER_MAJ ? "" : element.USER_MAJ.toString(),
            };
            pieceInfo.push(currentPiece);
            
        });
        return pieceInfo
         
        }),
        catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    )}

  getAllTNTQTB3Configured(params):Observable <any>{
    
    return this.httpClient.get<any>(this.urlService.getAllTNTQTB3ConfiguredURL()+"/"+params.ID+"/"+params.locale).pipe(
      map((data:any) => data.GetAllTNTQTB3EntitysResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  updatePieceAltistePlm(data):Observable <any>{
   
    return this.httpClient.post<any>(this.urlService.changePieceAltistePlmURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data),
       catchError(this.handleError)
  )}
  addAttachmentLink(data):Observable <any>{
  
    return this.httpClient.post<any>(this.urlService.savelinkattachmentURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  updateAttachmentLink(data):Observable <any>{
    
    return this.httpClient.post<any>(this.urlService.updatelinkattachmentURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data),
       catchError(this.handleError)
  )}
  deleteAttachmentLink(data):Observable <any>{
   
    return this.httpClient.post<any>(this.urlService.deletelinkattachmentURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  saveImageAttachment(data):Observable <any>{
   
    return this.httpClient.post<any>(this.urlService.saveImageattachmentURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  deleteImageAttachment(data):Observable <any>{
    
    return this.httpClient.post<any>(this.urlService.deleteImageattachmentURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  getImageAttachment(data):Observable <any>{
    
    return this.httpClient.get<any>(this.urlService.getdefectAttachmentURL()+"/"+data.locale+"/"+data.defectid).pipe(
       map((data:any) => data.GetDefectAttachmentsResult),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  getDefectAttachment(params):Observable <any>{
    
    return this.httpClient.get<any>(this.urlService.getdefectAttachmentURL()+"/"+params.defectId).pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  /**Set Image as main image */
  
    setMainImage(data):Observable <any>{
     
      return this.httpClient.post<any>(this.urlService.setMainImage(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
         map((data:any) => data),
         catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    )}


  /**
   * change state
   * @param data 
   */
  changeState(data):Observable <any>{
   
    return this.httpClient.post<any>(this.urlService.changeStateURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}

  /***
   * unlink from altis
   */
  unlinkFromFT(data):Observable <any>{
    
    return this.httpClient.post<any>(this.urlService.unlinkAltisURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data.UnlinkResult),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  /***
   * unlink from plm
   */
  unlinkFromIssue(data):Observable <any>{
    
    return this.httpClient.post<any>(this.urlService.unlinkPlmURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data.UnlinkIssueResult),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  /**
   * PlM and Altis Service
   * @param data 
   */
  linkAltis(data):Observable <any>{
    
    return this.httpClient.post<any>(this.urlService.linkAltisURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data.LinkResult),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
/**
 * 
 * @param data 
 */
  linkToIssue(data):Observable <any>{
   
    return this.httpClient.post<any>(this.urlService.linkPlmURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
       map((data:any) => data.LinkIssueResult),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
/**
 * 
 * @param data 
 */
measureExport(params):Observable <any>{
  
  return this.httpClient.get<any>(this.urlService.measureexportURL()+"/"+params.locale+"/"+params.measureid+"/"+params.userid+"/"+params.alldefects).pipe(
    map((data:any) => data.ExportMeasureResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}
/**
 * save ft data
 * @param data 
 */
saveDefect(data):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.updatedefectURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
     map((data:any) => data.AltisLinkResponse),
     catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}
/***
 * create new Ft
 */
createFT(data):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.createFTURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
     map((data:any) => data.CreateFTResult),
     catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}
createIssue(data):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.createIssueURL(),data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})}).pipe(
     map((data:any) => data.CreateIssueResult),
     catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}
/***
 * check email setting
 */
checkEmailConfig(params):Observable <any>{
 
  return this.httpClient.get<any>(this.urlService.emailSettingsConfiguredURL()+"/"+params.id+"/"+params.loacle).pipe(
    map((data:any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}
sendEmail(params):Observable <any>{
  
  return this.httpClient.get<any>(this.urlService.sendemailURL()+"/"+params.LOCALE+"/"+params.IDMeasure+"/"+params.UserName).pipe(
    map((data:any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}
getRoleByProjectId(params):Observable <any>{
  
  return this.httpClient.get<any>(this.urlService.getRoleByProjectId()+"/"+params.UserId+"/"+params.ProjectId).pipe(
    map((data:any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}

  /**
   * 
   * @param err 
   */
  private handleError(err:HttpErrorResponse){
    let errorMessage="";

    if(err.error instanceof ErrorEvent){
        errorMessage =`An error occured: ${err.error.message} `
    }
    else{
      this.technicalErrorService.setFlagValue(true)
        errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
    }
    console.log(errorMessage);
    return throwError(errorMessage);

}
}
