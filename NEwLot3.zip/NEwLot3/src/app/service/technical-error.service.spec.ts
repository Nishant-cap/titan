import { TestBed } from '@angular/core/testing';

import { TechnicalErrorService } from './technical-error.service';

describe('TechnicalErrorService', () => {
  let service: TechnicalErrorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TechnicalErrorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
