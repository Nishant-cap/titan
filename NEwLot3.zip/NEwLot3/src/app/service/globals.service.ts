export const GlobalsService = Object.freeze({
  //BASE_API_URL: 'http://ott.dev.inetpsa.com:9090/otrmicroservice'
  BASE_API_URL: 'http://yvav0dg0:90/'
 // BASE_API_URL: 'http://localhost:8080'
  //BASE_API_URL: 'http://api.ott.qualif.preprod.inetpsa.com/otrmicroservice'
  //BASE_API_URL: 'http://yval4hb0.inetpsa.com:8080/otrmicroservice' // for preprod
  //... more of your variables
});