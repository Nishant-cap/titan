import { TestBed } from '@angular/core/testing';

import { ProjectHomeService } from './launch.service';

describe('ProjectHomeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProjectHomeService = TestBed.get(ProjectHomeService);
    expect(service).toBeTruthy();
  });
});
