import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { URLService } from './url.service';
import { TechnicalErrorService } from './technical-error.service';
@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  constructor(private httpClient: HttpClient,private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }
  

  getvehicles(req):Observable <any>{
  return this.httpClient.post<any>(this.urlService.getVehicleURL(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
  map((data:any) => data.GetVehicleInfoByIDResult),
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error})
  )}

  savevehicles(req):Observable <any>{
    return this.httpClient.post<any>(this.urlService.updateVehicleURL(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data.UpdateVehicleInfoResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
    )}
  private handleError(errorResponse: HttpErrorResponse) {
   ad if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      this.technicalErrorService.setFlagValue(true)
      console.error('Server Side Error :', errorResponse);
    }
    return throwError(errorResponse);
  }

}
