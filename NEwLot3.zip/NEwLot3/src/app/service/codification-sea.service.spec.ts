import { TestBed } from '@angular/core/testing';

import { CodificationSeaService } from './codification-sea.service';

describe('CodificationSeaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CodificationSeaService = TestBed.get(CodificationSeaService);
    expect(service).toBeTruthy();
  });
});
