import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders ,HttpRequest, HttpEvent} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { URLService } from "./url.service";
import { catchError,tap,map } from 'rxjs/operators';
import { TechnicalErrorService } from './technical-error.service';
@Injectable({
  providedIn: 'root'
})
export class PartRepositoryService {

  constructor(private httpClient: HttpClient,private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }

  // return error message to the end user
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      this.technicalErrorService.setFlagValue(true)
      console.error('Server Side Error :', errorResponse);
    }
    return throwError(errorResponse);
  }
 uploadFile(req):Observable <any>{
  
      return this.httpClient.post<any>(this.urlService.uploadURL(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
        map((data:any) => data),
        
        catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    );}
    export(req):Observable <any>{
      
      return this.httpClient.post<any>(this.urlService.exporlURL(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
        map((data:any) => data),
        
        catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    );}
    exportAll(req):Observable <any>{
      
      return this.httpClient.post<any>(this.urlService.exportAllURL(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
        map((data:any) => data),
        
        catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    );}
  // upload(file: File): Observable<HttpEvent<any>> {
  //   const formData: FormData = new FormData();

  //   formData.append('file', file);

  //   const req = new HttpRequest('POST', `${this.baseUrl}/upload`, formData, {
  //     reportProgress: true,
  //     responseType: 'json'
  //   });

  //   return this.http.request(req);
  //}

  // getFiles(): Observable<any> {
  //   return this.http.get(`${this.baseUrl}/files`);
  // }
}
