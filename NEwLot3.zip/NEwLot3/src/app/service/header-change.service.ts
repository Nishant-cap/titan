
import { Injectable, Output, EventEmitter, Directive } from '@angular/core';

import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
@Directive()
@Injectable({
  providedIn: 'root'
})
export class HeaderChangeService {
  @Output() change = new EventEmitter<any>();
  @Output() projectchange = new EventEmitter<any>();
  private userlangObs$: BehaviorSubject<string> = new BehaviorSubject(null);
  
  private userProfileObs$: BehaviorSubject<string> = new BehaviorSubject(null);
  isLanguageSelected = false; isProjectSelected = false;

  constructor() { }
  getlanguageProfileObs(): Observable<string> {
    return this.userlangObs$.asObservable();
}
setlanguageProfileObs(lang: string) {
  this.userlangObs$.next(lang);
}
setuserprofile(user: any) {
  this.userProfileObs$.next(user);
}
getuserprofile(): Observable<any>  {
  return this.userProfileObs$.asObservable();
}
  toggle() {
    this.isLanguageSelected = true;
    this.change.emit({ isSelected: this.isLanguageSelected });
  }
  changeLeftpanel(istrue) {
    this.isProjectSelected =  istrue;
    this.projectchange.emit({ isProjectSelected: this.isProjectSelected });
  }
}
