import { TestBed } from '@angular/core/testing';

import { AdminTagService } from './admin-tag.service';

describe('AdminTagService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminTagService = TestBed.get(AdminTagService);
    expect(service).toBeTruthy();
  });
});
