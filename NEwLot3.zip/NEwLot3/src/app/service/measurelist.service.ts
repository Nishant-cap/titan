
import { Injectable } from '@angular/core';
import { TechnicalEvent } from '../modules/technicalevents/technicalevents-list/technicalevents';
import { FactDetails } from '../modules/technicalevents/technicalevents-list/factsdetail';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { URLService } from "./url.service";
import LocalStorage from '../util/local-storage';
import * as _ from 'node_modules/lodash';
import { TechnicalErrorService } from './technical-error.service';
@Injectable({
  providedIn: 'root'
})
export class MeasurelistService {
  pageSize: Number = 100;
  pageNumber: Number = 1
  constructor(private httpClient: HttpClient, private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }
  getRecords(req): Observable<any> {
   
    return this.httpClient.get<any>(this.urlService.getmeasureURL() + "/" + req.locale + "/" + req.pageSize + "/" + req.pageNumber + "/" + req.projectId).pipe(
      map(
        (data: any) => {
          return data.GetPagedTNTQVB5ByCurrentProjectResult
        }
      ),

      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }

  updateTNTQTB2DateEmon(req): Observable<any> {
   
    return this.httpClient.post<any>(this.urlService.updateTNTQTB2DateEmonURL(), req, { headers: new HttpHeaders({ 'Content-Type': "application/json;" }) }).pipe(
      map((data: any) => data),

      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }

  private handleError(err: HttpErrorResponse) {
    let errorMessage = "";

    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error occured: ${err.error.message} `
    }
    else {
this.technicalErrorService.setFlagValue(true)
      errorMessage = `Server returned code:${err.status}, error message is:${err.message}`
    }
    console.log(errorMessage);
    return throwError(errorMessage);

  }
}
