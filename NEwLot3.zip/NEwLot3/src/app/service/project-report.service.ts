import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from './url.service';
import { TechnicalErrorService } from './technical-error.service';


@Injectable({
  providedIn: 'root'
})
export class ProjectReportService {

  constructor(private httpClient: HttpClient,private urlService:URLService,private technicalErrorService:TechnicalErrorService) { }
  // return error message to the end user
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      this.technicalErrorService.setFlagValue(true)
      console.error('Server Side Error :', errorResponse);
    }
    return throwError(errorResponse);
  }



    /**------------------------------
*GET REPORT DATA.
--------------------------------*/


getReportData(parameter):Observable <any>{
  //API
  
     return this.httpClient.get<any>(this.urlService.getReportStatusUrl() +"/"+ parameter.UserLocale + "/" +parameter.StatusValue).pipe(
      map((data: any) => data),
      tap(data => console.log('All' + JSON.stringify(data))),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
      );
}

getSingleReport(parameter):Observable <any>{
  //API
 
     return this.httpClient.get<any>(this.urlService.getSingleReportData() + "/" +parameter.ID + "/"+parameter.UserLocale).pipe(
      map((data: any) => data.GetReportDetailsByIDResult),
      tap(data => console.log('All' + JSON.stringify(data))),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
      );
}

// Get Language

getProjectLanguage(): Observable<any> {
  
    return this.httpClient.get<any[]>(this.urlService.reportLanguageUrl() ).pipe(
      map((response: any) => response.GetLanguageMasterResult),
      tap(data => console.log('Report Language' + JSON.stringify(data))),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }

  // Get Perimiter List

  getPerimeterList(param): Observable<any> {
    
  return this.httpClient.get<any[]>(this.urlService.reportPerimiterUrl()+"/"+ param.LOCALE).pipe(
    map((response: any) => response.GetPerimeterListMasterByLocaleResult),
    tap(data => console.log('Report Language' + JSON.stringify(data))),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}

// Get Status Report Rasio Options

getReportStatusList(param): Observable<any> {
 
  return this.httpClient.get<any[]>(this.urlService.reportStatusUrl()+"/"+ param.LOCALE ).pipe(
    map((response: any) => response.GetReportStatusListMasterByLocaleResult),
    tap(data => console.log('Report Language' + JSON.stringify(data))),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}



 // Get Project Status
  // API -- GetProjectStatusMasterByUserLocale/{userLocale}
  getReportStatus(param): Observable<any[]> {
   
    return this.httpClient.get<any[]>(this.urlService.getReportStatusUrl()+"/"+ param.LOCALE).pipe(
      map((response: any) => response.GetLanguageMasterResult),
      tap(data => console.log('project status' + JSON.stringify(data))),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );

  }
  
// POST request for Create new customs export config
createReportData(data): Observable<any> {
  
  return this.httpClient.post<any>(this.urlService.saveReportURL(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data),
    tap(data => console.log('project status' + JSON.stringify(data))),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}
 // POST request for Delete Report
deleteReport(data): Observable<any> {
  
  return this.httpClient.post<any>(this.urlService.deleteReportURL(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data.DeleteReportByIDResult),
    tap(data => console.log('project status' + JSON.stringify(data))),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}

//Content - Tools

// getSingleTool(id):Observable <any>{
//   //API

//      return this.httpClient.get<any>(this.urlService.getSingleTooltData() + "/" + id  + "/en_US").pipe(
//       map((data: any) => data.GetReportDetailsByIDResult),
//       tap(data => console.log('All' + JSON.stringify(data))),
//       catchError(this.handleError)
//       );
// }
}
