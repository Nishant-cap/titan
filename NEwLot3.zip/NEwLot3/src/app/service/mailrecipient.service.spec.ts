import { TestBed } from '@angular/core/testing';

import { MailrecipientService } from './mailrecipient.service';

describe('MailrecipientService', () => {
  let service: MailrecipientService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MailrecipientService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
