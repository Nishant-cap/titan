import { HttpClient,HttpHeaders,HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable,throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { TechnicalErrorService } from './technical-error.service';
import { URLService } from './url.service';

@Injectable({
  providedIn: 'root'
})
export class MailrecipientService {
  constructor(private httpClient: HttpClient,private urlService:URLService,private technicalErrorService:TechnicalErrorService) { }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      this.technicalErrorService.setFlagValue(true)
      console.error('Server Side Error :', errorResponse);
    }
    return throwError(errorResponse);
  }

getAllMailRecipients(parameter):Observable<any>{
  
  return this.httpClient.get<any>(this.urlService.getAllMailList() +"/"+ parameter.ProjectID +"/"+parameter.UserName,
  { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} )
  .pipe(map((data:any) => data.GetAllMailRecipientsResult),
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error}));
}
getemailID():Observable<any>{
  
  //return this.httpClient.get<any>("assets/mockdata/emailList.json");
  return this.httpClient.get<any>("assets/mockdata/emailList.json" ).pipe(
    map((data: any) => data),
    tap(data => console.log('All' + JSON.stringify(data))),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
    );
}

getUserAndEmailIDBySearchText(parameter):Observable<any>{
  
  return this.httpClient.get<any>(this.urlService.getUserAndEmailIdBySearchText()+"/"+ parameter.Searchtext +"/"+parameter.UserLocale,
  { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
  .pipe(map((data:any) => data.GetUserAndGoalsBySearchTextResult),
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error}));
}

addMailData(data): Observable<any> {
 
  return this.httpClient.post<any>(this.urlService.addMailRecipients(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}

getmailRecipientsByID(parameter):Observable <any>{
  
  return this.httpClient.get<any>(this.urlService.getMailDataByID() +"/"+ parameter.ID +"/"+parameter.UserName,
  { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
  .pipe(map((data:any) => data.GetMailRecipientsResult),
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error}));
}

updateMailData(data):Observable<any>{
  
return this.httpClient.post<any>(this.urlService.updateMailRecipients(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
  map((data: any) => data),
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error})
);
}

deleteMailRecipientByID(parameter):Observable<any>{
  
  return this.httpClient.get<any>(this.urlService.deleteMailRecipient() +"/"+ parameter.ID +"/"+parameter.UserName,
  { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} )
  .pipe(map((data:any) => data),
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error}));

}
}