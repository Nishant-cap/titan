import { Injectable } from '@angular/core';
import { Project } from '../modules/home/project-list/project';
import { ProjectStatus } from "../modules/home/project-list/projectstatus";
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';

import { URLService } from './url.service';
import { Users } from '../modules/home/access-management/users' ;
import { TechnicalErrorService } from './technical-error.service';
@Injectable({
  providedIn: 'root'
})
export class AccessManagementService {

  constructor(private httpClient:HttpClient, private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }


  getRecords():Observable <Users[]>{
    
    return this.httpClient.get<Users[]>("assets/mockdata/users.json").pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  );}

  getProjects(parameter):Observable <any>{
    
    return this.httpClient.get<any>(this.urlService.getProjectList() +"/"+ parameter.UserLocale,
    { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
    .pipe(map((data:any) => data.GetProjectListForAllStatusResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));
    }

    getAccessManagementTransaction(parameter):Observable <any>{
     
      return this.httpClient.get<any>(this.urlService.getAccessManagementTransactionDetails() +"/"+ parameter.UserLocale,
      { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
      .pipe(map((data:any) => data.GetAccessManagementTransactionDetailsResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error}));
      } 
  
  getLdapUsers():Observable <Users[]>{
    
    return this.httpClient.get<Users[]>("assets/mockdata/users.json").pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  );}

  getRoleMaster(parameter):Observable<any>{
    
    return this.httpClient.get<any>(this.urlService.getRoleMaster() +"/"+ parameter.UserLocale,
    { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
    .pipe(map((data:any) => data.GetRolesMasterResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));

  }

  saveAccessManagementDetails(req):Observable<any>{
   
  //let token="eyJhbGciOiJSUzI1NiIsImtpZCI6IjRZclEzVGJxOUIyN29TM0V4S2ItaHZpSDI0dyIsInBpLmF0bSI6IjRwNyJ9.eyJzY29wZSI6Im9wZW5pZCIsImNsaWVudF9pZCI6IktRU1VRRUtFVUFFSFJFWEhDVlpCR0NHTUtQT0dXSkdWIiwiZ3JvdXBzIjpbIlROVC5VU0VSLlBSRVBST0QiLCJUTlQuRVRVREVTIl0sImZpcnN0bmFtZSI6IkhJTUFOU0hVIiwibGFzdG5hbWUiOiJSQUkiLCJ1c2VybmFtZSI6IkU2MDQxMjYiLCJleHAiOjE2MTUzNzkyMjB9.AgPyL-lFj_z_TiolSyp0QIIr4mVFTwt_jl3W1K6PTkqMvMg7X5HQEVh2JiCCXoen9YUfWIXJ34azhcqT81ffeRxXYA7Mm3oA1UJqN31bxm0K-xtfc4mP31wnw_tPr4tJlWAyUFfo72XYusmJigMhqZm1qSUjb7Ms9G7bdghUPHj4SSS78Gwtsa0URLm6IglGdo8dUzQrQV_Jl6qLCSznKVUowdx3XauNSUMk6JdBKV0vhmV10vqtvSl3sve4KZrOR-tNpqQ9KjAtStfeMn2G0MiMFT4hVtlllTzAQsmUbjfmRk5BUt5PRDlOy9b6n4Ua6CykvPtb4kZO8KJzfdOxVQ"
       return this.httpClient.post<any>(this.urlService.saveAccessManagementDetails(), req, 
  //{ headers: new HttpHeaders().set('Authorization','Bearer ' + token)
  //.set('Content-Type', 'application/json')} )
    { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
     .pipe(
         map((data: any) => data),
        
         catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
       );
     }

  getProjectListByGoalIDandRoleID(parameter):Observable<any>{
   
    return this.httpClient.get<any>(this.urlService.getProjectListByUserGoalIDAndRoleID() +"/"+ parameter.UserGoalId+"/"+parameter.RoleID,
    { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
    .pipe(map((data:any) => data.GetProjectListByUserGoalIDAndRoleIDResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));

  }

  deleteAccessManagementRecordsByID(req):Observable<any>{
    
        return this.httpClient.post<any>(this.urlService.deleteAccessManagementRecordsById(), req, 
       { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
      .pipe(
          map((data: any) => data),
         
          catchError(
            (error: any) => {
            
              this.handleError(error);
                throw error})
        );
      }

    editAccessmanagementRecordById(parameter):Observable<any>{
     
      return this.httpClient.get<any>(this.urlService.editAccessManagementById() +"/"+ parameter.ID+"/"+parameter.UserLocale,
    { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
    .pipe(map((data:any) => data.EditAccessManagementByIDResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));
    }

    getUserInfoPopupDetails(parameter):Observable<any>{
      
      return this.httpClient.get<any>(this.urlService.getuserInfoPopupDetails() +"/"+ parameter.UserGoalId+"/"+parameter.UserLocale,
    { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
    .pipe(map((data:any) => data.GetUserInfoPopupDetailsResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));
    }

    
    getUserAndGoalsBySearchText(parameter):Observable<any>{
      
      return this.httpClient.get<any>(this.urlService.getUserAndGoalsBySearchText() +"/"+ parameter.SearchText+"/"+parameter.UserLocale,
    { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) } )
    .pipe(map((data:any) => data.GetUserAndGoalsBySearchTextResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));
    }

   private handleError(err:HttpErrorResponse){
    let errorMessage="";

    if(err.error instanceof ErrorEvent){
        errorMessage =`An error occured: ${err.error.message} `
    }
    else{
      this.technicalErrorService.setFlagValue(true)
        errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
    }
    console.error(errorMessage);
    return throwError(errorMessage);

}

}
