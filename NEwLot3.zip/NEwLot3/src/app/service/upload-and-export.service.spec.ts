import { TestBed } from '@angular/core/testing';

import { UploadAndExportService } from './upload-and-export.service';

describe('UploadAndExportService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UploadAndExportService = TestBed.get(UploadAndExportService);
    expect(service).toBeTruthy();
  });
});
