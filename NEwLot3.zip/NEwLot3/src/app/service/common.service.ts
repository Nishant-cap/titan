import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { URLService } from "./url.service";
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import LocalStorage from '../util/local-storage';
import { LOCAL_STORAGE_USER_NAME ,PROJECT_ID,LOCAL_STORAGE_USER_ID,PROJECT_NAME,
  LOCAL_STORAGE_USER_LOCALE,LOCAL_STORAGE_USER_LOCALEID,PROJECT_ROLE, PROJECT_LOCALE, PROJECT_DESCRIPTION, USER_ROLE, LOCAL_STORAGE_USER_ROLE} from '../constant/auth-constant';
import { OAuthService } from 'angular-oauth2-oidc';
import { TechnicalErrorService } from './technical-error.service';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  
  constructor(private httpClient:HttpClient, private urlService: URLService,private oauthService:OAuthService,private technicalErrorService:TechnicalErrorService) { }


  getParameters():Observable <any>{
    return this.httpClient.get<any>(this.urlService.projectParametrsUrl()).pipe(
        map((data:any) => data.GetParametersResult),
        catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
    );
 }

getUserID(){
  return LocalStorage.readValue(LOCAL_STORAGE_USER_ID);
}
setProjectId(value){
  // NE28061-10 -Disk Storage Issue
  // return LocalStorage.addItem(PROJECT_ID,value);
  return sessionStorage.setItem(PROJECT_ID,value);
}
setProjectLocale(value){
  return sessionStorage.setItem(PROJECT_LOCALE,value);
}
getProjectLocale(){
  // disk storage issue
  return sessionStorage.getItem(PROJECT_LOCALE);
}
getProjectId(){
  // NE28061-10 -Disk Storage Issue
  // return LocalStorage.readValue(PROJECT_ID);
  return sessionStorage.getItem(PROJECT_ID);
}
getUserName(){
  return LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
}
getUserlocale(){
  return LocalStorage.readValue(LOCAL_STORAGE_USER_LOCALEID);
}
getUserlocaleName(){
  return LocalStorage.readValue(LOCAL_STORAGE_USER_LOCALE);
}
getApiURL(){
  return LocalStorage.readValue("apiurl");
}
setProjectName(name){
  // disk storage issue
  return sessionStorage.setItem(PROJECT_NAME,name);
}

getProjectName(){
  // disk storage issue
  // return LocalStorage.readValue(PROJECT_NAME);
  return sessionStorage.getItem(PROJECT_NAME);
}
s
setProjectDescription(desc){
  return LocalStorage.addItem(PROJECT_DESCRIPTION,desc);
}

getProjectDesciption(){
  return LocalStorage.readValue(PROJECT_DESCRIPTION);
}

setUserRole(role){
  return LocalStorage.addItem(LOCAL_STORAGE_USER_ROLE,role);
}

getUserRole(){
  return LocalStorage.readValue(LOCAL_STORAGE_USER_ROLE);
}
setProjectRole(role){
  return LocalStorage.addItem(PROJECT_ROLE,role);
}
getChangedCod(){
  return LocalStorage.readValue("iscodchange");
}
setChangedCod(val){
  return LocalStorage.addItem("iscodchange",val);
}

getPeojectRole(){
  return LocalStorage.readValue(PROJECT_ROLE);
}

handleResponse(data:any){
    console.log(data);
}

private handleError(err:HttpErrorResponse){
    let errorMessage="";

    if(err.error instanceof ErrorEvent){
        errorMessage =`An error occured: ${err.error.message} `
    }
    else{
      this.technicalErrorService.setFlagValue(true)
        errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
    }
    console.error(errorMessage);
    return throwError(errorMessage);

}
// auth code to get storage items
get id_token() {
  return this.oauthService.getIdToken();
}

 access_token() {
  return this.oauthService.getAccessToken();
}

 id_token_expiration() {
  return this.oauthService.getIdTokenExpiration();
}

 access_token_expiration() {
  return this.oauthService.getAccessTokenExpiration();
}

// encrypt(value:string): string{
//   if(value!=undefined){
//   const keys = '[+;f$*$#@$^@1ERF';
//   var key = CryptoJS.enc.Utf8.parse(keys);
//   var iv = CryptoJS.enc.Utf8.parse(keys);

//   var encrypted = CryptoJS.AES.encrypt(value.toString(), key,
//   {
//       keySize: 128/8,
//       iv: iv,
//       mode: CryptoJS.mode.CBC,
//       padding: CryptoJS.pad.Pkcs7
//   });
//   let val3=this.decryptID(encrypted.toString().replace('+','xMl').replace('/','Por').replace('==','Mla'))
//   console.log("decrytp",val3);
//   console.log("encrypt",encrypted.toString());
//  // console.log("encrypt",encrypted.toString().replace(/[&\/\\#,=+()$~%.'":*?<>{}]/g, 'p2'));
//   return encrypted.toString().split("/").join('Por').split("+").join('xMl').split("=").join('Mla');
//   //replace(/[^a-zA-Z ]/g,'')
//   //replace('xMl', '+' ).replace('Por', '/').replace('Ml', '=')
// }
// }

// decryptID(value:string):string {
//   if(value!=null && value!=undefined){
//   const keys = '[+;f$*$#@$^@1ERF';
//   let _key = CryptoJS.enc.Utf8.parse(keys);
//   let _iv = CryptoJS.enc.Utf8.parse(keys);

//   let decrypt = CryptoJS.AES.decrypt(
//     value.split("Por").join('/').split("xMl").join('+').split("Mla").join('='), _key, {
//       keySize:128/8,
//       iv: _iv,
//       mode: CryptoJS.mode.CBC,
//       padding: CryptoJS.pad.Pkcs7
//     });
//     return decrypt.toString(CryptoJS.enc.Utf8)
// }}
}

