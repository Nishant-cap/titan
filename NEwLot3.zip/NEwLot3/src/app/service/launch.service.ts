import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';

import { URLService } from './url.service';
import { TechnicalErrorService } from './technical-error.service';
@Injectable({
  providedIn: 'root'
})
export class ProjectHomeService {

  constructor(private httpClient: HttpClient,private urlService:URLService,private technicalErrorService:TechnicalErrorService) { }
  // return error message to the end user
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      this.technicalErrorService.setFlagValue(true)
      console.error('Server Side Error :', errorResponse);
    }
    return throwError(errorResponse);
  }

  


    /**------------------------------
*GET LAUNCH DATA.
--------------------------------*/


 getLaunchData(parameter):Observable <any>{
 
   //API
  return this.httpClient.get<any>(this.urlService.getLaunchData()+"/"+parameter.locale+"/"+parameter.ProjectId, 
  { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) }).pipe(map((data:any) =>
   data),
     //tap(data => console.log('All'+ JSON.stringify(data))),
     //const _url = '/assets/jsonFiles/launch.json';
     catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));
}
getMasterDataListforLaunch(parameter):Observable <any>{
  
 return this.httpClient.get<any>(this.urlService.getlaunchDatamasterURL()+"/"+parameter.locale).pipe(map((data:any) => data.GetMasterDataListforLaunchResult),
 catchError(
  (error: any) => {
  
    this.handleError(error);
      throw error}));
}
getSingleData(parameter):Observable <any>{
   //API
   
  return this.httpClient.get<any>(this.urlService.getLaunchDetailURL()+"/"+parameter.locale+"/"+parameter.launchId, 
  { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) }).pipe(map((data:any) => data),
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error}));
}
addLaunch(data): Observable<any> {
  
  return this.httpClient.post<any>(this.urlService.addLaunchURL(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}
/*planning url*/
uploadFile(req):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.planningUploadURL(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}
export(req):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.exportPlanningURL(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}
deletePlanningByLaunchID(req):Observable<any>{
  
  return this.httpClient.post<any>(this.urlService.deletePlanningFile(),req ,
  { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) }).pipe(map((data:any) => data),
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error}));
}

/*objective url*/
uploadFileObjectives(req):Observable <any>{
 
  return this.httpClient.post<any>(this.urlService.uploadObjectivesUrl(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
  map((data:any) => data),
  
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error})
  )}

  exportObjective(req):Observable <any>{
    
    return this.httpClient.post<any>(this.urlService.exportObjectiveByLaunchId(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
      map((data:any) => data),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
  deleteObjectiveByLaunchID(req):Observable<any>{
    
    return this.httpClient.post<any>(this.urlService.deleteObjectiveFile(),req, 
    { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) }).pipe(map((data:any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));
  }

}
