import { HttpClient, HttpErrorResponse, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { TechnicalErrorService } from './technical-error.service';
import { URLService } from './url.service';

@Injectable({
  providedIn: 'root'
})
export class UploadAndExportService {

  constructor(private httpClient: HttpClient,private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      this.technicalErrorService.setFlagValue(true)
      console.error('Server Side Error :', errorResponse);
    }
    return throwError(errorResponse);
  }

getReportCategory(parameter):Observable <any>{
  
  return this.httpClient.get<any>(this.urlService.reportCategory() +"/"+ parameter.locale,
  { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} )
  .pipe(map((data:any) => data.GetReportCategoryDetailsResult),
  
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error}));
  
}
/* upload  for planning service*/
uploadFilePlanning(req):Observable <any>{
 
  
return this.httpClient.post<any>(this.urlService.uploadPlanningUrl(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
map((data:any) => data),

catchError(
  (error: any) => {
  
    this.handleError(error);
      throw error})
)}

/*export for planning service*/
exportPlanning(req):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.exporlURLPlanning(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}


/*exportall for planning service*/
exportAllPlanning(req):Observable <any>{
 
  return this.httpClient.post<any>(this.urlService.exportAllURLPlanning(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}

/*upload for part configuration*/

uploadFilePartConfiguration(req):Observable <any>{
  
  
return this.httpClient.post<any>(this.urlService.uploadPartConfigurationUrl(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
map((data:any) => data),

catchError(
  (error: any) => {
  
    this.handleError(error);
      throw error})
)}


/* export for part configuration */
exportPartConfiguration(req):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.exportPartConfiguration(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}

/*export all for part configuration*/

exportAllPartConfiguration(req):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.exportAllPartConfigurationUrl(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}


/*upload for vehicle service*/

uploadFileVehicle(req):Observable <any>{
 
return this.httpClient.post<any>(this.urlService.uploadVehicle(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
map((data:any) => data),

catchError(
  (error: any) => {
  
    this.handleError(error);
      throw error})
)}

/* export for vehicle service */

exportVehicle(req):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.exportVehicle(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}

/*export all for vehicle*/

exportAllVehicle(req):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.exportAllVehicle(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}

/*upload for manual import*/

uploadFileManualImport(req):Observable <any>{
  
return this.httpClient.post<any>(this.urlService.uploadManualImportUrl(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
map((data:any) => data),

catchError(
  (error: any) => {
  
    this.handleError(error);
      throw error})
)}

/*export for manual Import*/

exportManualImport(req):Observable <any>{

  return this.httpClient.post<any>(this.urlService.exportManualImport(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}

/*export all for manual Import*/

exportAllManualImport(req):Observable <any>{
 
  return this.httpClient.post<any>(this.urlService.exportAllManualImport(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data:any) => data),
    
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
)}

/*upload for objectives*/

uploadFileObjectives(req):Observable <any>{
  
  return this.httpClient.post<any>(this.urlService.uploadObjectivesUrl(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
  map((data:any) => data),
  
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error})
  )}


  /*export for objectives*/

  exportObjectives(req):Observable <any>{
    
    return this.httpClient.post<any>(this.urlService.exportObjectives(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
      map((data:any) => data),
      
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}
/*export all objetive*/
  exportAllObjectives(req):Observable <any>{
  
    return this.httpClient.post<any>(this.urlService.exportAllObjectives(),req, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
      map((data:any) => data),
      
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  )}


/* launch ID */
 
getLaunch(parameter):Observable<any>{

  return this.httpClient.get<any>(this.urlService.getLaunchID() +"/"+ parameter.ProjectID,
  { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} )
  .pipe(map((data:any) => data.GetLancementsByProjectIdResult),
  
     
  catchError(
    (error: any) => {
    
      this.handleError(error);
        throw error}));

}






}
