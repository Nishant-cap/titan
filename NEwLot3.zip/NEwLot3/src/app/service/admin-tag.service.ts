import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from './url.service';
import { TechnicalErrorService } from './technical-error.service';


@Injectable({
  providedIn: 'root'
})
export class AdminTagService {

  constructor(private httpClient: HttpClient,private urlService:URLService,private technicalErrorService:TechnicalErrorService) { }
  // return error message to the end user
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      this.technicalErrorService.setFlagValue(true)
      console.error('Server Side Error :', errorResponse);
    }
    return throwError(errorResponse);
  }


  
    /**------------------------------
*GET ADMIN TAG PROJECT LIST.
--------------------------------*/


 getProjectData(parameter):Observable <any>{
  //API
  
 return this.httpClient.get<any>(this.urlService.getAdminProjectURL()+"/"+parameter.locale, 
 { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) }).pipe(map((data:any) => data),
    tap(data => console.log('All'+ JSON.stringify(data))),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));
}

    /**------------------------------
*GET PREVIOUS TAG PROJECT LIST.
--------------------------------*/


getPreviousTag(parameter):Observable <any>{
  
 return this.httpClient.get<any>(this.urlService.getPreviousTagURL()+"/"+parameter.ProjectId+"/"+parameter.locale, 
 { headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8",}) }).pipe(map((data:any) => data),
    tap(data => console.log('All'+ JSON.stringify(data))),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error}));
}

   /**------------------------------
* SUBMIT ADMIN TAG LIST.
--------------------------------*/

saveAdmin(data): Observable<any> {
  
  return this.httpClient.post<any>(this.urlService.saveAdminURL(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data),
    tap(data => console.log('project status' + JSON.stringify(data))),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}


}
