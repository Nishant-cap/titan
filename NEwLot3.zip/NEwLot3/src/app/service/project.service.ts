import { Injectable } from '@angular/core';
import { Project } from '../modules/home/project-list/project';
import { ProjectStatus } from "../modules/home/project-list/projectstatus";
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { URLService } from './url.service';
import { TechnicalErrorService } from './technical-error.service';


@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private httpClient: HttpClient, private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }
  // Handle Error
  private handleError(err: HttpErrorResponse) {
    let errorMessage = "";
    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error occured: ${err.error.message} `
    }
    else {
      this.technicalErrorService.setFlagValue(true)
      errorMessage = `Server returned code:${err.status}, error message is:${err.message}`
    }
    console.error(errorMessage);
    return throwError(errorMessage);

  }

  // Get Project Data INProgress
  // API -- GetProjectListByStatus/{userLocale}/{projectStatus} //StatusValue -- 0/1/2
  getRecords(param): Observable<Project[]> {
   
   //let token="eyJhbGciOiJSUzI1NiIsImtpZCI6IjRZclEzVGJxOUIyN29TM0V4S2ItaHZpSDI0dyIsInBpLmF0bSI6IjRwNyJ9.eyJzY29wZSI6Im9wZW5pZCIsImNsaWVudF9pZCI6IktRU1VRRUtFVUFFSFJFWEhDVlpCR0NHTUtQT0dXSkdWIiwiZ3JvdXBzIjoiVE5ULkFETUlOIiwiZmlyc3RuYW1lIjoiSU5URVJORSBTSU1VTEUiLCJsYXN0bmFtZSI6Ik0wMDAzMzYwIiwidXNlcm5hbWUiOiJNMDAwMzM2MCIsImV4cCI6MTYyMDYzMDg3N30.kwt0BFfiMNnT6qZCb0EJ2Tg4AUzk1olBWn20MMvhTNjQBigBxkp0Y9Df9aSkeV0uYrrmapOG6WqGzRA4e7_VmgBiiQMdasbKtv9Fu77Wy_aDuW7Szc7rQEzOcC9A541KmBSkgjSzVKzTu7S7MHX1jlwU9P6BW2pmVz282e0H5zerqCGJymguRtLAONboUFLWFzJPWgH0nDHPZerQR0xTLBkPdoAtQ8qXOpEHPokcy2UEG_QxMBNw2lAK_59sOofgOATCHZaDd7im_dJntuRF_SIol7JEwi7ZcMsbia75NdSP9QxKW0ZNVV8HnypOxoTTqrUtJ3ER7hu5mo8AOWMnmw"
    return this.httpClient.get<Project[]>(this.urlService.getProjectData() +"/"+param.LOCALE + "/" + param.StatusValue)
  //{ headers: new HttpHeaders().set('Authorization','Bearer ' + token)
  //.set('Content-Type', 'application/json')} )
    .pipe(
      map((data: any) => data.GetProjectListByStatusResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})

    );
  }

  // Get Project Status
  // API -- GetProjectStatusMasterByUserLocale/{userLocale}
  getProjectStatus(param): Observable<ProjectStatus[]> {
    
    return this.httpClient.get<ProjectStatus[]>(this.urlService.projectStatusUrl() +"/"+ param.LOCALE).pipe(
      map((response: any) => response.GetProjectStatusMasterByUserLocaleResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );

  }

  // Get Single record by ID
  // API -- GetProjectDetailsByID/{projectId}
  getprojectDetail(parameter): Observable<Project[]> {
    
    return this.httpClient.get<Project[]>(this.urlService.projectSingleUrl() + "/" + parameter.projectId).pipe(
      map((data: any) => data.GetProjectDetailsByIDResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }
  //disk storage issue 
  getprojectDetailById(parameter): Observable<Project[]> {

    return this.httpClient.get<Project[]>(this.urlService.projectSingleUrl() + "/" + parameter).pipe(
      map((data: any) => {
        console.log(data, "from service");
        return data.GetProjectDetailsByIDResult.ProjectData
      }),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }
  // Get Neo Data
  // API -- GetProjectStatusMasterByUserLocale/GetProjectDefaultMasterResult.lstNeoProjects

  getNeoProjects(): Observable<Project[]> {
    
    return this.httpClient.get<Project[]>(this.urlService.projectLanguageUrl()).pipe(
      map((data: any) => data.GetProjectDefaultMasterResult.lstNeoProjects),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }

  // Get LOTS Data
  // API -- GetProjectStatusMasterByUserLocale/GetProjectDefaultMasterResult.lstSparteProjects

  getLotsProjects(): Observable<Project[]> {
    
    return this.httpClient.get<Project[]>(this.urlService.projectLanguageUrl()).pipe(
      map((data: any) => data.GetProjectDefaultMasterResult.lstSparteProjects),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }

  // Get Language
  // API -- GetProjectDefaultMaster/GetProjectDefaultMasterResult.lstLanguages

  getMasterData(): Observable<any> {
    
    return this.httpClient.get<ProjectStatus[]>(this.urlService.projectLanguageUrl()).pipe(
      map((response: any) => response.GetProjectDefaultMasterResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }

  // Sava Project Data
  // API -- SaveProjectDetails/SAVE

  updateProject(data): Observable<any> {
    
    return this.httpClient.post<any>(this.urlService.updateProjectURL(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
      map((data: any) => data),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }

  saveProjectImage(data): Observable<Project[]> {
    
    return this.httpClient.post<any>(this.urlService.projectImageUploadURL(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
      map((data: any) => data.SaveProjectImageResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }


  getProjectParameters(): Observable<any> {
   
    return this.httpClient.get<any>(this.urlService.projectParametrsUrl(), {
      headers: new HttpHeaders({
        'Content-Type': "application/json; charset=utf-8",
      })
    }).pipe(
      map((data: any) => data.responseList),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }


  postFile(fileToUpload: File): Observable<boolean> {
    
    const endpoint = 'Http:';
    const formData: FormData = new FormData();
    formData.append('fileKey', fileToUpload, fileToUpload.name);
    return this.httpClient
      .post(endpoint, formData, { headers: new HttpHeaders({ 'Content-Type': 'application/form-data' }) }).pipe(
        map((dat: any) => { return true; }),
        catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})

      );
  }

}
