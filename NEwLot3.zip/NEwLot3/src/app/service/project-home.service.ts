import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpEvent, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from './url.service';
import { TechnicalErrorService } from './technical-error.service';


@Injectable({
  providedIn: 'root'
})
export class ProjectHomeService {
   
  
  constructor(private httpClient: HttpClient,private urlService:URLService,private technicalErrorService:TechnicalErrorService) {
    
   }
  // return error message to the end user
  public handleError(errorResponse: HttpErrorResponse) {
    
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
      
    } else {
     this.technicalErrorService.setFlagValue(true)
      console.error('Server Side Error :', errorResponse);
      
    }
    
    return throwError(errorResponse);
 
}


  /**------------------------------
*GET LIST OF REPORT DATA.
--------------------------------*/


getProjectReportList(parameter):Observable <any>{
  //API
 
  return this.httpClient.get<any[]>(this.urlService.getProjectHomeData()+"/"+parameter.locale+"/"+parameter.ProjectId ).pipe(
    map((response: any) => response.GetPerimeterListByProjectIDResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
      );
    }

getProjectList(parameter):Observable <any>{
  //API
  
  return this.httpClient.get<any[]>(this.urlService.getProjectReportData()+"/"+parameter.locale+"/"+parameter.ProjectId+"/"+parameter.obj ).pipe(
    map((response: any) => response.GetPerimeterListByProjectIDAndPerimeterValueResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
      );
    }


    //Get Peremeter Count
getPerimeterCount(parameter):Observable <any>{
  //API
  
  return this.httpClient.get<any[]>(this.urlService.getPerimeterCount()+"/"+parameter.ProjectId+"/"
  +parameter.dropdownValue+"/"+parameter.UserLocale ).pipe(
    map((response: any) => response.GetPerimeterCountByProjectIDAndPerimeterValueResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
      );
    }

//Get Perimeter List and Count of specific Project
getPerimeterCountList(parameter):Observable <any>{
  //API
  
  return this.httpClient.get<any[]>(this.urlService.getPerimeterCountList()+"/"+parameter.ProjectId+"/"+parameter.UserLocale).pipe(
    
      // return this.httpClient.get<any[]>("assets/mockdata/project-report.json").pipe(
    map((response: any) => response.GetPerimeterDetailsByProjectIDResult),
    // map((response: any) => response),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
      );
    }

  // Get Perimiter List

  getPerimeterList(param): Observable<any> {
    
    return this.httpClient.get<any[]>(this.urlService.reportPerimiterUrl()+ "/"+param.locale ).pipe(
      map((response: any) => response.GetPerimeterListMasterByLocaleResult),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    );
  }

  getSingleReport(param):Observable <any>{
    //API
    
       return this.httpClient.get<any>(this.urlService.getSingleProjectData() + "/" + param.id  + "/"+param.locale).pipe(
        map((data: any) => data.GetPerimeterReportDetailsByPerimeterIDResult),
        catchError(
          (error: any) => {
          
            this.handleError(error);
              throw error})
        );
  }

  // POST request for Create new customs export config
createPerimeterData(data): Observable<any> {
  
  return this.httpClient.post<any>(this.urlService.savePerimeterUrl(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}

   // POST request for Delete Report
   deleteProject(data): Observable<any> {
    
  return this.httpClient.post<any>(this.urlService.DeleteProjectData(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data.DeletePerimeterReportByPerimeterIDResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}

 // POST request for Delete Report
 getProjectImage(projectid): Observable<any> {
  
  return this.httpClient.get<any>(this.urlService.publicgetProjectImageURL()+"/"+projectid, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data.GetProjectImagePathResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}

//get request for rich text box content*/
getRichBoxtextContentByProjectId(param){
  
  return this.httpClient.get<any>(this.urlService.getRichTextBoxContent()+"/"+param.projectID+"/"+param.userLocale, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data.GetRichTextBoxContentByProjectIDResult),
    catchError(
      (error: any, caught: Observable<HttpEvent<any>>) => {
      
        this.handleError(error);
          throw error})
  );
}

/*post request for rich text box content*/
saveContentSectionRichTextBox(data){
 
  return this.httpClient.post<any>(this.urlService.saveRichTextBoxContent(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}
saveContentSectionDetails(data){
  
  //let token="eyJhbGciOiJSUzI1NiIsImtpZCI6IjRZclEzVGJxOUIyN29TM0V4S2ItaHZpSDI0dyIsInBpLmF0bSI6IjRwNyJ9.eyJzY29wZSI6Im9wZW5pZCIsImNsaWVudF9pZCI6IktRU1VRRUtFVU"
  return this.httpClient.post<any>(this.urlService.saveContentSectionDetails(), data, 
  { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} )
  //{ headers: new HttpHeaders().set('Authorization','Bearer ' + token)
  //.set('Content-Type', 'application/json')} )
  .pipe(
    map((data: any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}
getContentSectionDetails(param){
  
  return this.httpClient.get<any>(this.urlService.getContentSectionByID()+"/"+param.ID+"/"+param.UserLocale, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data.GetContentSectionByIDResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}
deleteContentSectionByID(data){
  
  return this.httpClient.post<any>(this.urlService.deleteContentSectionDetails(), data, { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error})
  );
}

getContentSectionDetailsByType(param){
  
  return this.httpClient.get<any>(this.urlService.getContentSectionByType()+"/"+param.Type+"/"+param.UserLocale+"/"+param.ProjectID,
   { headers: new HttpHeaders({ 'Content-Type': "application/json;"})} ).pipe(
    map((data: any) => data.GetContentSectionByTypeResult),
    catchError(
      (error: any) => {
      
        this.handleError(error);
          throw error;
      }
  )
  );
}
}