import { TestBed } from '@angular/core/testing';

import { ProjectReportService } from './project-report.service';

describe('ProjectReportService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProjectReportService = TestBed.get(ProjectReportService);
    expect(service).toBeTruthy();
  });
});
