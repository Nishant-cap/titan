import { Injectable } from '@angular/core';
import { EnvService } from '../env-service/env.service';
import LocalStorage from '../util/local-storage';
//import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class URLService {
  newTitanMicroServiceApiUrl:string="";newTitanAltisMicroServiceApiUrl:string="";newTitanPLmMicroServiceApiUrl:string="";helpLink:string=""
  constructor(private envservice:EnvService) { 
 
    this.envservice.loadConfigurations().subscribe(
      (data: any) => {        
        this.newTitanMicroServiceApiUrl = data.titanService;
        this.newTitanAltisMicroServiceApiUrl = data.altisService;
        this.newTitanPLmMicroServiceApiUrl = data.plmService;
        this.helpLink=data.helpLink
      },
      
    );
    }
  
  authenticationServiceURL() {
    return this.newTitanMicroServiceApiUrl + 'Authenticate';
  }
  authenticationWithIDPURL() {
    return this.newTitanMicroServiceApiUrl + 'AuthenticateWithIDP';
  }
  languageURL() {
    return this.newTitanMicroServiceApiUrl + 'GetLanguageMasterWithLanguageName';
  }
  userdetailURL() {
    return this.newTitanMicroServiceApiUrl + 'GetUserProfile';
  }
  updateuserdetailURL() {
    return this.newTitanMicroServiceApiUrl + 'InsertUserProfile ';
  }

  public projectParametrsUrl() {
    return this.newTitanMicroServiceApiUrl+ 'GetParameters';
  }

  public projectNameParametrsUrl() {
    return this.newTitanMicroServiceApiUrl + 'GetParameters';
  }
  public altisFilterURL() {
    return this.newTitanMicroServiceApiUrl + 'GetStades';
  }
  public decisionmakingFilterURL() {
    return this.newTitanMicroServiceApiUrl + 'GetInstanceDec';
  }
  public lancementFilterURL() {
    return this.newTitanMicroServiceApiUrl + 'GetLancements';
  }
  public piecesFilterURL() {
    return this.newTitanMicroServiceApiUrl + 'GetPieces';
  }
 
  public getTNTQVB9PagedURL() {
    return this.newTitanMicroServiceApiUrl + 'GetTNTQVB9Paged';
  }
  public alrisStatusURL() {
    return this.newTitanMicroServiceApiUrl + 'GetStatutsAltis';
  }
  public getAllTNTQTB3URL() {
    return this.newTitanMicroServiceApiUrl + 'GetAllTNTQTB3';
  }
  public getFTInfo() {
    return this.newTitanMicroServiceApiUrl + 'GetFTInfo';
  }
  public updateFT() {
    return this.newTitanMicroServiceApiUrl + 'UpdateFT';
  }
  //mesurelist
  public getmeasureURL() {
    return this.newTitanMicroServiceApiUrl + 'GetPagedTNTQVB5ByCurrentProject';
  }
  public updateTNTQTB2DateEmonURL() {
    return this.newTitanMicroServiceApiUrl + 'UpdateTNTQTB2DateEmon';
  }

// Launch Page 
public getLaunchData() {
  return  this.newTitanMicroServiceApiUrl + 'GetLaunchList';
 
}
public addLaunchURL() {
  return  this.newTitanMicroServiceApiUrl + 'SaveLaunch';
}
public getlaunchDatamasterURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetMasterDataListforLaunch';
}

public planningUploadURL() {
  return  this.newTitanMicroServiceApiUrl + 'UploadPlanning';
}
public exportPlanningURL() {
  return  this.newTitanMicroServiceApiUrl + 'ExportPlanningByLancement';
}
public exportObjectiveByLaunchId(){
  return  this.newTitanMicroServiceApiUrl + 'ExportObjectiveByLancement';
}
public getLaunchDetailURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetLaunchDetails';
}
/* Project List service */

//Get All Project data
public getProjectData() {
  return  this.newTitanMicroServiceApiUrl + 'GetProjectListByStatus';
}
//Get Single Project data
public projectSingleUrl()
{
  return  this.newTitanMicroServiceApiUrl + 'GetProjectDetailsByID';
}

// Get Project status
public projectStatusUrl() {
  return  this.newTitanMicroServiceApiUrl + 'GetProjectStatusMasterByUserLocale';
}

// Get Project language
public projectLanguageUrl() {
  return  this.newTitanMicroServiceApiUrl + 'GetProjectDefaultMaster';
}
// update Project image
public projectImageUploadURL() {
  return  this.newTitanMicroServiceApiUrl + 'SaveProjectImage';
}


// Get Project language
public updateProjectURL() {
  return  this.newTitanMicroServiceApiUrl + 'SaveProjectDetails';
}

// Get Admin Tag Project List

// Get Admin list
public getAdminProjectURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetAdminTagProjectList';
}

// Get Admin Tag
public getPreviousTagURL()
{
  return  this.newTitanMicroServiceApiUrl + 'GetTagsbyProjectID';
}
// Get Admin 
public saveAdminURL()
{
  return  this.newTitanMicroServiceApiUrl + 'SaveAdminTag';
}

//// Codification-sea

public getMeasuresURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetMeasureAll';


}
public getOriginAltisURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetOriginsAltis';
}
/*main data of cod-ets*/
public getMeasureSynthesisURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetMeasureSynthesis';
}
public emailSettingsConfiguredURL() {
  return  this.newTitanMicroServiceApiUrl + 'EmailSettingsConfigured';
}
/*Send Email */
public sendemailURL() {
  return  this.newTitanMicroServiceApiUrl + 'SendEmail';
}
/*get detail of defect */
public getAllTNTQTB3ConfiguredURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetAllTNTQTB3';
}
/* to bind the enginerring team by default*/
public getDefaultPieceChoiceURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetDefaultPieceChoice';
}
public getEnginerringTeamURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetTNTQTR4ByID';
}
/*get altisChangePieceAltistePlm*/
public getAltisURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetOriginsAltis';
}
/**change of altis/pl, */
public changePieceAltistePlmURL() {
  return  this.newTitanMicroServiceApiUrl + 'ChangePieceAltistePlm';
}
/*Link attachment  */
public savelinkattachmentURL() {
  return  this.newTitanMicroServiceApiUrl + 'SaveLinkAttachment';
}
/* update Link attachment  */
public updatelinkattachmentURL() {
  return  this.newTitanMicroServiceApiUrl + 'UpdateLinkAttachment';
}
/* delete Link attachment  */
public deletelinkattachmentURL() {
  return  this.newTitanMicroServiceApiUrl + 'DeleteLinkAttachment';
}
/*Save Image attachment  */
public saveImageattachmentURL() {
  return  this.newTitanMicroServiceApiUrl + 'SaveImageAttachment';
}
/* get Image attachment  */
public getImageattachmentURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetImageAttachmentByID';
}
/* get Image main  */
public setMainImage() {
  return  this.newTitanMicroServiceApiUrl + 'SetAsMainImage';
}


/* delete Image attachment  */
public deleteImageattachmentURL() {
  return  this.newTitanMicroServiceApiUrl + 'DeleteImageAttachment';
}
/* get defect attachment  */
public getdefectAttachmentURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetDefectAttachments';
}
/**change state*/
public changeStateURL() {
  return  this.newTitanMicroServiceApiUrl + 'UpdateExistingTNTQTB6EntityState';
}
/*link to altis state*/
public linkAltisURL() {
  return  this.newTitanAltisMicroServiceApiUrl + 'Link';
}
/*Unlink to altis state*/
public unlinkAltisURL() {
  return  this.newTitanAltisMicroServiceApiUrl + 'Unlink';
}
/*link to plm */
public linkPlmURL() {
  return  this.newTitanPLmMicroServiceApiUrl + 'LinkIssue';
}
/*update defect*/
public updatedefectURL() {
  return  this.newTitanMicroServiceApiUrl + 'UpdateDefect';
}
/*craete new  ft*/
public createFTURL() {
  return  this.newTitanAltisMicroServiceApiUrl + 'CreateFT';
}
/*craete new  issue*/
public createIssueURL() {
  return  this.newTitanPLmMicroServiceApiUrl + 'CreateIssue';
}
/*unlink to plm */
public unlinkPlmURL() {
  return  this.newTitanPLmMicroServiceApiUrl + 'UnlinkIssue';
}
/*get defect info  */
public getdefectinfoURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetDefectInfo';
}
/*export for cod-sea and ets screen*/
public measureexportURL() {
  return  this.newTitanMicroServiceApiUrl + 'ExportMeasure';
}

/* Part repository service */
/*upload */
public uploadURL() {
  return  this.newTitanMicroServiceApiUrl + 'UploadPartConfigMain';
}
/*Export */
public exporlURL() {
  return  this.newTitanMicroServiceApiUrl + 'ExportPartConfigurationMain';
}
/*ExportAll */
public exportAllURL() {
  return  this.newTitanMicroServiceApiUrl + 'ExportAllPartConfigurationMain';
}

/* Part repository service */

/*report category*/
public reportCategory(){
  
  return  this.newTitanMicroServiceApiUrl + 'GetReportCategoryDetails';
}

/* Part repository service */

/*Plannig service*/
public uploadPlanningUrl() {
  return  this.newTitanMicroServiceApiUrl + 'UploadPlanning';
}

public exporlURLPlanning() {
  return  this.newTitanMicroServiceApiUrl + 'ExportPlanning';
}

public exportAllURLPlanning() {
  return  this.newTitanMicroServiceApiUrl + 'ExportAllPlanning';
}
public deletePlanningFile(){
  return  this.newTitanMicroServiceApiUrl + 'DeletePlanningByLaunchID';
}

/*Planning service*/

/*vehicle service */

public uploadVehicle() {
  return  this.newTitanMicroServiceApiUrl + 'UploadVehicle';
}

public exportVehicle() {
  return  this.newTitanMicroServiceApiUrl + 'ExportVehicle';
}

public exportAllVehicle() {
  return  this.newTitanMicroServiceApiUrl + 'ExportAllVehicle';
}

/*vehicle service*/


/*part configuration service*/

public uploadPartConfigurationUrl() {
  return  this.newTitanMicroServiceApiUrl + 'UploadPartConfigProject';
}

public exportPartConfiguration() {
  return  this.newTitanMicroServiceApiUrl + 'ExportPartConfigurationProject';
}

public exportAllPartConfigurationUrl() {
  return  this.newTitanMicroServiceApiUrl + 'ExportAllPartConfigurationProject';
}
/* partconfiguration */

/*Launch Id*/

public getLaunchID(){
  return  this.newTitanMicroServiceApiUrl + 'GetLancementsByProjectId';
}

/*manual import*/

public uploadManualImportUrl() {
  return  this.newTitanMicroServiceApiUrl + 'UploadManualImport';
}

public exportManualImport() {
  return  this.newTitanMicroServiceApiUrl + 'ExportManualImport';
}

public exportAllManualImport() {
  return  this.newTitanMicroServiceApiUrl + 'ExportAllManualImport';
}

/*Objectives*/

public uploadObjectivesUrl() {
  return  this.newTitanMicroServiceApiUrl + 'UploadObjective';
}

public exportObjectives() {
  return  this.newTitanMicroServiceApiUrl + 'ExportObjective';
}
public exportAllObjectives() {
  return  this.newTitanMicroServiceApiUrl + 'ExportAllObjective';
}

public deleteObjectiveFile(){
  return  this.newTitanMicroServiceApiUrl + 'DeleteObjectiveByLaunchID';
}



/* Report Service */
// Get All Data

public getReportData() {
  return  this.newTitanMicroServiceApiUrl + 'GetReportListByStatus';
}
public saveReportURL() {
  return  this.newTitanMicroServiceApiUrl + 'SaveReportDetails';
}

// Get Report language
public reportLanguageUrl() {
  return  this.newTitanMicroServiceApiUrl + 'GetLanguageMaster';
}
public savePerimeterUrl() {
  return  this.newTitanMicroServiceApiUrl + 'SavePerimeterDetails';
}
//Get Perimiter List
public reportPerimiterUrl() {
  return  this.newTitanMicroServiceApiUrl + 'GetPerimeterListMasterByLocale';
}

// Get Status Report List
public reportStatusUrl() {
  return  this.newTitanMicroServiceApiUrl + 'GetReportStatusListMasterByLocale';
}

// Get Report status
public getReportStatusUrl() {
  return  this.newTitanMicroServiceApiUrl + 'GetReportListByStatus';
}

//Delete Report
public deleteReportURL() {
  return  this.newTitanMicroServiceApiUrl + 'DeleteReportByID';
}
// Get single Report data
public getSingleReportData() {
  return  this.newTitanMicroServiceApiUrl + 'GetReportDetailsByID';
}



// Project Home Page
public getProjectHomeData() {
  return  this.newTitanMicroServiceApiUrl + 'GetPerimeterListByProjectID';
}
public getProjectReportData() {
  return  this.newTitanMicroServiceApiUrl + 'GetPerimeterListByProjectIDAndPerimeterValue';
}
public getPerimeterCount() {
  return  this.newTitanMicroServiceApiUrl + 'GetPerimeterCountByProjectIDAndPerimeterValue';
}
public getPerimeterCountList() {
  // return  this.newTitanMicroServiceApiUrl + 'GetPerimeterCountByProjectID';

  return  this.newTitanMicroServiceApiUrl + 'GetPerimeterDetailsByProjectID';
}
public getSingleProjectData() {
  return  this.newTitanMicroServiceApiUrl + 'GetPerimeterReportDetailsByPerimeterID';
}
public savePeremeterURL() {
  return  this.newTitanMicroServiceApiUrl + 'SavePerimeterDetails';
}
public DeleteProjectData() {
  return  this.newTitanMicroServiceApiUrl + 'DeletePerimeterReportByPerimeterID';
}
public getProjectListData() {
  return  this.newTitanMicroServiceApiUrl + 'DeletePerimeterReportByPerimeterID';
}
publicgetProjectImageURL() {
  return  this.newTitanMicroServiceApiUrl + 'GetProjectImagePath';
}

public getContentSectionByID(){
  return  this.newTitanMicroServiceApiUrl + 'GetContentSectionByID';
}

public saveContentSectionDetails(){
  
  return  this.newTitanMicroServiceApiUrl + 'SaveContentSectionDetails';
}

public deleteContentSectionDetails(){
  
  return  this.newTitanMicroServiceApiUrl + 'DeleteContentSectionByID';
}
public getContentSectionByType(){
  return  this.newTitanMicroServiceApiUrl + 'GetContentSectionByType';
}

/*mail recipients url*/
public getAllMailList(){
  return  this.newTitanMicroServiceApiUrl + 'GetAllMailRecipients';
}
public addMailRecipients(){
  return  this.newTitanMicroServiceApiUrl + 'InsertMailRecipients';
}
public getMailDataByID(){
  return  this.newTitanMicroServiceApiUrl + 'GetMailRecipients';
}
public updateMailRecipients(){
  return  this.newTitanMicroServiceApiUrl + 'UpdateMailRecipients';
}
public deleteMailRecipient(){
  return  this.newTitanMicroServiceApiUrl + 'DeleteMailRecipients';
}
public getUserAndEmailIdBySearchText(){
  return  this.newTitanMicroServiceApiUrl + 'GetUserAndGoalsBySearchText';
}


/*rich text box content*/
public getRichTextBoxContent(){
  return  this.newTitanMicroServiceApiUrl + 'GetRichTextBoxContentByProjectID';
}

public saveRichTextBoxContent(){
  return  this.newTitanMicroServiceApiUrl + 'SaveContentSectionRichTextBox';
}

/*access management*/

public getRoleMaster(){
  return  this.newTitanMicroServiceApiUrl + 'GetRolesMaster';
}

public getProjectList(){
  return  this.newTitanMicroServiceApiUrl + 'GetProjectListForAllStatus';
}

public saveAccessManagementDetails(){
  return  this.newTitanMicroServiceApiUrl + 'SaveAccessManagementDetails';
}

public getProjectListByUserGoalIDAndRoleID(){
  return  this.newTitanMicroServiceApiUrl + 'GetProjectListByUserGoalIDAndRoleID';
}

public getAccessManagementTransactionDetails(){
  return  this.newTitanMicroServiceApiUrl + 'GetAccessManagementTransactionDetails';
}

public deleteAccessManagementRecordsById (){
  return  this.newTitanMicroServiceApiUrl + 'DeleteAccessManagementRecordByID';
}

public editAccessManagementById(){
  return  this.newTitanMicroServiceApiUrl + 'EditAccessManagementByID';
}

public getuserInfoPopupDetails(){
  return  this.newTitanMicroServiceApiUrl + 'GetUserInfoPopupDetails';
}

public getUserAndGoalsBySearchText(){
  return  this.newTitanMicroServiceApiUrl + 'GetUserAndGoalsBySearchText';
}

/*get vehicle info */
public getVehicleURL(){
  return  this.newTitanMicroServiceApiUrl + 'GetVehicleInfoByID';
}
public updateVehicleURL(){
  return  this.newTitanMicroServiceApiUrl + 'UpdateVehicleInfo';
}

/*get vehicle info */
/* get help link from env.json*/
public getHelpLink(){
  return  this.helpLink;
}

public getRoleByProjectId(){
  return this.newTitanMicroServiceApiUrl + 'GetRoleDetailsByUserGoalIDAndProjectIDNew'
}
/*vehicle */
public getvehicleListByProjectId(){
  return this.newTitanMicroServiceApiUrl + 'GetPagedVehicleListByProjectID'
}
/*search api for vehicle*/
public searchVehicleList(){
  return this.newTitanMicroServiceApiUrl + 'SearchPagedVehicleListByProjectID'
}
/*delete api for vehicle*/
public deleteVehicle(){
  return this.newTitanMicroServiceApiUrl + 'DeleteVehicleFromList'
}

/*get vehicle details by id*/
public getVehicleDetailsById(){
  return this.newTitanMicroServiceApiUrl + 'GetVehicleDetailsByID'
}

/*update vehicle details*/
public UpdateVehicleDetails(){
  return this.newTitanMicroServiceApiUrl + 'UpdateVehicleFromUI'
}

/*add vehicle details*/
public addVehicleDetails(){
  return this.newTitanMicroServiceApiUrl + 'AddVehicleFromUI'
}

}

