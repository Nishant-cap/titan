import { Injectable } from '@angular/core';
import { TechnicalEvent } from '../modules/technicalevents/technicalevents-list/technicalevents';
import {FactDetails} from '../modules/technicalevents/technicalevents-list/factsdetail';
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from "./url.service";
import LocalStorage from '../util/local-storage';

import * as _ from 'node_modules/lodash';
import { TechnicalErrorService } from './technical-error.service';
@Injectable({
  providedIn: 'root'
})
export class TechnicaleventsService {
  techdata:any;
  ftdetail:FactDetails;

  pageNumber:Number=1
  constructor(private httpClient:HttpClient, private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }
  getRecords(params):Observable <any[]>{
   
    return this.httpClient.get<any[]>(this.urlService.getTNTQVB9PagedURL()+"/"+ params.locale + '/' + params.pageSize + '/' + params.pageNumber+'/'+params.projectId).pipe(
      map((data:any) => data.GetTNTQVB9PagedResult),
      
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  ); 
  }
  //pass id and project lang fr_Us
  getTechFactInfo(parameter):Observable <any[]>{
   
    return this.httpClient.get<any>(this.urlService.getFTInfo() +"/"+ parameter.id+"/"+parameter.UserLocale+"/"+parameter.ProjectId,{ headers: new HttpHeaders({ 'Content-Type': "application/json; charset=utf-8"}) }).pipe(
      map((data:any) => data),
      catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
    )}


  getLanchFilter(param):Observable <any>{
    
    return this.httpClient.get<any>(this.urlService.lancementFilterURL()+"/"+param.locale+"/"+param.projectid).pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  );}
  getTags(param):Observable <any>{
    
    return this.httpClient.get<any>(this.urlService.getAllTNTQTB3URL()+"/"+param.locale+"/"+param.projectid).pipe(
       map((data:any) => data),
       catchError(
        (error: any) => {
        
          this.handleError(error);
            throw error})
  );}

      geAltisFilter(param):Observable <any>{
        
        return this.httpClient.get<any>(this.urlService.alrisStatusURL()+"/"+param.locale).pipe(
           map((data:any) => data),
         
           catchError(
            (error: any) => {
            
              this.handleError(error);
                throw error})
      );
        }
        geDecisionMakingFilter(param):Observable <any>{
         
          return this.httpClient.get<any>(this.urlService.decisionmakingFilterURL()+"/"+param.locale+"/"+param.projectid).pipe(
             map((data:any) => data.GetInstanceDecResult),
             catchError(
              (error: any) => {
              
                this.handleError(error);
                  throw error})
        ); }

        updateFT(data):Observable <any>{
         
          return this.httpClient.post<any>(this.urlService.updateFT(),data).pipe(
             map((data:any) => data),
             catchError(
              (error: any) => {
              
                this.handleError(error);
                  throw error})
        ); }
        


  private handleError(err:HttpErrorResponse){
    let errorMessage="";

    if(err.error instanceof ErrorEvent){
        errorMessage =`An error occured: ${err.error.message} `
    }
    else{
      this.technicalErrorService.setFlagValue(true)
        errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
    }
    console.error(errorMessage);
    return throwError(errorMessage);

}


}
