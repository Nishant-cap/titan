import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import LocalStorage from '../util/local-storage';
import { LOCAL_STORAGE_TOKEN_NAME, LOCAL_STORAGE_USER_ID, LOCAL_STORAGE_USER_LOCALE, LOCAL_STORAGE_User_LOGGED, LOCAL_STORAGE_USER_NAME, LOCAL_STORAGE_USER_ROLE, PROJECT_ROLE, ROLE_ADMIN } from '../constant/auth-constant';
import * as jwt_decode from 'jwt-decode';
import { Observable, throwError } from 'rxjs';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { URLService } from './url.service';
import { User } from '../shared/model/user';
import { Role } from '../shared/model/role';
import { catchError, tap, map } from 'rxjs/operators';
import { IfStmt } from '@angular/compiler';
import { promise } from 'protractor';
import { HeaderChangeService } from './header-change.service';
import { OAuthService } from 'angular-oauth2-oidc';
import { TechnicalErrorService } from './technical-error.service';
export interface userDataModal {
  AuthenticateWithIDPResult:{
    UserName: string;
    UserID: string;UserLocale:string,groups:string
  }
  
};
@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {
  private user: User;
  constructor(private _httpClient: HttpClient, private oauthService: OAuthService, 
    private headerChangeService:HeaderChangeService,private _router: Router, private urlService: URLService,private technicalErrorService:TechnicalErrorService) { }

  
 async loginLDAP(accesstoken: string){
   
    let promise = await this._httpClient.post<any>(this.urlService.authenticationWithIDPURL(), { accessToken: accesstoken}).toPromise();
 
      let data=promise.AuthenticateWithIDPResult
      if(data.Result){
      LocalStorage.addItem(LOCAL_STORAGE_USER_NAME, data.UserName)
     LocalStorage.addItem(LOCAL_STORAGE_USER_ID, data.UserID)
     LocalStorage.addItem(LOCAL_STORAGE_User_LOGGED, true)
     LocalStorage.addItem(LOCAL_STORAGE_USER_LOCALE, data.UserLocale)
     LocalStorage.addItem(LOCAL_STORAGE_USER_ROLE, data.groups  )
    
     this.roleAssign(data.groups)
     this.headerChangeService.setuserprofile(data)
      console.log("Promise resolved with: " + JSON.stringify(data));
      
    }
  }
  
  loginWithToken(reqparams): Observable<any> {
    return this._httpClient.post<any>(this.urlService.authenticationWithIDPURL(), reqparams).pipe(
      map((data: any) => data
      ),
      tap(data => console.log('login' + JSON.stringify(data)
      ))
    );
  }
  getuser(userid): Observable<any> {
    return this._httpClient.get<any>(this.urlService.userdetailURL() + '/' + userid).pipe(
      map((data: any) => data
      ),
      tap(data => console.log('login' + JSON.stringify(data)
      ))
    );
  }
  updateUser(params): Observable<any> {
    return this._httpClient.post<any>(this.urlService.updateuserdetailURL(), params, {
      headers: new HttpHeaders({
        'Content-Type': "application/json;"
      })
    }).pipe(
      map((data: any) => data
      ),
      tap(data => console.log('data' + JSON.stringify(data)
      ))
    );
  }

  getlanguageList(): Observable<any> {
    return this._httpClient.get<any>(this.urlService.languageURL()).pipe(
      map((data: any) => data.GetLanguageMasterWithLanguageNameResult
      )
      
      )
    
  }
  /**
   * This method helps check if a token is expired.
   * @param token of  type string is the token
   */
  // isTokenExpired(token?: string): boolean {
  //   if (!token) token = LocalStorage.readToken();
  //   if (!token) return true;

  //   const date = this.getTokenExpirationDate(token);
  //   if (date === undefined) return false;
  //   return !(date.valueOf() > new Date().valueOf());
  // }
  isTokenExpired(token?: string): boolean {
    if (!token) token = LocalStorage.readToken();
    if (!token) return true;

    // const date = this.getTokenExpirationDate(token);
    // if (date === undefined) return false;
    // return !(date.valueOf() > new Date().valueOf());
  }
  /**
   * This method helps retrieve the token expiration date.
   * @param token of type string is the token
   */


  getTokenExpirationDate(token: string): Date {
    /* const decoded = jwt_decode(token);
 
     if (decoded['exp'] === undefined) return null;
 
     const date = new Date(0);
     date.setUTCSeconds(decoded['exp']);
     return date;*/

    const decoded = jwt_decode(token);

    if (decoded['exp'] === undefined) return null;

    const date = new Date(0);
    date.setUTCSeconds(decoded['exp']);
    return date;


  }

  logout(): void {
    // LocalStorage.removeItem(LOCAL_STORAGE_TOKEN_NAME);
    // LocalStorage.removeItem(LOCAL_STORAGE_USER_NAME);
    // this.oauthService.revokeTokenAndLogout();

    this.oauthService.logOut();
  }

  getConnectedUser(): any {
    //console.log(LocalStorage.readValue(LOCAL_STORAGE_USER_NAME));
    return LocalStorage.readValue(LOCAL_STORAGE_USER_ROLE);

  }

  isAdmin(): boolean {
    // console.log("is reader")
    return this.getConnectedUser().userRole === Role.GlobalAdmin;
  }

 
  // NE28061-27 -Session Expire
  sessionExpired(){
    if(this.oauthService.hasValidAccessToken()){
      return true
    }else{
      alert("session expired")
      this.oauthService.logOut();
    }

  }

  hasRole(role: Role) {
 
    let rl: Role
    LocalStorage.readValue(LOCAL_STORAGE_USER_ROLE);
    if (LocalStorage.readValue(LOCAL_STORAGE_USER_ROLE).toLocaleLowerCase() == Role.GlobalAdmin.toLocaleLowerCase()) {
      rl = Role.GlobalAdmin
      this.user = { role: rl }
    }
    else if (LocalStorage.readValue(LOCAL_STORAGE_USER_ROLE).toLocaleLowerCase() ==Role.ExpertPilot.toLocaleLowerCase()) {
      rl = Role.ExpertPilot
      this.user = { role: rl }
    }
    else if (LocalStorage.readValue(LOCAL_STORAGE_USER_ROLE).toLocaleLowerCase() ==Role.Pilot.toLocaleLowerCase()) {
      rl = Role.Pilot
      this.user = { role: rl }
    }
    else if (LocalStorage.readValue(LOCAL_STORAGE_USER_ROLE).toLocaleLowerCase() ==Role.ReadOnly.toLocaleLowerCase()) {
      rl = Role.ReadOnly
      this.user = { role: rl }
    }
    return  this.user.role === role;
  }

  matchRole(role: String) {
 
    let rl: boolean=false;
    
    if (role.toLocaleLowerCase() == Role.GlobalAdmin.toLocaleLowerCase()) {
      rl = true;
      return rl;
    }
    else if (role.toLocaleLowerCase() ==Role.ExpertPilot.toLocaleLowerCase()) {
      rl = true;
      return rl;
    }
    else if (role.toLocaleLowerCase() ==Role.Pilot.toLocaleLowerCase()) {
      rl = true;
      return rl;
    }
    else if (role.toLocaleLowerCase() ==Role.ReadOnly.toLocaleLowerCase()) {
      rl = true;
      return rl;
    }
    return rl;
  }
  hasProjectRole(role: Role) {
    
    let rl: Role
    LocalStorage.readValue(PROJECT_ROLE);
    if (LocalStorage.readValue(PROJECT_ROLE ).toLocaleLowerCase() == Role.GlobalAdmin.toLocaleLowerCase()) {
      rl = Role.GlobalAdmin
      this.user = { projectrole: rl }
    }
    else if (LocalStorage.readValue(PROJECT_ROLE).toLocaleLowerCase() ==Role.ExpertPilot.toLocaleLowerCase()) {
      rl = Role.ExpertPilot
      this.user = { projectrole: rl }
    }
    else if (LocalStorage.readValue(PROJECT_ROLE).toLocaleLowerCase() ==Role.Pilot.toLocaleLowerCase()) {
      rl = Role.Pilot
      this.user = { projectrole: rl }
    }
    else if (LocalStorage.readValue(PROJECT_ROLE).toLocaleLowerCase() ==Role.ReadOnly.toLocaleLowerCase()) {
      rl = Role.ReadOnly
      this.user = { projectrole: rl }
    }
    return  this.user.projectrole === role;
  }
  roleAssign(role: Role) {
    this.user = { role: role };
  }
  encrypt(value: string): string {
    const keys = '[+;f$*$#@$^@1ERF';
    var key = CryptoJS.enc.Utf8.parse(keys);
    var iv = CryptoJS.enc.Utf8.parse(keys);

    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(value.toString()), key,
      {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
      });
    return encrypted.toString();
  }

  private refreshTokenTimeout;

  public startRefreshTokenTimer(interval) {
      // parse json object from base64 encoded jwt token
      
     let tokenexpiry = this.oauthService.getAccessTokenExpiration();
    console.log(tokenexpiry, "tokenexpiry epoch");
    let expires_at =  window.localStorage.getItem('expires_at');
     console.log(expires_at, "expires_at ");
     let valueExpDATETIME = new Date(tokenexpiry as number);
      console.log(valueExpDATETIME,"valueExpDATETIME"); 
      this.refreshTokenTimeout = setInterval(() => this.refreshToken(), interval);
    
  }

  public stopRefreshTokenTimer() {
      clearTimeout(this.refreshTokenTimeout);
  }
  refreshToken() {
   this.oauthService.refreshToken().then(res=>{
   
   }).catch(err => {
     
    console.log("Unable to refresh the token");
 
  })
   this.oauthService.getRefreshToken()
}


}
