import { Injectable, Inject, OnInit } from '@angular/core';
import { HttpClient, HttpParams, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import LocalStorage from '../util/local-storage';
import { Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';
interface Configuration {
  titanService: string;
  altisService: string;
  plmService: string;
  helpLink:string;
  stage: string;
  debugEnabled:boolean
}


@Injectable()
export class EnvService implements OnInit {

  constructor(private httpClient: HttpClient) {
  
  }
  private readonly CONFIG_URL="assets/envdata/envdata.json"
  private configuration$: Observable<Configuration>;
  public newTitanMicroServiceApiUrl = '';

  // to dsiplay or not console logs
  ngOnInit() {    
   // this.loadEnvData(); 
  }
  public loadConfigurations(): any {
    if (!this.configuration$) {
      this.configuration$ = this.httpClient.get<Configuration>(this.CONFIG_URL).pipe(
        shareReplay(1)
      );
    }
    console.log("confi",this.configuration$)
    return this.configuration$;
  }
  // public loadEnvData() { 
 
  //   this.httpClient.get<string>("assets/envdata/envdata.json",   {responseType: 'json'}).subscribe(
  //     (data: any) => {
  //       console.log("returned response from envdata",this.newTitanMicroServiceApiUrl)
  //       this.newTitanMicroServiceApiUrl = data.newTitanServiceUrl;
  //       LocalStorage.addItem("apiurl",this.newTitanMicroServiceApiUrl)
  //     },
  //     (error) => { console.log("error while loading env data from /envdata") }
  //     );
  // }
}
