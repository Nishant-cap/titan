export enum Role {
    GlobalAdmin = 'TNT.ADMIN',
    ExpertPilot='TNT.EXPERT_PILOT',
    Pilot="TNT.PILOT",
    ReadOnly="TNT.READER"

  }
  