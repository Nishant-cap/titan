import { Role } from './role';

export class User {
  role?: Role;
  projectrole?: Role;
   _ID?:any;
    _USER_ID?:any;
    _USER_NAME?:any;
    _LOCALE_ID?:string;
     _LOCALE_NAME?:string;
     _USER_CREATION?:string;
    _USER_MAJ?:string;
     _DATE_CREATION?:string;
     _DATE_MAJ?:string;
}
