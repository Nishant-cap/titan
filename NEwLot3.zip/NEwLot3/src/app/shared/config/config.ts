export const config = {
    pageSize:800,
    pageSizeVehicle:30

}