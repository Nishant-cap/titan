import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export interface IAppConfig {
  
    titanService: string;
    altisService: string;
    plmService: string;
    stage: string;
    debugEnabled:boolean
    issuerURL:string,
    redirectUri:string;
    logoutURL:string,
    clientID:string,
    scopeVar:string,
    allowedUrl:string,
    idleTimeInterval:number,
    refreshTokenInterval:number,
    idleTimeOutInterval:number
};

@Injectable()
export class AppConfig {

    public static settings;
    public static testURL:string;

    public testvar:string;
    public testURL:string;
    public exposedTokenEndpointURL:string;
    public exposedIssuerURL:string;
    public exposedRedirectURL:string;
    public exposedLogoutURL:string;
    public exposedClientID:string;
    public exposedScopeVar:string;
    public exposedClientSecretVar: string;
    public exposedallowedURlVar: string;
   
    public exposedIdleInterval: number;
    public exposedRefreshTokenInterval: number;
    public eposedidleTimeOutInterval:number

    constructor(private http: HttpClient) { }

    load() {
         let url="assets/envdata/envdata.json"
        console.log("Initialize App")
        return new Promise<void>((resolve, reject) => {
            this.http.get(url).toPromise().then((response: Response) => {
                AppConfig.settings = response;
                console.log(AppConfig.settings);
                AppConfig.testURL = AppConfig.settings.redirectURI;
                this.testURL = AppConfig.settings.redirectURI;
                // Exposed value assigened to variables 
                this.exposedIssuerURL = AppConfig.settings.issuerURL;
                this.exposedRedirectURL = AppConfig.settings.redirectURI;
                this.exposedLogoutURL = AppConfig.settings.logoutUrl;
                this.exposedClientID = AppConfig.settings.clientID;
                this.exposedScopeVar = AppConfig.settings.scopeVar;
                this.exposedTokenEndpointURL=AppConfig.settings.tokenEndpoint
                this.exposedClientSecretVar = AppConfig.settings.dummyClientSecretVar; 
                this.exposedallowedURlVar = AppConfig.settings.allowedUrl; 
                this.exposedIdleInterval= AppConfig.settings.idleTimeInterval;
                this.exposedRefreshTokenInterval= AppConfig.settings.refreshTokenInterval;
                this.eposedidleTimeOutInterval=AppConfig.settings.idleTimeOutInterval;
                resolve();
            }).catch((response: any) => {
                reject(`Could not load file '${url}': ${JSON.stringify(response)}`);
            });
        });
    }

    getAppConfig(): IAppConfig {
        console.log("getappconfig" + AppConfig.settings)
        return AppConfig.settings;
    }
}
