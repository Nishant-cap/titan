
import { Directive, OnInit, TemplateRef, ViewContainerRef, Input } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { AuthenticationService } from '../../service/authentication.service';
import { Role } from '../model/role';

@Directive({
  selector: '[appProjectRole]'
})
export class ProjectRoleDirective {

  constructor(private templateRef: TemplateRef<any>,
    private authService: AuthenticationService,private oauthService: OAuthService,
    private viewContainer: ViewContainerRef) { }
    projectRoles: Role[];
    @Input() 
    set appProjectRole(roles: Role[]) {
        if (!roles || !roles.length) {
            throw new Error('Roles value is empty or missed');
        }
 
        this.projectRoles = roles;
    }
 
    ngOnInit() {
        let hasAccess = false;
 
        if (this.projectRoles) {
            hasAccess = this.projectRoles.some(r => this.authService.hasProjectRole(r));
        }
 
        if (hasAccess) {
            this.viewContainer.createEmbeddedView(this.templateRef);
        } else {
            this.viewContainer.clear();
        }
    }
}
