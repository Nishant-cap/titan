import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserRoleDirective } from '../../directives/user-role.directive';




@NgModule({
  declarations: [UserRoleDirective],
  imports: [
    CommonModule
  ],exports: [
    UserRoleDirective
  ],
})
export class UserRoleDirectiveModule { }
