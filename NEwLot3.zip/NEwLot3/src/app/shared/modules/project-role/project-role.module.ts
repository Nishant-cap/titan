import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectRoleDirective } from '../../directives/project-role.directive';



@NgModule({
  declarations: [ProjectRoleDirective],
  imports: [
    CommonModule
  ],exports: [
    ProjectRoleDirective
  ]
})
export class ProjectRoleModule { }
