import { Pipe, PipeTransform } from '@angular/core';
import { ignoreElements } from 'rxjs/operators';
import * as _ from 'node_modules/lodash';
@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(list: any, searchmetier: any, searchtitle: any, searchlaunchName: any, searchdecision: any, selectedAltis: any): any {


    let temp: any[] = [];
    let tempdata: any[] = [];
    if (((searchmetier.length > 0) || (searchtitle.length > 0) || (searchlaunchName.length > 0) || searchdecision.length > 0 || selectedAltis.length > 0)) {
      
      temp = list;
      
      if (searchmetier.length > 0) {

        temp = _.filter(temp, function (o) {
          if (o.metier.toUpperCase().includes(searchmetier.toUpperCase())) return o;

        });
      }
      
      // NE28061-62 fixed issue
      if (searchtitle.length > 0) {
        
        temp = _.filter(temp, function (o) {
          o.idFTAltis = o.idFTAltis.toString();
         
          if (!_.isNil(o.title))
            if (o.title.toUpperCase().includes(searchtitle.toUpperCase()) || 
            o.idFTAltis.toUpperCase().includes(searchtitle.toUpperCase()) ||
            o.dessignation.toUpperCase().includes(searchtitle.toUpperCase()) ||
            o.tags.toString().toUpperCase().includes(searchtitle.toUpperCase())
            
            ) return o;
        });
        
      }
     

      let temptde: any[] = [];
      if (searchdecision.length > 0) {
        searchdecision.forEach(element => {
          temptde = _.concat(temptde, _.filter(temp, function (o) {
            if (!_.isNil(o.instDecision))
              if (o.instDecision.toUpperCase().includes(element.toUpperCase())) return o;
          }));

        })
        temp = temptde
      }


      let tempti: any[] = [];
      if (selectedAltis.length > 0) {
        selectedAltis.forEach(element => {
          tempti = _.concat(tempti, _.filter(temp, function (o) {
            if (!_.isNil(o.stateProgress))
              if (o.stateProgress.toUpperCase().includes(element.toUpperCase())) return o;
          }));

        })
        temp = tempti
      }

      let temptla: any[] = [];
      if (searchlaunchName.length > 0) {
        searchlaunchName.forEach(element => {
          temptla = _.concat(temptla, _.filter(temp, function (o) {
            if (!_.isNil(o.launchName))
              if (o.launchName.toUpperCase().includes(element.toUpperCase())) return o;
          }));
         
          
        })
        temp = temptla
      }
      



      tempdata = temp
      return tempdata
    }
    else
      return list;
  }
}
