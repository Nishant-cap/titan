import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'node_modules/lodash';
@Pipe({
  name: 'measureSearch'
})
export class MeasureSearchPipe implements PipeTransform {
  
  constructor() {
   }

  transform(list: any, searctestType: any, searchCm: any, searchVnVs: any,
    searchLicon: any, searchPhase: any, searchManDatefrom: any, searchManDateto: any, searchNOfDefects: any, searchPhaseSparte: any,
    searchPhaseTitan: any, searchLastModFrom: any, searchLastModto: any
  ): any {
  
    let Isaerchtext: boolean = false; let Islanchtext: boolean = false; let Isldecisiontext: boolean = false;
    let temp: any[] = [];
    let tempdata: any[] = [];
    

    // let g=new Date(searchManDate).toISOString()

    //     let latest_date =this.datepipe.transform(g, 'yyyy-MM-dd');
    if ((searctestType.length > 0) || (searchCm.length > 0) || (searchVnVs.length > 0) || (searchLicon.length > 0) || (searchManDatefrom != "") || (searchManDateto != "")
      || (searchPhase.length > 0) || (searchNOfDefects.length > 0) || (searchPhaseSparte.length > 0)
      || (searchPhaseTitan.length > 0) || (searchLastModFrom != "") || (searchLastModto != "")) {
      temp = list;






      if (searctestType.length > 0) {
        temp = _.filter(temp, function (o) {
          if (o.testType.toUpperCase().includes(searctestType.toUpperCase())) return o;

        });
      }
      if (searchCm.length > 0) {
        temp = _.filter(temp, function (o) {
          if (o.contremarque.toUpperCase().includes(searchCm.toUpperCase())) return o;
        });
      }
      if (searchVnVs.length > 0) {
        temp = _.filter(temp, function (o) {
          if (o.vis.toUpperCase().includes(searchVnVs.toUpperCase())) return o;
        });

      }
      // if (searchLicon.length > 0) {
      //   temp = _.filter(temp, function (o) {
      //     if (o.silhouette.toUpperCase().includes(searchLicon.toUpperCase())) return o;
      //   });

      // }
      if (searchLicon.length > 0) {
        temp = _.filter(temp, function (o) {
          if (o.silhouette.toUpperCase().includes(searchLicon.toUpperCase())) return o;
        });

      }
      if (searchManDatefrom != "" && searchManDateto != "") {
        let minDate: Date = new Date(searchManDatefrom);
        let maxDate: Date = new Date(searchManDateto);
        temp = _.filter(temp, function (o) {
          let currentDate: Date = new Date(o.dateEmon);
          if (minDate < currentDate && currentDate < maxDate) {
            return o;
          }
        }
        );

      }
      else if (searchManDateto != "") {
        let maxDate: Date = new Date(searchManDateto);
        // let currentDate: Date = new Date();
        //let custdate=(new Date(searchManDatefrom).toISOString())
        // let format_date =this.datepipe.transform(custdate, 'dd/MM/yyyy')

        temp = _.filter(temp, function (o) {
          let currentDate: Date = new Date(o.dateEmon);
          if (currentDate < maxDate) {
            return o;
          }
        }
        );
      }
      else if (searchManDatefrom != "") {
        let minDate: Date = new Date(searchManDatefrom);
        temp = _.filter(temp, function (o) {
          let currentDate: Date = new Date(o.dateEmon);
          if (minDate < currentDate) {
            
            
            return o;
          }
        }
        );
      }
      //modified date filter
      if (searchLastModFrom != "" && searchLastModto != "") {
        let minDate: Date = new Date(searchLastModFrom);
        let maxDate: Date = new Date(searchLastModto);
        temp = _.filter(temp, function (o) {
          let currentDate: Date = new Date(o.modifiedDateSparteNeo);
          if (minDate < currentDate && currentDate < maxDate) {
            return o;
          }
        }
        );

      }
      else if (searchLastModto != "") {
        let maxDate: Date = new Date(searchLastModto);
        // let currentDate: Date = new Date();
        //let custdate=(new Date(searchManDatefrom).toISOString())
        // let format_date =this.datepipe.transform(custdate, 'dd/MM/yyyy')

        temp = _.filter(temp, function (o) {
          let currentDate: Date = new Date(o.modifiedDateSparteNeo);
          if (currentDate < maxDate) {
            return o;
          }
        }
        );
      }
      else if (searchLastModFrom != "") {
        let minDate: Date = new Date(searchLastModFrom);
        temp = _.filter(temp, function (o) {
          let currentDate: Date = new Date(o.modifiedDateSparteNeo);
          if (minDate < currentDate) {
            return o;
          }
        }
        );
      }
      if (searchPhase.length > 0) {
        temp = _.filter(temp, function (o) {
          if (o.phase.toUpperCase().includes(searchPhase.toUpperCase())) return o;
        });

      }
      if (searchNOfDefects.length > 0) {
        temp = _.filter(temp, function (o) {
          if (o.seriousDefects.toUpperCase().includes(searchNOfDefects.toUpperCase())) return o;
        });

      }
     
      let tempSpa: any[] = [];
      if (searchPhaseSparte.length > 0) {
        searchPhaseSparte.forEach(element => {
          tempSpa = _.concat(tempSpa, _.filter(temp, function (o) {
            if (o.statutSparteNeo==element) return o;
          }));

        })
        temp = tempSpa
      }
      let tempti: any[] = [];
      if (searchPhaseTitan.length > 0) {
        searchPhaseTitan.forEach(element => {
          tempti = _.concat(tempti, _.filter(temp, function (o) {
            if (o.statutTitan == element) return o;
          }));

        })
        temp = tempti
      }
      tempdata = temp
      localStorage.removeItem("measureData")
      localStorage.setItem("measureData",JSON.stringify(tempdata))      
      return tempdata
    }
    else
      return list;
      
  }

}
