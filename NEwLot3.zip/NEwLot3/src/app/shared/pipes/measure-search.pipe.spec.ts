import { DatePipe } from '@angular/common';
import { MeasureSearchPipe } from './measure-search.pipe';

describe('MeasureSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new MeasureSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
