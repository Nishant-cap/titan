import { CodseaSearchPipe } from './codsea-search.pipe';

describe('CodseaSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new CodseaSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
