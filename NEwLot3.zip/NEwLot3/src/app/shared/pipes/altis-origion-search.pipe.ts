import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'node_modules/lodash';
@Pipe({
  name: 'altisOrigionSearch'
})
export class AltisOrigionSearchPipe implements PipeTransform {

  transform(list: any, altisplm: any): any 
    {
    
    let Isaerchtext: boolean = false; let Islanchtext: boolean = false; let Isldecisiontext: boolean = false;
    let temp: any[] = [];
    let tempdata: any[] = [];
    if ((!_.isNil(altisplm) && altisplm.length > 0  )
      ) {
        
          temp=list;
         
          
         
        temp = _.filter(temp, function (o) {
         
          if (o.altistePlm!=undefined && (o.altistePlm.toUpperCase().includes(altisplm.toUpperCase())
         
           )) return o;
           
        });
      
        
      tempdata=temp
      
      return tempdata
    }
    else
      return list;
  }

}
