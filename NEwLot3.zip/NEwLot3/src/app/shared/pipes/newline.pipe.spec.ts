import { NewlinePipe } from './newline.pipe';

describe('NewlinePipe', () => {
  it('create an instance', () => {
    const pipe = new NewlinePipe();
    expect(pipe).toBeTruthy();
  });
});
