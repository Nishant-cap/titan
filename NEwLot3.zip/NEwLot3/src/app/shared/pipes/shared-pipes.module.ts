import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { SearchPipe } from './search.pipe';
import { SearchNeoPipe } from './search-neo.pipe';
import { SearchSpartePipe } from './search-sparte.pipe';


@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [ ],
   
})
export class SharedPipesModule { }
