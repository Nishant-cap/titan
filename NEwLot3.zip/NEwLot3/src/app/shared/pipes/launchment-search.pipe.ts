import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'node_modules/lodash';
@Pipe({
  name: 'launchmentSearch'
})
export class LaunchmentSearchPipe implements PipeTransform {

  transform(list: any, id: any, searchtitle: any,  searchdecision: any): any {
   
    let Isaerchtext: boolean = false; let Islanchtext: boolean = false; let Isldecisiontext: boolean = false;
    let temp: any[] = [];
    let tempdata: any[] = [];
    if (((searchtitle.length > 0) || (id.length > 0) ||  searchdecision.length > 0)) {
      temp = list;

      if (searchtitle.length > 0) {
        temp = _.filter(temp, function (o) {
          if (o.title.toUpperCase().includes(searchtitle.toUpperCase())) return o;
        });
      }
      if (id.length > 0) {
        temp = _.filter(temp, function (o) {
          if (o.id.toString().includes(id)) return o;
        });
      }
      if (searchdecision.length > 0) {
        temp = _.filter(temp, function (o) {
          if (o.tradeForAction.toUpperCase().includes(searchdecision.toUpperCase())) return o;
        });
      }

      tempdata = temp
      return tempdata

    }
    else
      return list;
  }

}
