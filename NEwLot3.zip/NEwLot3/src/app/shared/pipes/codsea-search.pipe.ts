import { Pipe, PipeTransform } from '@angular/core';
import { ignoreElements } from 'rxjs/operators';
import * as _ from 'node_modules/lodash';

@Pipe({
  name: 'codseaSearch'
})
export class CodseaSearchPipe implements PipeTransform {
  transform(list: any, grossnbrTxt: any, gravityTxt: any, 
    stateTxt: any, copTxt: any): any {
    let Isaerchtext: boolean = false; let Islanchtext: boolean = false; let Isldecisiontext: boolean = false;
    let temp: any[] = [];
    let tempdata: any[] = [];
    if (((grossnbrTxt.length > 0) ||  (gravityTxt.length > 0) ||stateTxt.length>0||copTxt.length>0)
      ) {
          temp=list;
   
        if (grossnbrTxt.length > 0) {
        temp = _.filter(temp, function (o) {
          if ((o.nBrut.toUpperCase().includes(grossnbrTxt.toUpperCase()) ||
           (o.localisation.toUpperCase().includes(grossnbrTxt.toUpperCase()) )||
           (o.nature.toUpperCase().includes(grossnbrTxt.toUpperCase()) ) ||
           (o.codeNature.toUpperCase().includes(grossnbrTxt.toUpperCase()) ) ||
           (o.side.toUpperCase().includes(grossnbrTxt.toUpperCase()) ) ||
           (o.observations.toUpperCase().includes(grossnbrTxt.toUpperCase()) ) ||
           (o.codeLoc.toUpperCase().includes(grossnbrTxt.toUpperCase()) ) ||
           (o.user.toUpperCase().includes(grossnbrTxt.toUpperCase()) )
           )) return o;
           
        });
      }
     
      let tempSpa: any[] = [];
      if(gravityTxt.length>0){
        gravityTxt.forEach(element => {
          tempSpa =_.concat(tempSpa,_.filter(temp, function(o) {
            if (o.severity.code.toUpperCase().includes(element.toUpperCase())) return o;
          }));
         
      })
      temp=tempSpa
    }
  
    let tempstate: any[] = [];
      if(stateTxt.length>0){
        stateTxt.forEach(element => {
          tempstate =_.concat(tempstate, _.filter(temp, function(o) {
            if (o.status.toUpperCase().includes(element.toUpperCase())) return o;
          }));
         
      })
      temp=tempstate
    }
      // if (stateTxt.length > 0) {
      //   temp = _.filter(temp, function (o) {
      //     if (o.silhouette.toUpperCase().includes(stateTxt.toUpperCase())) return o;
      //   });

      // }
      let tempcop: any[] = [];
      if(copTxt.length>0){
        copTxt.forEach(element => {
          tempcop=_.concat(tempcop ,_.filter(temp, function(o) {
            if (o.codifState.toUpperCase().includes(element.toUpperCase())) return o;
          }));
         
      })
      temp=tempcop
    }
    
      tempdata=temp
      return tempdata
    }
    else
      return list;
  }
}
