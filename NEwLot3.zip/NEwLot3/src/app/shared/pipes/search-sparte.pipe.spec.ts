import { SearchSpartePipe } from './search-sparte.pipe';

describe('SearchSpartePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchSpartePipe();
    expect(pipe).toBeTruthy();
  });
});
