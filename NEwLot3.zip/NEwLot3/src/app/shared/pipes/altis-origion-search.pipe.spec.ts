import { AltisOrigionSearchPipe } from './altis-origion-search.pipe';

describe('AltisOrigionSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new AltisOrigionSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
