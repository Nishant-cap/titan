import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'node_modules/lodash';
@Pipe({
  name: 'searchSparte'
})
export class SearchSpartePipe implements PipeTransform {

  transform(list: any,searchSparte: any):any {
    let temp: any[] = [];
    let tempdata: any[] = [];
    if (searchSparte.length > 0) {
    
     temp = list;
     if (searchSparte.length > 0) {
       
      temp = _.filter(temp, function (o) {
        if (!_.isNil(o.Key))
          if (o.Key.toUpperCase().startsWith(searchSparte.toUpperCase())
          
          )
          
           return o;
      });
      
    }
    tempdata = temp
      return tempdata
    }else{
      return list
    }
    
  }
  

}
