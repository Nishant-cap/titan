import { SearchNeoPipe } from './search-neo.pipe';

describe('SearchNeoPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchNeoPipe();
    expect(pipe).toBeTruthy();
  });
});
