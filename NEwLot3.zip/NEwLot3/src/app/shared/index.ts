
export * from './pipes/shared-pipes.module';
export * from './guard';
