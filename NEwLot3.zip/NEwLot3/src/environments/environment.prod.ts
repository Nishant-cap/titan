export const environment = {
  production: true
};

/*
export const environment = {
  production: true,
  BASE_API_URL: 'http://localhost:9090/otrmicroservice',
  name: 'prod'
};
*/