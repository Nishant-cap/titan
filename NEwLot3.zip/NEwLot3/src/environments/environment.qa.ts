export const environment = {
    production: false,
    BASE_API_URL: 'http://api.ott.qualif.preprod.inetpsa.com/otrmicroservice',
    name: 'qa'
  };