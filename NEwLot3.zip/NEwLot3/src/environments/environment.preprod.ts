export const environment = {
    production: false,
    BASE_API_URL_TITAN: 'http://bi.preprod.inetpsa.com/sites/titan/_vti_bin/Psa.Sfa.Titan.Wcf/TITAN.svc/',
    BASE_API_URL_ALTIS: 'http://bi.preprod.inetpsa.com/sites/titan/_vti_bin/Psa.Sfa.Titan.Wcf/TITAN.svc/',
    BASE_API_URL_PLM: 'http://bi.preprod.inetpsa.com/sites/titan/_vti_bin/Psa.Sfa.Titan.Wcf/TITAN.svc/',
    name: 'preprod'
  };

