// This api will come in the next version

import { AuthConfig } from 'angular-oauth2-oidc';

export const authConfig: AuthConfig = {
  // Url of the Identity Provider
  issuer: 'https://idfed-preprod.mpsa.com:443',
  redirectUri: window.location.origin,
  clientId: 'KQSUQEKEUAEHREXHCVZBGCGMKPOGWJGV',
  dummyClientSecret:'CmYAyVOuq70VLWoyXyvVrki6ObYCKdD3sX7tKlwTE0l10VeWRExouvPRAshG4mii',
  responseType:'code',
  //useSilentRefresh:true,
  scope: 'openid',
  disablePKCE:false,
  logoutUrl: 'https://idfed-preprod.mpsa.com:443/idp/startSLO.ping', 

  tokenEndpoint:"https://idfed-preprod.mpsa.com:443/as/token.oauth2",
 //timeoutFactor: 0.95,
  showDebugInformation: true,

};
